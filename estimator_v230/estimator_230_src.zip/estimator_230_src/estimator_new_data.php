<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
    
<head>

<style>
.matt_required
{
	color: red;
}

.matt_position
{
	color: indigo;
}

.estimate_header
{
	color: #3399cc;
}

.estimate_div
{
	border: 4px solid #3399cc;
	margin-top: 5px;
	/*
	height: 120px;
	*/
}

.missing_features
{
	text-align: left; 
	margin-left: 5px;
}

</style>

 
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 

    <link rel="shortcut icon" href="http://www.thegoodagent.ie/favicon.ico" type="image/x-icon"/> 
<title>Search Sales | Properties | The Good Agent</title> 
<link rel="stylesheet" type="text/css" href="estimator_files/main.css"/> 
<link rel="stylesheet" type="text/css" href="estimator_files/jqmodal.css"/> 
<script src="estimator_files/ga.js" async="" type="text/javascript"></script><script type="text/javascript" src="estimator_files/jquery-1.js"></script>
<script type="text/javascript" src="estimator_files/jquery_002.js"></script>
<script type="text/javascript" src="estimator_files/jquery.js"></script>
<script type="text/javascript" src="estimator_files/jqmodal.js"></script> 

<script type="text/javascript" src="estimator_files/z_matt_county_price_functions.js"></script> 
<script type="text/javascript" src="estimator_files/z_matt_county_price_data.php"></script> 


<script type="text/javascript" src="estimator_files/z_matt_county_town_functions.js"></script>
<script type="text/javascript" src="estimator_files/z_matt_county_town_data.php"></script>

<script type="text/javascript" src="estimator_files/thegoodagent_stuff.js"></script> 
<script type="text/javascript" src="estimator_files/thegoodagent_stuff2.js"></script> 
<script type="text/javascript" src="estimator_files/thegoodagent_stuff3_towns.js"></script> 




<!-- google maps stuff -->
<!-- google maps stuff -->
<!-- google maps stuff -->
<!-- google maps stuff -->
<link href="http://code.google.com/apis/maps/documentation/javascript/examples/default.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>

<script type="text/javascript" src="estimator_files/z_matt_county_location_data.php"></script>
<script type="text/javascript" src="estimator_files/z_matt_google_maps.js"></script>

<script type="text/javascript" src="estimator_files/z_matt_county_google_lookup_data.php"></script>

<!-- ajax stuff -->
<!-- ajax stuff -->
<!-- ajax stuff -->
<!-- ajax stuff -->
<script type="text/javascript" src="estimator_files/aa_matt_ajax_scripts.js"></script>


<!-- VERSION 2 functions -->
<!-- VERSION 2 functions -->
<!-- VERSION 2 functions -->
<!-- VERSION 2 functions -->
<!-- VERSION 2 functions -->


</head>
    
    
<body onload="initialize()">

<div id="modalWindow" class="jqmWindow jqmID1"> 
	<div id="jqmTitle" style="float: right;"> 
		<span id="jqmTitleText">close</span> 
		<button class="jqmClose"> 
		   X
		</button> 
	</div> 
	<iframe id="jqmContent" src="" style="border: 1px solid rgb(255, 255, 255); padding: 0pt; margin: 0pt; width: 388px; height: 448px;" frameborder="0"> 
	</iframe> 
</div> 
<div class="max_width head" style="z-index: 1000;">
	<div class="max_width_cnt">
		<a href="http://www.thegoodagent.ie/"><img src="images/tga_logo.png" alt="The Good Agent - We've just launched!"></a>
		<div id="phone_cnt">Phone: 01-9020203<img src="images/phone_cnt_right.png"></div>
		<a href="#" id="signin_btn">Log In</a>		
		
		<div id="login_cntr">
			<form action="http://www.thegoodagent.ie/properties/sales" method="post">
<input name="form_name" value="login_user" type="hidden">
<label for="username_input">Email Address:</label><input name="username" maxlength="100" size="25" id="username_input" class="login_input" type="text"><label for="password_input">Password:</label><input name="password" value="" maxlength="100" size="25" id="password_input" class="login_input" type="password"><input name="login_submit" value="Sign In" id="login_submit" type="submit"><span><br>Remember me <input name="remember_me" value="remember" type="checkbox"></span><br><span><a href="http://www.thegoodagent.ie/login">Forgotten Password?</a></span></form>
		</div>
		<div class="clear"></div>
		<div id="nav">
		<ul>
			<li id="home_btn"><a href="http://www.thegoodagent.ie/" title="Home"><span>Home</span></a></li>
			<li id="properties_btn"><a href="http://www.thegoodagent.ie/properties" title="Properties" class="current"><span>Properties</span></a></li>
			<li id="team_btn"><a href="http://www.thegoodagent.ie/theteam" title="The Team"><span>The Team</span></a></li>
			<li id="faq_btn"><a href="http://www.thegoodagent.ie/faqs" title="FAQs"><span>FAQs</span></a></li>
		</ul>
		</div>
	</div>
</div>
<div class="max_width toolbar">
	<div class="max_width_cnt">
		
		<form action="http://www.thegoodagent.ie/properties" method="post">
<input name="form_name" value="search_quick" type="hidden">
<div class="qs_item" style="padding-top: 5px;">Search For a Property to Buy or Rent</div><div class="qs_item" style="padding-top: 3px;"><select name="qs_search_salelet_option" id="qs_search_salelet_option" class="select" style="width: 100px;">
<option selected="selected" value="0">Buy</option>
<option value="1">Rent</option>
</select></div><div class="qs_item" style="padding-top: 3px;"><select name="qs_search_county_option" id="qs_search_county_option" class="select" style="width: 200px;">
<option selected="selected" value="def">Choose a County</option>
<option value="0">- All Counties -</option>
<option value="1">Carlow</option>
<option value="2">Cavan</option>
<option value="3">Clare</option>
<option value="4">Cork</option>
<option value="54">&nbsp;&nbsp;--&nbsp;Cork City</option>
<option value="55">&nbsp;&nbsp;--&nbsp;Cork West</option>
<option value="6">Donegal</option>
<option value="7">Dublin</option>
<option value="29">&nbsp;&nbsp;--&nbsp;Dublin 1</option>
<option value="30">&nbsp;&nbsp;--&nbsp;Dublin 2</option>
<option value="31">&nbsp;&nbsp;--&nbsp;Dublin 3</option>
<option value="32">&nbsp;&nbsp;--&nbsp;Dublin 4</option>
<option value="33">&nbsp;&nbsp;--&nbsp;Dublin 5</option>
<option value="34">&nbsp;&nbsp;--&nbsp;Dublin 6</option>
<option value="35">&nbsp;&nbsp;--&nbsp;Dublin 6W</option>
<option value="36">&nbsp;&nbsp;--&nbsp;Dublin 7</option>
<option value="37">&nbsp;&nbsp;--&nbsp;Dublin 8</option>
<option value="38">&nbsp;&nbsp;--&nbsp;Dublin 9</option>
<option value="39">&nbsp;&nbsp;--&nbsp;Dublin 10</option>
<option value="40">&nbsp;&nbsp;--&nbsp;Dublin 11</option>
<option value="41">&nbsp;&nbsp;--&nbsp;Dublin 12</option>
<option value="42">&nbsp;&nbsp;--&nbsp;Dublin 13</option>
<option value="43">&nbsp;&nbsp;--&nbsp;Dublin 14</option>
<option value="44">&nbsp;&nbsp;--&nbsp;Dublin 15</option>
<option value="45">&nbsp;&nbsp;--&nbsp;Dublin 16</option>
<option value="46">&nbsp;&nbsp;--&nbsp;Dublin 17</option>
<option value="48">&nbsp;&nbsp;--&nbsp;Dublin 18</option>
<option value="49">&nbsp;&nbsp;--&nbsp;Dublin 20</option>
<option value="50">&nbsp;&nbsp;--&nbsp;Dublin 22</option>
<option value="51">&nbsp;&nbsp;--&nbsp;Dublin 24</option>
<option value="6">&nbsp;&nbsp;--&nbsp;Dublin County</option>
<option value="7">&nbsp;&nbsp;--&nbsp;Dublin North</option>
<option value="8">&nbsp;&nbsp;--&nbsp;Dublin South</option>
<option value="9">&nbsp;&nbsp;--&nbsp;Dublin West</option>
<option value="10">Galway</option>
<option value="56">&nbsp;&nbsp;--&nbsp;Galway City</option>
<option value="11">Kerry</option>
<option value="12">Kildare</option>
<option value="13">Kilkenny</option>
<option value="15">Laois</option>
<option value="14">Leitrim</option>
<option value="16">Limerick</option>
<option value="57">&nbsp;&nbsp;--&nbsp;Limerick City</option>
<option value="18">Longford</option>
<option value="19">Louth</option>
<option value="20">Mayo</option>
<option value="21">Meath</option>
<option value="22">Monaghan</option>
<option value="23">Offaly</option>
<option value="24">Roscommon</option>
<option value="25">Sligo</option>
<option value="26">Tipperary</option>
<option value="27">Waterford</option>
<option value="29">Westmeath</option>
<option value="30">Wexford</option>
<option value="31">Wicklow</option>
</select></div><div class="qs_item" style="padding-top: 3px;"><select name="qs_search_bed_option" id="qs_search_bed_option" class="select" style="width: 150px;">
<option selected="selected" value="def">No. of Bedrooms</option>
<option value="0">- Any -</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select></div><div class="qs_item" style="margin-bottom: 3px;"><input name="qs_search_submit" value="search" id="qs_search_submit" style="vertical-align: top;" type="submit"></div></form>		
	</div>
</div>


<div id="container">

	<div class="box_wht search_btns_cntr">
		<a href="estimator.php" id="sales_btn" class="current"><img src="images/value_tab_white.png"/></a>
		<a href="" id="lettings_btn"><img src="images/add_to_db_tab_blue.png"/></a>
	</div>

	<div class="box_wht blue_heading_brd">
		<img src="images/estimator_add_db_hd.png" alt="Add new data for estimator database">
	</div>

	



	<div class="box_wht sales_search">
	
	<div style="float:right;">

		<div id="infoPanel">
				
				<form id="google_address_form">
					<input id="move_to_address_button" type="button" value="Move to address:"/>
					<input id="address" type="textbox" size="40"/>
					<input id="move_pin_to_center_button" type="button" value="Move pin to centre of map"/>

				</form>
				<br/>
			  			
		</div>

		<div id="map_canvas" style="width:550px;height:550px;"></div>
		
	</div>	

	
	
	
		<div class="tga_c_property"></div>
		
		<form action="http://www.thegoodagent.ie/properties/sales" method="post">
		
<input name="form_name" value="search_property" type="hidden">
<div class="cola">
<div class="row">
<div class="col1">
<label for="search_county_option">County:<span class="matt_required"> *</span></label></div><div class="col2">
	<select name="search_county_option" id="search_county_option">


		<?php
		//--------- start PHP --------
		
			// PHP to generate county HTML menu here
			include_once( "estimator_files/z_matt_county_menu_html.php");

		//--------- end PHP --------
		?>

	
	</select>
</div>

	<div class="clear"></div>
</div>
	
	<div class="row">
		<div class="col1"><label for="search_town_option">Town:</label></div>
		<div class="col2"><select name="search_town_option" id="search_town_option">
			<option value="0">- Choose a town -</option>
		</select>
	</div>

	<div class="clear"></div>
	
	</div>
	
	<div class="row">
		<div class="col1">
			<label for="search_property_type_option">Type:<span class="matt_required"> *</span></label>
		</div>
		
		<div class="col2"><select name="search_property_type_option" id="search_property_type_option">
			<option value="0" selected="selected" >- Choose property type -</option>
			<option value="1">Apartment</option>
			<option value="2">Terraced</option>
			<option value="3">Semi-Detached</option>
			<option value="4">Detached</option>
			</select>
		</div>
	
		<div class="clear"></div>
	
	</div>

	
	<div class="row">
		<div class="col1">
			<label for="bedrooms">Bedrooms:<span class="matt_required"> *</span></label>
		</div>
	
		<div class="col2"><select name="bedrooms" id="bedrooms" class="select">
			<option value="0" selected="selected" >- No. of bedrooms -</option>
			<option value="1">1</option>
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			</select>
		</div>
	
		<div class="clear"></div>
	</div>
	
	<div class="row">
		<div class="col1">
			<label for="bathrooms">Bathrooms:<span class="matt_required"> *</span></label>
		</div>
	
		<div class="col2"><select name="bathrooms" id="bathrooms" class="select">
			<option value="0" selected="selected" >- No. of bathrooms -</option>
			<option value="1">1</option>
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			</select>
			

		</div>

			<div style="">		
				(<span class="matt_required">*</span> indicates a required field)
			</div>	

		<div class="clear"></div>
	</div>



	<div class="row" style="width:400px">
		<div>
			Other features:
			
			
			<table border="0">
				<tr>
					<th>Central heating</th>
					<td>
						<input type="checkbox" name="central_heating" id="central_heating" value="true" checked="checked"/>
					</td>

					<th>Conservatory</th>
					<td>
						<input type="checkbox" name="conservatory" id="conservatory" value="true"/>
					</td>

				</tr>
				
				<tr>
					<th>Off-street parking</th>
					<td>
						<input type="checkbox" name="parking" id="parking" value="true"/>
					</td>


					<th>New kitchen</th>
					<td>
						<input type="checkbox" name="kitchen_new" id="kitchen_new" value="true"/>
					</td>

				</tr>

				<tr>
					<th>Loft/attic conversion</th>
					<td>
						<input type="checkbox" name="conversion" id="conversion" value="true"/>
					</td>
					
					<td colspan="2">
<!--
						<div id="calc_submit_div" style="float:right;">					
							<input id="calc_submit_div_button" type="button" value="Submit"/>
						</div>
-->
&nbsp;
					</td>
					
					
				</tr>


				
			</table>
			
		</div>
		


		<div class="clear"></div>
	</div>


	<div class="row">
		<div class="col1">
			<label>Value date:<span class="matt_required"> *</span></label>
		</div>
	
		<div class="col2">
			<select name="valuation_month" id="valuation_month" class="select">
				<option value="0" selected="selected" >- Month -</option>


				<?php
				//--------- start PHP --------
				
					// PHP to generate county HTML menu here
					include_once( "estimator_files/z_matt_valuation_month_menu_html.php");
		
				//--------- end PHP --------
				?>
		

			</select>

		</div>
	
		<div class="clear"></div>
	</div>


	<div>
		<div id="estimater_results_block"  class="estimate_div price_div" style="padding: 5px;text-align: center;">
			
			<h3>INCOMPLETE PROPERTY DATA</h3>
			<p class="missing_features">
			The following required features (<span class='matt_required'>*</span>) have yet to be selected:
			</p>
			<ul>
				<li class='matt_required'>Property-type</li>
				<li class='matt_required'>Number of Bathrooms</li>
				<li class='matt_required'>Number of Bedrooms</li>
				<li class='matt_required'>Valuation date (month/year)</li>
			</ul>
		</div>	

	</div>	

</div>
</form>			



</div>




	<div class="box_wht search_results_ftr">
		<div class="property_options">
					</div>
	</div>
	<div class="drop_btm"></div>
	
	<div class="drop_tp"></div>
	<div class="box_wht testimonial">
		<div class="open_qt"></div>
		I was delighted with The Good Agent's service. They were very professional and the advice they gave was spot-on <span>Laura, Dalkey</span>
		<div class="close_qt"></div>
	</div>
	<div class="drop_btm"></div><div class="drop_tp"></div>
</div>
<div class="max_width head">
	<div class="max_width_cnt footer">
		<div class="col1">
			<h3>Home</h3>
			<a href="http://www.thegoodagent.ie/properties">Properties</a><br>
			<a href="http://www.thegoodagent.ie/theteam">Meet The Team</a><br>
			<a href="http://www.thegoodagent.ie/faqs">FAQs</a><br>
			<a href="http://www.thegoodagent.ie/askbarry?width=400&amp;height=480" class="thickbox" title="close">Ask Barry</a><br>
			<a href="mailto:info@thegoodagent.ie">info@thegoodagent.ie</a>
		</div>
		<div class="col2">
			<h3>Property Quick Search</h3>
			<div class="cola">
				<a href="http://www.thegoodagent.ie/properties/sales/search/carlow/1-0-0-0-0-0-0">Carlow</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/cavan/2-0-0-0-0-0-0">Cavan</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/clare/3-0-0-0-0-0-0">Clare</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/cork/52-0-0-0-0-0-0">Cork</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/donegal/4-0-0-0-0-0-0">Donegal</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/dublin/5-0-0-0-0-0-0">Dublin</a>
			</div>
			<div class="colb">
				<a href="http://www.thegoodagent.ie/properties/sales/search/galway/10-0-0-0-0-0-0">Galway</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/kerry/11-0-0-0-0-0-0">Kerry</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/kildare/12-0-0-0-0-0-0">Kildare</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/kilkenny/13-0-0-0-0-0-0">Kilkenny</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/laois/14-0-0-0-0-0-0">Laois</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/leitrim/15-0-0-0-0-0-0">Leitrim</a>
			</div>
			<div class="colc">
				<a href="http://www.thegoodagent.ie/properties/sales/search/limerick/16-0-0-0-0-0-0">Limerick</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/longford/17-0-0-0-0-0-0">Longford</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/louth/18-0-0-0-0-0-0">Louth</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/mayo/19-0-0-0-0-0-0">Mayo</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/meath/20-0-0-0-0-0-0">Meath</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/monaghan/21-0-0-0-0-0-0#">Monaghan</a>
			</div>
			<div class="cold">
				<a href="http://www.thegoodagent.ie/properties/sales/search/offaly/22-0-0-0-0-0-0">Offaly</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/roscommon/23-0-0-0-0-0-0">Roscommon</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/sligo/24-0-0-0-0-0-0">Sligo</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/tipperary/25-0-0-0-0-0-0">Tipperary</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/waterford/26-0-0-0-0-0-0">Waterford</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/westmeath/27-0-0-0-0-0-0">Westmeath</a>
			</div>
			<div class="cole">
				<a href="http://www.thegoodagent.ie/properties/sales/search/wexford/28-0-0-0-0-0-0">Wexford</a><br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/wicklow/53-0-0-0-0-0-0">Wicklow</a><br>
				<br>
				<a href="http://www.thegoodagent.ie/properties/sales/search/dublin-county/6-0-0-0-0-0-0">Dublin County</a><br>
			</div>
		</div>
		<div class="col3">
			<div id="twitter_hd"></div>
			<h3 class="dark">Follow Us</h3>
			<div class="twitted" style="display: block;" id="twitter"><ul style="display: block; height: 58px;" id="twitter_update_list"><li class="firstTweet lastTweet"><span>UK House Prices increase 0.3% month-on-month in June 2011 (0.2% on seasonally adjusted basis) « NAMA Wine Lake - <a href="http://goo.gl/u6MaL">http://goo.gl/u6MaL</a> ^BW</span> <a style="font-size: 85%;" href="http://twitter.com/AskTheGoodAgent/statuses/96872164069871616">1 day ago</a></li></ul></div>
			<div id="news_signup_cntr">
				<form action="http://www.thegoodagent.ie/properties/sales" method="post">
<input name="form_name" value="newsletter_signup" type="hidden">
<input name="email_address" value="Sign Up For Our Newsletter" maxlength="100" size="25" id="newsletter_input" type="text"><input name="email_submit" value="submit" id="newsletter_submit" type="submit"></form>			
			</div>			
		</div>
		<div class="clear"></div>
		<div class="footer_nts">
			<div class="terms"><a href="http://www.thegoodagent.ie/terms">Terms and Conditions</a>  - <a href="http://www.thegoodagent.ie/privacy">Privacy Policy</a> - All Rights Reseverved The Good Agent 2010 - Phone: 01-9020203</div>
			<div class="social">
				<a href="http://twitter.com/AskTheGoodAgent" id="twitter_btn" target="_blank"></a>
				<a href="http://www.facebook.com/TheGoodAgent" id="fbook_btn" target="_blank"></a>
				<a href="http://www.linkedin.com/company/1385349?trk=pro_other_cmpy" id="linkedin_btn"></a>
			</div>
			<div class="dandc"><a href="http://www.weareelevate.com/">Built by We Are Elevate</a></div>
			
		</div>
	</div>
</div>
<div class="clear"></div> 
<div id="ask_barry_cntr"><a href="http://www.thegoodagent.ie/askbarry?width=400&amp;height=480" id="ask_barry_btn" class="thickbox" title="close"></a></div>


<script type="text/javascript" src="estimator_files/zz_matt_VERSION2_db_form_functions.js"></script>


</body></html>