<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" lang="en">
    
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
	<link href="http://code.google.com/apis/maps/documentation/javascript/examples/default.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="//maps.googleapis.com/maps/api/js?sensor=false"></script>
	<script src="http://code.jquery.com/jquery-latest.js"></script>

<script type="text/javascript">

var dublin = new google.maps.LatLng(53.354983819697665, -6.287366142773401);
var marker;
var map;

function initialize() 
{
	var mapDiv = document.getElementById('map_canvas');
	var myOptions = 
	{
  		streetViewControl: false,
    	panControl: true,
		zoom: 12,
		center: dublin,
		mapTypeId: google.maps.MapTypeId.ROADMAP
	}
	
	map = new google.maps.Map(mapDiv, myOptions);
	
    $("#drop_pin_button").click( drop_pins );    
    $("#close_window_button").click( close_window );   
    
    window.setTimeout(drop_pins, 300); 
}
	
function drop_pins() 
{
	create_marker( dublin );
}

function close_window() 
{
	self.close ();
}

function create_marker( location )
{
	marker = new google.maps.Marker(
	{
		map:map,
		draggable:true,
		animation: google.maps.Animation.DROP,
		position: pin_location
	});
}

</script>
</head>

<body onload="initialize()">

<div>
	<input id="drop_pin_button" type="submit" value="drop pins on all properties"/>
	<input id="close_window_button" type="submit" value="(close this window)"/>
</div>
	<div	
		id="map_canvas" 
		style="width:100%; height:100%"
	>
	</div>

	
</body>
</html>

