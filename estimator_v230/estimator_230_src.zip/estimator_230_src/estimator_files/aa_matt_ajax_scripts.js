
// simple AJAX for DB retrieval

// global variable, so can have several functions
var g_xmlhttp;

//function ajax_build_and_send_http_request()
function version2_ajax_update_and_display_estimate()
{
	var lat = marker.getPosition().lat();
	var lng = marker.getPosition().lng();
	
	// (0)
	// retreive stored lat/lng
	
	// (1) 
	// create new XML HTTP object
	g_xmlhttp = create_ajax_object();
	
	// (2)
	// register event handler function for change of state 
	// (i.e. receipt of HTTP response from server)
	g_xmlhttp.onreadystatechange = process_http_response;

	// (3)
	// create GET message
	var script = "estimator_files/aa_matt_ajax_match_property.php";
	var query_string = build_query_string(lat, lng);
	var url = script + query_string;
	g_xmlhttp.open("GET", url, true);
	
	// (4)
	// send the HTTP GET message
	g_xmlhttp.send();
	
}


// process the http response
function process_http_response()
{
	if (g_xmlhttp.readyState==4 && g_xmlhttp.status==200)
	{
		var returned_text = g_xmlhttp.responseText;

		var value_array = returned_text.split(";");

		var min_asking_price = value_array[1];
		var max_asking_price = value_array[3];
		var min_rent = value_array[5];
		var max_rent = value_array[7];
		var estimate_confidence = value_array[9];
		
		// (and remove / change form warningmessage/ updating msg)
		version2_update_display_estimate_values( min_asking_price, max_asking_price, min_rent, max_rent, estimate_confidence);

		var nice_text = render_info( value_array );
		$("#debug_info").html( nice_text );
		
	}
}



/**
 * send new property details to the PHP script that will add the details to the Database
 */
function ajax_submit_new_property_to_database()
{
	var lat = marker.getPosition().lat();
	var lng = marker.getPosition().lng();
	
	// (0)
	// retreive stored lat/lng
	
	// (1) 
	// create new XML HTTP object
	g_xmlhttp = create_ajax_object();
	
	// (2)
	// register event handler function for change of state 
	// (i.e. receipt of HTTP response from server)
	g_xmlhttp.onreadystatechange = process_http_response_after_db_submit;

	// (3)
	// create GET message
	var script = "estimator_files/aa_matt_ajax_add_property_to_db.php";
	var query_string = build_extended_query_string(lat, lng);
	var url = script + query_string;

	g_xmlhttp.open("GET", url, true);

	// (4)
	// send the HTTP GET message
	g_xmlhttp.send();
	
}


// process the http response process_http_response_after_db_submit
function process_http_response_after_db_submit()
{
	if (g_xmlhttp.readyState==4 && g_xmlhttp.status==200)
	{
		var db_update_status = g_xmlhttp.responseText;

		
/*
		// open up pin dropper page
		var window_reference = window.open("estimator_files/aa_matt_property_pin_dropper.php","pin_dropper_window");
		var pin_location = marker.position;
        if(!window_reference.pin_location){ window_reference.pin_location = pin_location; }

		var nice_text = render_info_all(value_array );
		$("#debug_info").html( nice_text );
				
		//alert(nice_text);	
*/
		// display user message about DB update success
		display_db_update_success_message(db_update_status);

		// reset menus, so display is ready for another property
		reset_menus();
		
		// move marker to dublin
		marker.setPosition( dublin );
		
		// process new marker position
		version2_process_new_marker_position();
		
		// update message window for reset page
		version2_update_display();

	}
	
}

function display_db_update_success_message( result )
{

if( result.length > 1 )
{
	// must have some debugging text inside it ...
	var message_array = result.split(";");
	result = message_array[0];
	
//	alert( message_array );
}
	
	var message = "sorry - there was an unexpected message when trying to add property details to historic database";
	if( result > 0)
	{
		message = "SUCCESS - new property added to database";
	}
	else
	{
		message = "ERROR - there was a problem when trying to add the new property details to the database";
	}
	
	alert( message );
}

function reset_menus()
{
	$("#search_property_type_option").val( 0 );
	$("#bedrooms").val( 0 );
	$("#bathrooms").val( 0 );
	$("#valuation_month").val( 0 );;
}


function render_info_all(info_string_array )
{
	var newline = "<br/>";
	var html = "";
	
	for(var i = 0; i < info_string_array.length; i++)
	{
		html += info_string_array[i];
		
		if( i % 2)
		{
			html += newline;
		}
	
	}
	
	return html;
}

// break down info text into HTML easy to read
function render_info(info_string_array )
{
	var newline = "<br/>";
	var html = "";
	
	for(var i = 8; i < info_string_array.length; i++)
	{
		html += info_string_array[i];
		
		if( i % 2)
		{
			html += newline;
		}
	
	}
	
	return html;
}



// return appropriate HTTP object, depending on user agent/browser
function create_ajax_object()
{
	if (window.XMLHttpRequest)
	{
		// code for IE7+, Firefox, Chrome, Opera, Safari
		return new XMLHttpRequest();
	}
	else
	{
		// code for IE6, IE5
		return new ActiveXObject("Microsoft.XMLHTTP");
	}

}

// extract values for form to build up the query string
function build_extended_query_string(lat, lng)
{
	var query_string = build_query_string(lat, lng);

	// get type of value (rent / asking / selling)
//	var value_type = $("#asking_price_or_rent_radio").val();
// NOTE - cannot use ID since 3 different elements - 1 for each radio button alternative
	var value_type = $('input:radio[name=value_type]:checked').val();

// get historic valuation MONTH
//	var value_type = $("#value_type").val();
	
	// get historic valuation figure
	var historic_value = $("#historic_value").val();
	
	// get historic valuation MONTH
	var valuation_month = $("#valuation_month").val();
	
	// add details to qiuery srteing
	query_string += "&valuation_month=" + valuation_month;
	query_string += "&value_type=" + value_type;
	query_string += "&historic_value=" + historic_value;
	query_string += "&value_type=" + value_type;

	return query_string;
}

// extract values for form to build up the query string
function build_query_string(lat, lng)
{
	// get values from form
	var county_id = $("#search_county_option").val();
	var property_type_id = $("#search_property_type_option").val();
	var bedrooms = $("#bedrooms").val();
	var bathrooms = $("#bathrooms").val();
	var central_heating = 0;
	if($('#central_heating:checked').val() !== undefined) 
	{
		central_heating = 1;
	}
	var conservatory = 0;
	if($('#conservatory:checked').val() !== undefined) 
	{
		conservatory = 1;
	}
	var parking = 0;
	if($('#parking:checked').val() !== undefined) 
	{
		parking = 1;
	}
	var kitchen_new = 0;
	if($('#kitchen_new:checked').val() !== undefined) 
	{
		kitchen_new = 1;
	}
	var conversion = 0;
	if($('#conversion:checked').val() !== undefined) 
	{
		conversion = 1;
	}

	//
	var q_string = "";
	q_string += "?lat=" + lat;
	q_string += "&lon=" + lng;
	q_string += "&county_id=" + county_id;	
	q_string += "&property_type_id=" + property_type_id;	
	q_string += "&bedrooms=" + bedrooms;	
	q_string += "&bathrooms=" + bathrooms;	
	q_string += "&central_heating=" + central_heating;	
	q_string += "&conservatory=" + conservatory;	
	q_string += "&kitchen_new=" + kitchen_new;	
	q_string += "&conversion=" + conversion;	
	q_string += "&parking=" + parking;		

	return q_string;
}
