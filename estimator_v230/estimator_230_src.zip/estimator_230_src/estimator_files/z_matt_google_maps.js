


////////////////
//            //
// section 0  //
//            //
////////////////////////////////////////////////////////////
//////// functions in this section need further work ///////
////////////////////////////////////////////////////////////

function extract_town_id_from_string( town_name_string )
{
//alert("town_name_string = '" + town_name_string + "'");	
	
	// need to lookup town name in the big array !
	var town_id = find_town_id( town_name_string );
	
	// for now just say we can't find it !
	return town_id;
}

/**
given a town name string, and assuming county menu is set to correct county
attempt to identify the town_id of the given town name

NOTE - only attempt if town_name > MIN_TOWN_NAME_LENGTH
*/
function find_town_id( town_name )
{
	var town_id = -1;

	var county_id = $("#search_county_option").val();
	var town_name_array = estimator_town_array[county_id];
	
	if( isset( town_name_array ) )
	{
		town_id = find_string( town_name, town_name_array);
	}
	
	return town_id;	
}


/**
attempt to locate given string in element 0 of given array
*/
function find_string( town_name, town_name_array)
{
	var town_id = -1;

	for(var i = 0; i < town_name_array.length; i++)
	{
		if( town_name == town_name_array[i][0])
		{
			town_id = i;
			break;
		}		
	}
	
	return town_id;
}

////////////////
//            //
// section 1  //
//            //
////////////////////////////////////////////////////////////
//////// start of completed production code          ///////
////////////////////////////////////////////////////////////

var geocoder = new google.maps.Geocoder();

var chicago = new google.maps.LatLng(41.850033, -87.6500523);
var dublin = new google.maps.LatLng(53.354983819697665, -6.287366142773401);

var map;
var infowindow = new google.maps.InfoWindow();
var marker;


function version2_process_new_marker_position()
{
		// (1) record that it is a COMPUTER about to change county / town menus
		stored_actor = ACTOR_COMPUTER;

		// (2) geocode (+ update county /town menus)
		geocode_current_marker_position();
	    
		// (3) update display (get and show new estimate, if all required features chosen)
		version2_update_display();	
}

function initialize() 
{
	var mapDiv = document.getElementById('map_canvas');
	var myOptions = 
	{
  		streetViewControl: false,
    	panControl: true,
		zoom: 12,
		center: dublin,
		mapTypeId: google.maps.MapTypeId.ROADMAP
	}
	
	map = new google.maps.Map(mapDiv, myOptions);
	
//    createDragbableMarker( map.getCenter() );
	  marker = new google.maps.Marker({
	    position: map.getCenter(),
	    title: 'Property',
	    map: map,
	    draggable: true
	  });   
  
	google.maps.event.addListener(marker, 'dragend', version2_process_new_marker_position );

/*
	google.maps.event.addListener(marker, 'dragend', function() 
	{
		// (1) record that it is a COMPUTER about to change county / town menus
		stored_actor = ACTOR_COMPUTER;

		// (2) geocode (+ update county /town menus)
		geocode_current_marker_position();
	    
		// (3) update display (get and show new estimate, if all required features chosen)
		version2_update_display();	
	});
*/
   	// INFO PANEL UPDATE
   	// INFO PANEL UPDATE
   	// INFO PANEL UPDATE
   	// INFO PANEL UPDATE
	  // Update current position info.
	geocode_current_marker_position();

}  


function orient_to_new_center( new_google_maps_latlong )
{
	map.setCenter(new_google_maps_latlong);
	move_marker_to_center2();
	
}



function move_marker_to_center2()
{
	// reposition marker to center of map
	marker.setPosition( map.getCenter() );
	
	// now process this new marker position
	version2_process_new_marker_position();
}

/**
fn update_MAP_POSITION(new lat / new long)

1 - address box = (updating map ...)
2 - recenter map - for new co-ordinates
3 - get MAP location and STORE lat/long in JS globals
4 - move marker
5 - geocode new location
6 - update address bar(new address) - but don't then change county / town - since this methdo may be called by county/town change?

*/
function version2_update_MAP_POSITION( new_google_maps_latlong )
{
//alert("z_matt_google_maps.js :: calling :: version2_update_MAP_POSITION() ")
	
    map.setCenter(new_google_maps_latlong);
    marker.setPosition( new_google_maps_latlong );
}

////////////////////////
function county_center( county_id )
{
	var latlong_data_row = county_latlong[county_id];
	return google_maps_latlong( latlong_data_row );

}


function process_geocode_responses(responses) 
{
	if (responses && responses.length > 0) 
	{
		extract_and_update_county_town_menus( responses[0].formatted_address );
	} 
}

// update position event handlers
function geocode_current_marker_position() 
{
	var pos = marker.getPosition();
	
	geocoder.geocode({ latLng: pos }, process_geocode_responses );
}


// matt woz ere ... revisit this function & the one above...
// NOTE - perhaps remove this function and use toFixed
//
// var x = 2.31;
// var s  = x.toFixed()    // result: '2'
function number_format( n, dp )
{
	if( isNaN( parseFloat( n ) ) )
		return n;
	else 
		return parseFloat( n ).toFixed(dp);
}


/**
remove all leading and training spaces
e.g. "    hello world   " >> "hello world"
*/
function alltrim(str) 
{
	return str.replace(/^\s+|\s+$/g, '');
}


/**
give address string, attempt to identify county name, and then update county menu on form
if able to find county, then also try to find town name in address, and update that menu correspondingly
*/
function extract_and_update_county_town_menus( address_string ) 
{
	// remove ", Ireland" from address string
	address_string = address_string.replace(", Ireland", "");

	// get the last 2 phrases from the address
	// e.g. "53 main street, Leixlip, Co. Kildare"
	// county name = "Co. Kildare"
	// town name = "Leixlip"
	var phrases = address_string.split(',');
	phrases = phrases.reverse();
	
	var county_name = "** dummy text **";
	var town_name = "** dummy text **";

	if( phrases.length > 0)
	{
		county_name = phrases[0];
		county_name = alltrim( county_name );
	}

	// try to identify county name
	var extracted_county_id = extract_county_id_from_string( county_name );
	if( extracted_county_id > -1 )
	{
		// (1) set menu to COUNTY id 
		$("#search_county_option").val( extracted_county_id );
		
		// (2) load town list for new county >>>>>> should happen anyway ...
		update_town_list_from_county_id();
		
		// (3) since we found county, now also try to find town in the address
		if( phrases.length > 1)
		{
			town_name = phrases[1];
			town_name = alltrim( town_name );
			extract_and_update_town_menu( town_name );
		}
	}
}

/**
give address string, attempt to identify TOWN name, and then update corresponding menu on form
*/
function extract_and_update_town_menu( town_name ) 
{
	// try to identify county name
	var extracted_town_id = extract_town_id_from_string( town_name );
	if( extracted_town_id > -1 )
	{
		$("#search_town_option").val( extracted_town_id );
	}
}


/**
given a county name string (e.g. "Co. Kildare") try to locate the county_id from the PHP generated array
*/

function extract_county_id_from_string( county_name )
{
	var id = -1;
	var temp_id = google_county_array[ county_name ];

	// test whether valid array refefrence found
	if( temp_id != undefined )
	{
		id = temp_id;
	}
	
	return id;
}

/**
given an address string,
*/
function phrase_after_last_comma( short_address )
{
	var words = short_address.split(',');
	var last_index = (words.length - 1);
	var phrase = words[ last_index ];
	return phrase;
}



function contains_comma( s )
{
	// if location of char in string is NOT -1, then it was found
	return (s.indexOf(",") > -1);
}

function code_address() 
{
	// get address
	var address = document.getElementById("address").value;
	

	
	// clear the form field
	document.getElementById('address').value = "";
	
	// process the address
	if( "" != address)
	{
		address += ", Ireland";
		alert("contacting Google Maps to try to locate the address: " + address + "\n (depending on internet connection speed there may be a short delay)");
		
		geocoder.geocode( { 'address': address}, function(results, status) 
			{
			if (status == google.maps.GeocoderStatus.OK) 
			{
				var new_google_maps_latlong = results[0].geometry.location;
				orient_to_new_center( new_google_maps_latlong );
	   		} 
			else
			{
				alert("Sorry, Google Maps did not find a location matching the typed address");
			}
		});
	}
}

