<?php

// first thing always - ensure session continued (or new one started)
session_start(); 

// redirect to PUBLIC home page
$redirect_page = "DISPLAY_login.php";

// ***********************
// *** LOGIC - logout by setting:
// ***  (a) - SESSION username to NULL
// ***  (b) - $is_logged_in to FALSE
// ***********************
$_SESSION["login_username"] = NULL;
$is_logged_in = FALSE;

// ***********************
// *** REDIRECT to another page
// ***********************
// redirect browser back to login page
header("Location: $redirect_page");

?>