<?php
//------------------------------------------------------
// (1) prep - start session and set defaults to error ...
//------------------------------------------------------

//
// first thing always - ensure session continued (or new one started)
session_start();

// default to error page
$redirect_page = "DISPLAY_error.php";

// get name of this file
$thisPage = $_SERVER['PHP_SELF'];
$filename = ltrim(strrchr($thisPage, '/'), '/');

// default error message is unknown error from this page!
$error_message = "unkown error - source 'filename'";
$_SESSION["error_message"] = $error_message;

// check whether user already logged in ...
require_once("SECURE_INCLUDE_check_login_status.php");

// load classes
require_once("../classes/class_loader.php");

//------------------------------------------------------
// (2) error redirect if not logged in ...
//------------------------------------------------------

//
// IF
//		NOT logged in
// THEN
//		NOT AUTHORISED to view this page !
//		redirect with error message
//
if( TRUE != $is_logged_in )
{
	// ensure not logged in as anyone
	$_SESSION["login_username"] = NULL;

	// error message tells user bad username or password
	// and gives link to login again
	$error_message = "you are not authroised to view this page without first <a href='DISPLAY_login.php'>logging in ...</a>";
	$_SESSION["error_message"] = $error_message;
	
	//------------------------------------------------------
	// *** REDIRECT to another page
	//------------------------------------------------------
	header("Location: $redirect_page");
}

//------------------------------------------------------
// (3) display list of all CSO records
//------------------------------------------------------

// get connection to DB "$connection, $db"
require_once("../zz_matt_db_connect.php");

// note the use of "UNIX_TIMESTAMP(month)" to automatically convert from
// MySQL datetime into a Unix (i.e. PHP) datetime format
// so the converted date can now be easily maniptulated in PHP
$sql_query_string = "SELECT * FROM property_county_type ORDER BY id DESC";

// run query and store the "result set"
$rs = mysql_query($sql_query_string, $connection);

// error message if no result set from query ...
if( !$rs ) die( "ERROR: query did not return a result set: $sql_query_string");

$is_most_recent = TRUE;

$newline = "\n";
$html_string = "";
while( $row = mysql_fetch_assoc($rs) )
{
	$id = $row["id"];
	$county_name = $row["county_name"];
	$property_type = $row["type"];
	$asking_price = $row["asking_price"];
	$rent = $row["rent"];
	$bedrooms = $row["bedrooms"];
	$bathrooms = $row["bathrooms"];
	$bedrooms = $row["bedrooms"];
	$parking = $row["parking"];
	$conversion = $row["conversion"];
	$kitchen_new = $row["kitchen_new"];
	$conservatory = $row["conservatory"];
	$central_heating = $row["central_heating"];
	$valuation_month = $row["valuation_month"];
	
	$month = Property::get_month_from_year_month_string( $valuation_month );
	$month_name = Property::month_name( $month );
	$year = Property::get_year_from_year_month_string( $valuation_month );
	$formatted_month = "$month_name $year ($valuation_month)";
	
	$html_string .= "<tr>";

	$html_string .= $newline;
	$html_string .= "<td>";
	$html_string .= $newline;
	$html_string .= "<a href='SECURE_DISPLAY_property_confirm_delete.php?id=$id'>";
	$html_string .= $newline;
	$html_string .= "DELETE";
	$html_string .= $newline;
	$html_string .= "</a>";
	$html_string .= $newline;
	$html_string .= "</td>";
	$html_string .= $newline;

	$html_string .= "<td>$id</td>";
	$html_string .= $newline;
	$html_string .= "<td>";
	$html_string .= "$formatted_month";
	$html_string .= "</td>";
	$html_string .= $newline;
	$html_string .= "<td>$county_name</td>";
	$html_string .= $newline;
	$html_string .= "<td>$property_type</td>";
	$html_string .= $newline;
	$html_string .= "<td>$asking_price</td>";
	$html_string .= $newline;
	$html_string .= "<td>$rent</td>";
	$html_string .= $newline;
	$html_string .= "<td>$bedrooms</td>";
	$html_string .= $newline;
	$html_string .= "<td>$bathrooms</td>";
	$html_string .= $newline;
	$html_string .= "<td>$parking</td>";
	$html_string .= $newline;
	$html_string .= "<td>$conversion</td>";
	$html_string .= $newline;
	$html_string .= "<td>$kitchen_new</td>";
	$html_string .= $newline;
	$html_string .= "<td>$central_heating</td>";
	$html_string .= $newline;
	$html_string .= "<td>$conservatory</td>";
	$html_string .= $newline;
	$html_string .= "</tr>";
	$html_string .= $newline;

}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <meta http-equiv="content-type" content="text/xml; charset=utf-8" />
    
	<title>The Good Agent - estimator -  admin - Property list</title>

	<style type="text/css">
		td
		{
			width: 100px;
			text-align: center;
		}
	</style>
</head>
<body>

<p style="float: right; width: 250px">
	You are logged in as 
	<strong>
	
	<?php
	// --------------- PHP start ----------------
		print $login_username;
	// --------------- PHP end  -----------------
	?>	
	</strong>
	<br/>
	do you wish to <a href="SECURE_LOGIC_logout.php">logout? </a> 
</p>

<p>
<strong>
The Good Agent - estimator -  admin 
</strong>

</br>

<a href="SECURE_DISPLAY_cso.php">
CSO listing 
</a>
|
Property listing
</p>


<hr style="clear: both"/>
<!-- ****************************** HR ******************* -->
<table border="1">
	<caption>
	Estimator Property DB contents
	</caption>

	<tr>
		<th>(ACTION)</th>
		<th>id</th>
		<th>valuation month</th>
		<th>region <br/>(county)</th>
		<th>type</th>
		<th>asking price</th>
		<th>rent <br/> (user added if NULL)</th>
		<th>bedrooms</th>
		<th>bathrooms</th>
		<th>off-street<br/> parking</th>
		<th>attic/loft<br/>conversion</th>
		<th>new</br>kitchen</th>
		<th>central</br>heating</th>
		<th>conservatory</th>
	</tr>
	

<?php
	// --------------- PHP start ----------------
	print $html_string;
	// --------------- PHP end  -----------------
?>

</table>

<!-- ****************************** HR ******************* -->
<hr/>
<p>
	You are logged in as 
	<strong>
	
	<?php
	// --------------- PHP start ----------------
		print $login_username;
	// --------------- PHP end  -----------------
	?>	
	</strong>
	<br/>
	do you wish to <a href="SECURE_LOGIC_logout.php">logout? </a> 
</p>

</body>
</html>