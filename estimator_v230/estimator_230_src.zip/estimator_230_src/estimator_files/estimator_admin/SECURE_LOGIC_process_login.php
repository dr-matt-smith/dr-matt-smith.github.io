<?php
//------------------------------------------------------
// (1) prep - start session and set defaults to error ...
//------------------------------------------------------

//
// first thing always - ensure session continued (or new one started)
session_start();

// default to error page
$redirect_page = "DISPLAY_error.php";

// get name of this file
$thisPage = $_SERVER['PHP_SELF'];
$filename = ltrim(strrchr($thisPage, '/'), '/');

// default error message is unknown error from this page!
$error_message = "unkown error - source 'filename'";
$_SESSION["error_message"] = $error_message;

//------------------------------------------------------
// (2) get admin password, and also extract value user entered
//------------------------------------------------------
//
// load classes, and retreive CSO ADMIN password text
require_once("../classes/class_loader.php");
$correct_username = Parameters::ADMIN_USERNAME;
$correct_password = Parameters::ADMIN_PASSWORD;

//
// get password from USER form data
//
$user_entered_password = "";
if( filter_has_var(INPUT_POST, "password") ) 
{
	$user_entered_password = filter_input(INPUT_POST, "password");
}	

//
// get username from USER form data
//
$user_entered_username = "";
if( filter_has_var(INPUT_POST, "username") ) 
{
	$user_entered_username = filter_input(INPUT_POST, "username");
}	

//
// if bad password or username, redirect to error page
// else set redirect to display page, and store data in session
//
$isValid_username = ( $user_entered_username == $correct_username );
$isValid_password = ( $user_entered_password == $correct_password );

if( $isValid_username && $isValid_password)
{
	// login successful
	//
	// store username in SESSION variable
	$_SESSION["login_username"] = $correct_username;

	// redirect to SECURE admin home page
	$redirect_page = "SECURE_DISPLAY_cso.php";
}
else
{
	// ensure not logged in as anyone
	$_SESSION["login_username"] = NULL;

	// error message tells user bad username or password
	// and gives link to login again
	$error_message = "bad username or password, try again: <a href='DISPLAY_login.php'>admin login</a>";
	$_SESSION["error_message"] = $error_message;
}

//------------------------------------------------------
// *** REDIRECT to another page
//------------------------------------------------------
header("Location: $redirect_page");
?>