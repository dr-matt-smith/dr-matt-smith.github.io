<?php
//------------------------------------------------------
// (1) prep - start session and set defaults to error ...
//------------------------------------------------------

//
// first thing always - ensure session continued (or new one started)
session_start();

// default to error page
$redirect_page = "DISPLAY_error.php";

// get name of this file
$thisPage = $_SERVER['PHP_SELF'];
$filename = ltrim(strrchr($thisPage, '/'), '/');

// default error message is unknown error from this page!
$error_message = "unkown error - source 'filename'";
$_SESSION["error_message"] = $error_message;

// check whether user already logged in ...
require_once("SECURE_INCLUDE_check_login_status.php");

// load classes
require_once("../classes/class_loader.php");

//------------------------------------------------------
// (2) error redirect if not logged in ...
//------------------------------------------------------

//
// IF
//		NOT logged in
// THEN
//		NOT AUTHORISED to view this page !
//		redirect with error message
//
if( TRUE != $is_logged_in )
{
	// ensure not logged in as anyone
	$_SESSION["login_username"] = NULL;

	// error message tells user bad username or password
	// and gives link to login again
	$error_message = "you are not authroised to view this page without first <a href='DISPLAY_login.php'>logging in ...</a>";
	$_SESSION["error_message"] = $error_message;
	
	//------------------------------------------------------
	// *** REDIRECT to another page
	//------------------------------------------------------
	header("Location: $redirect_page");
}

//------------------------------------------------------
// (3) display list of all CSO records
//------------------------------------------------------

// get connection to DB "$connection, $db"
require_once("../zz_matt_db_connect.php");

// note the use of "UNIX_TIMESTAMP(month)" to automatically convert from
// MySQL datetime into a Unix (i.e. PHP) datetime format
// so the converted date can now be easily maniptulated in PHP
$sql_query_string = "SELECT * FROM `cso_rppi` ORDER BY `year_month` DESC";

// run query and store the "result set"
$rs = mysql_query($sql_query_string, $connection);

// error message if no result set from query ...
if( !$rs ) die( "ERROR: query did not return a result set: $sql_query_string");

$is_most_recent = TRUE;

$newline = "\n";
$html_string = "";
while( $row = mysql_fetch_assoc($rs) )
{
	$id = $row["id"];
	$year_month = $row["year_month"];
	$dublin = $row["dublin"];
	$national = $row["national"];
	
	$month = Property::get_month_from_year_month_string( $year_month );
	$month_name = Property::month_name( $month );
	$year = Property::get_year_from_year_month_string( $year_month );
	$formatted_month = "$month_name $year ($year_month)";
	
	$html_string .= "<tr>";

	$html_string .= $newline;
	$html_string .= "<td>";
	$html_string .= $newline;
	$html_string .= "<a href='SECURE_DISPLAY_cso_confirm_delete.php?id=$id'>";
	$html_string .= $newline;
	$html_string .= "DELETE";
	$html_string .= $newline;
	$html_string .= "</a>";
	$html_string .= $newline;
	$html_string .= "</td>";
	$html_string .= $newline;

	$html_string .= "<td>$id</td>";
	$html_string .= $newline;
	$html_string .= "<td>";
	$html_string .= "$formatted_month";
	$html_string .= "</td>";
	$html_string .= $newline;
	$html_string .= "<td>$dublin</td>";
	$html_string .= $newline;
	$html_string .= "<td>$national</td>";
	$html_string .= $newline;
	$html_string .= "</tr>";
	$html_string .= $newline;
	
	if( $is_most_recent )
	{
		$is_most_recent = FALSE;
		$most_recent_year_month = $year_month;
	}
}

//------------------------------------------------------
// (4) create special row for form to add data for the NEXT month
//------------------------------------------------------

//
// create strings for year and month, for max month + 1 month
//

	$next_year_month_string = Property::calc_next_year_month_string( $most_recent_year_month );
	
	$next_month = Property::get_month_from_year_month_string( $next_year_month_string );
	$next_month_name = Property::month_name( $next_month );
	$next_year = Property::get_year_from_year_month_string( $next_year_month_string );
	$next_year_formatted_month_string = "$next_month_name $next_year ($next_year_month_string)";
	
	$add_record_row_string = "<tr>";

	$add_record_row_string .= $newline;
	$add_record_row_string .= "<td colspan='2'>";
	$add_record_row_string .= $newline;
	$add_record_row_string .= "<form";
	$add_record_row_string .= $newline;
	$add_record_row_string .= "		name='login'";
	$add_record_row_string .= $newline;
	$add_record_row_string .= "		action='SECURE_LOGIC_cso_add_record.php'";
	$add_record_row_string .= $newline;
	$add_record_row_string .= "		method='POST'";
	$add_record_row_string .= $newline;
	$add_record_row_string .= "	/>";
	$add_record_row_string .= $newline;
	$add_record_row_string .= "	<input type='submit' value='Add new value to DB'/>";
	$add_record_row_string .= $newline;
	$add_record_row_string .= "<input type='hidden' name='year_month' value='$next_year_month_string'/>";
	$add_record_row_string .= $newline;
	$add_record_row_string .= "</td>";
	$add_record_row_string .= $newline;

	$add_record_row_string .= "<td><strong>$next_year_formatted_month_string</strong></td>";
	$add_record_row_string .= $newline;
	$add_record_row_string .= "<td><input type='text' name='dublin_percentage'/></td>";
	$add_record_row_string .= $newline;
	$add_record_row_string .= "<td><input type='text' name='national_percentage'/>";
	$add_record_row_string .= $newline;
	$add_record_row_string .= "</form>";
	$add_record_row_string .= $newline;
	$add_record_row_string .= "</td>";
	$add_record_row_string .= $newline;
	
	$add_record_row_string .= "</tr>";



?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <meta http-equiv="content-type" content="text/xml; charset=utf-8" />
    
	<title>The Good Agent - estimator -  admin - CSO list</title>

	<style type="text/css">
		td
		{
			width: 100px;
			text-align: center;
		}
	</style>
</head>
<body>
<p style="float: right; width: 250px">
	You are logged in as 
	<strong>
	
	<?php
	// --------------- PHP start ----------------
		print $login_username;
	// --------------- PHP end  -----------------
	?>	
	</strong>
	<br/>
	do you wish to <a href="SECURE_LOGIC_logout.php">logout? </a> 
</p>

<p>
<strong>
The Good Agent - estimator -  admin 
</strong>

</br>

CSO listing 
|
<a href="SECURE_DISPLAY_property.php">
Property listing
</a>
</p>

<hr style="clear: both"/>
<!-- ****************************** HR ******************* -->
<table border="1">
	<caption>
	CSO monthly property values
	<br/>
	(100% = 1 / Jan / 2005)
	</caption>

	<tr>
		<th>(ACTION)</th>
		<th>id</th>
		<th>month</th>
		<th>dublin</t>
		<th>national</th>
	</tr>
	
	<?php
		// --------------- PHP start ----------------
		print $add_record_row_string;
		// --------------- PHP end  -----------------
	?>
	
<?php
	// --------------- PHP start ----------------
	print $html_string;
	// --------------- PHP end  -----------------
?>

</table>

<!-- ****************************** HR ******************* -->
<hr/>
<p>
	You are logged in as 
	<strong>
	
	<?php
	// --------------- PHP start ----------------
		print $login_username;
	// --------------- PHP end  -----------------
	?>	
	</strong>
	<br/>
	do you wish to <a href="SECURE_LOGIC_logout.php">logout? </a> 
</p>

</body>
</html>