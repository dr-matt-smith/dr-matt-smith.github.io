<?php

// first thing always - ensure session continued (or new one started)
session_start();

require_once("SECURE_INCLUDE_check_login_status.php");

$error_message = $_SESSION["error_message"];

// ***********************
// *** LOGIC
// ***********************

// if no message in SESSION object then indicate unknown error
if( NULL == $error_message)
{
	$error_message = "unkown error - please contact system administrator";
}


// HTML code for a login form
$cso_link_html_string = <<<HERE
	
	<!-- ****************************** HR ******************* -->
	<hr/>

	<p>
		Return to the 
		<a href='SECURE_DISPLAY_cso.php'>
		CSO list of monthly records
		</a>
	</p>
HERE;

//--------------------------- end php ----------------------------
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <meta http-equiv="content-type" content="text/xml; charset=utf-8" />
    
	<title>The Good Agent - estimator -  admin - ERROR PAGE</title>
</head>

<body>

<h3>The Good Agent - estimator - admin - ERROR PAGE</h3>

<h1> ERROR detected </h1>

<p>
The following error has been detected...
</p>

<hr/>

<p>
	<!-- use PRE so can see line breaks in string ... -->
	<pre>
	
	<?php
		// --------------- PHP start ----------------
		print $error_message;
		// --------------- PHP end  -----------------
	?>
	
	</pre>
</p>

	<?php
		// --------------- PHP start ----------------
		// provide link to CSO list, if user is logged in ...
		if( $is_logged_in )
		{
			print $cso_link_html_string;
		}
		// --------------- PHP end  -----------------
	?>

	
</body>

</html>