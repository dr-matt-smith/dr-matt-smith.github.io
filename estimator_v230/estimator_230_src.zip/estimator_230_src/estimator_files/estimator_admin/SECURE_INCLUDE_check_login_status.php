<?php

//
// e.g. you'll see code like this in pages requireing logins:
//		if( TRUE == $is_logged_in )
//		{
//			<actions to do if logged in>
//		}
//
//--------- about this script -------

// ********************  authentication PHP  *************************

// ********************  authentication PHP  *************************


// assume not logged in by default
$is_logged_in = FALSE;
$login_username = null;

// IF
//      a variable "username" is found inside $_SESSION
// THEN
//      set flag to indicated logged in & store username
if(isset($_SESSION["login_username"]))
{
	$is_logged_in = TRUE;
	$login_username = $_SESSION["login_username"];
}

?>