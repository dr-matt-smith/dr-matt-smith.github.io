<?php
// load classes
require_once("classes/class_loader.php");

// get connection to DB "$connection, $db"
require_once("zz_matt_db_connect.php");

// create SQL query string
$query = "SELECT * FROM county ORDER BY menu_sequence";

// run query and store the "result set"
$rs = mysql_query($query, $connection);

// error message if no result set from query ...
if( !$rs ) die( "ERROR: query did not return a result set: $query");

//  loop for each row, building up "message" string
$newline = "\n";
$google_county_array_string = "google_county_array =  new Array();";
$google_county_array_string .= $newline;
while( $row = mysql_fetch_assoc($rs) )
{
	$region_id = $row["region_id"];
	$google_county_name =  $row["google_maps_county_name"];
	$google_county_array_string .= "google_county_array['$google_county_name'] = '$region_id';";
	$google_county_array_string .= $newline;
}

// housekeeping - close DB connection
mysql_close($connection);

//print "<html><head></head><body><script type='text/javascript'>";
//print "alert('hello world');";

print $google_county_array_string;
?>
