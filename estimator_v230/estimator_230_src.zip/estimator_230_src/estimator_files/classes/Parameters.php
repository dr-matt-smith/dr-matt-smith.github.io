<?php

/*
-------------------------------------------
--------------------------------------------
NOTE 1 - asking price adjustment factors based on property features:
-------------------------------------------
--------------------------------------------

Loft/attic conversion: +21%
No central heating: -7%
Parking: +6%
New kitchen: +4%
Conservatory: +4.5%
Additional bedroom (useful if we don't have a property that has exactly the same number of bedrooms as the searched property): +6%
Additional bathroom (as above): +5%

*/

/*
-------------------------------------------
--------------------------------------------
NOTE 2 - DAFT PRICE ASSUMPTIONS & IMPACT ON USE OF DAFT AVERAGE PRICES
-------------------------------------------
--------------------------------------------

the values below are reflected in the constants prefixd: DAFT_ASSUMPTION_ADJUSTMENT_<feature>

** 1 ** "central heating" :: Assume 90% of houses have this feature
IMPACT ON VALUATION:
IF (HAS feature) THEN
	increase daft price by 10% of the increase for this factor
ELSE (if feature MISSING)
	reduce Daft average price by 90% of the increase for this factor

** 2 ** "Loft/attic conversion" :: Assume 10% of houses have this feature
IMPACT ON VALUATION:
IF (HAS feature) THEN
	increase daft price by 90% of the increase for this factor
ELSE (if feature MISSING)
	reduce Daft average price by 10% of the increase for this factor

** 3 ** "Parking" :: Assume 40% of houses have this feature
IMPACT ON VALUATION:
IF (HAS feature) THEN
	increase daft price by 60% of the increase for this factor
ELSE (if feature MISSING)
	reduce Daft average price by 40% of the increase for this factor

** 4 ** "New kitchen" :: Assume 25% of houses have this feature
IMPACT ON VALUATION:
IF (HAS feature) THEN
	increase daft price by 75% of the increase for this factor
ELSE (if feature MISSING)
	reduce Daft average price by 25% of the increase for this factor

** 5 ** "Conservatory" :: Assume 20% of houses have this feature
IMPACT ON VALUATION:
IF (HAS feature) THEN
	increase daft price by 80% of the increase for this factor
ELSE (if feature MISSING)
	reduce Daft average price by 20% of the increase for this factor

** 6 ** "Additional bathroom" :: Assume 25% of houses have this feature
IMPACT ON VALUATION:
IF (HAS feature) THEN
	increase daft price by 75% of the increase for this factor
ELSE (if feature MISSING)
	reduce Daft average price by 25% of the increase for this factor




/**
-------------------------------------------
--------------------------------------------
CLASS: Parameters
VERSION: 1.0 (Sep 2011)
AUTHOR: Dr Matt Smith
class to store data of parameters effecting the matching algorithm

NOTE
All properties are public static - no instance every needed of this class

USAGE:
example, to retrieve INVESTMENT_YEARS for use in another script, write:
	Parameters::INVESTMENT_YEARS
e.g.
	$year_rent = ($price / Parameters::INVESTMENT_YEARS);

--------------------------------------------
--------------------------------------------
*/
class Parameters
{


//--------------------------------------------
// CLASS - CONSTANTS
//--------------------------------------------

/** the text username to access the admin functions */
const ADMIN_USERNAME = "myadmin";

/** the text password to access the admin functions */
const ADMIN_PASSWORD = "sell20cats";

/** latitude of Dublin center - for use to determine which CSO figure to use */
const DUBLIN_CENTER_LAT = 53.32599;

/** longitude of Dublin center - for use to determine which CSO figure to use */
const DUBLIN_CENTER_LON = -6.26765;

/** distance (Km) within which a property is considered in Dublin
- for use to determine which CSO figure to use */
const DUBLIN_CENTER_RADIUS = 10.0;

/** the percentage above which the Asking price is likely to be, over the final price the property was actually SOLD at 
e.g. if property sold for 5% less than asking price, then this constant would be 0.05, i.e. the asking price is 5% higher than final selling price
*/
const ASKING_PRICE_PROPORTION_ABOVE_SELLING_PRICE = 0.05;

/** number of years of investment - used to convert between asking price and monthly rental income */
const INVESTMENT_YEARS = 15;

/** this represents the distance (in Km), within which properties have maximum influence of the calculate of the estimate */
const NEIGHBOUR_RANGE = 0.5;

/** this represents the distance, beyond which properties will be ignored and which the Daft county average is considered just as accurate */
const MAX_RANGE = 2.0;

/** 
this represents the number of properties that, if available within NEIGHBOUR_RANGE, will be used exclusively to calculate the estimate 
(i.e. properties beyond NEIGHBOUR_RANGE, and also the Daft average, will be ignored)
*/
const DESIRABLE_NUM_VALUES_NEIGHBOUR_RANGE = 10;

/** 
this represents the number of properties within MAX_RANGE that, if avaialble, will be used exclusively to calculate the estimate 
(i.e. the Daft average, will be ignored)
NOTE - this only is considered if DESIRABLE_NUM_VALUES_NEIGHBOUR_RANGE has not been acheived (i.e. insufficient properties found within NEIGHBOUR_RANGE)
*/
const DESIRABLE_NUM_VALUES_MAX_RANGE = 30;

/**
the MINIMUM percentage confidence range (plus or minus) indicating how accurate the asking price average is beleived to be
NOTE: even in best case, where lots of 100% matching nearby properties are found, there should probably be SOME range suggested for asking price ... 
*/
const MIN_CONFIDENCE_INTERVAL = 5.0;

/**
the MAXIMUM percentage confidence range (plus or minus) indicating how accurate the asking price average is beleived to be
NOTE: in worst case (no properties found within MAX_DISTANCE) there is still the Daft average based on county and number of bedrooms
therefore it would seem to make sense to have a maximum confidence interval to prevent a near useless range being suggested by the estimator ...



NOTE - "var confidence" in "z_matt_calculations.js" should also be changed each time this paramter is changed - FIX via PHP sometime ...
*/
const MAX_CONFIDENCE_INTERVAL = 30.0;


/** the amount (percentage) the confidence range is increased for each property within NEIGHBOUR_RANGE than needed adjusting for addition bedrooms/bathrooms */
const BEDBATH_NEIGHBOUR_AJUST = 0.025;

/**
the amount (percentage) the confidence range is increased for each property within NEIGHBOUR_RANGE than needed adjusting for the other 5 features 
(i.e. not bed/bath)
*/
const FIVE_FEATURE_NEIGHBOUR_AJUST = 0.05;

/** the amount (percentage) the confidence range is increased for each property between NEIGHBOUR_RANGE and MAX_RANGE than needed adjusting for addition bedrooms/bathrooms
*/
const BEDBATH_MAX_RANGE_AJUST = 0.075;

/** 
the amount (percentage) the confidence range is increased for each property between NEIGHBOUR_RANGE and MAX_RANGE than needed adjusting for the other 5 features 
(i.e. not bed/bath)
*/
const FIVE_FEATURE_MAX_RANGE_AJUST = 0.1;

/**
the extra weighting (multiple) given to nearby properties, as opposed to those between NEIGHTBOUR_RANGE and the MAX_RANGE to consider
e.g. a value of 3 means nearby properties influcence the estimate 3 times more than those further away
*/
const NEIGHBOUR_WEIGHTING = 3.0;

/**
this represents how the weighting for a property is reduced for EACH feature which did not match fully
- perhaps this is too broadh .. it could easily be more focused
*/
const WEIGHTING_REDUCTION_FOR_ADJUST = 0.03;

/** 
increase in asking price for each additional bedroom 
e.g. 6% = 0.06
*/
const ADDITIONAL_BEDROOM = 0.06;

/** 
increase in asking price for each additional bathroom 
e.g. 6% = 0.06
*/
const ADDITIONAL_BATHROOM = 0.05;

/** 
percentage of Daft houses assumed to have this feature: ADDITIONAL_BATHROOM
*/
const DAFT_ASSUMPTION_ADJUSTMENT_ADDITIONAL_BATHROOM = 0.15;

/** 
number of bedrooms at which a SECOND bathroom is considered NORMAL
NOTE - systems only allows for 1-5 bedrooms and bathrooms
*/
const NUM_BEDROOMS_NEEDING_BATHROOM_NUMBER_2 = 4;

/** 
number of bedrooms at which a THIRD bathroom is considered NORMAL
NOTE - systems only allows for 1-5 bedrooms and bathrooms
*/
const NUM_BEDROOMS_NEEDING_BATHROOM_NUMBER_3 = 6;


/** 
increase in asking price for parking over no parking
e.g. 6% = 0.06
*/
const PARKING = 0.06;

/** 
percentage of Daft houses assumed to have this feature: PARKING
*/
const DAFT_ASSUMPTION_ADJUSTMENT_PARKING = 0.40;


/** 
increase in asking price for new kitchen over old kitchen
e.g. 6% = 0.06
*/
const KITCHEN_NEW = 0.04;

/** 
percentage of Daft houses assumed to have this feature: KITCHEN_NEW
*/
const DAFT_ASSUMPTION_ADJUSTMENT_KITCHEN_NEW = 0.25;

/** 
increase in asking price for conversion over conversion
e.g. 6% = 0.06
*/
const CONVERSION = 0.21;

/** 
percentage of Daft houses assumed to have this feature: CONVERSION
*/
const DAFT_ASSUMPTION_ADJUSTMENT_CONVERSION = 0.10;


/** 
increase in asking price for conservatory over conservatory
e.g. 6% = 0.06
*/
const CONSERVATORY = 0.045;

/** 
percentage of Daft houses assumed to have this feature: CONSERVATORY
*/
const DAFT_ASSUMPTION_ADJUSTMENT_CONSERVATORY = 0.10;

/** 
increase in asking price for central heating over no central heating
e.g. 6% = 0.06
*/
const CENTRAL_HEATING = 0.07;

/** 
percentage of Daft houses assumed to have this feature: CENTRAL_HEATING
*/
const DAFT_ASSUMPTION_ADJUSTMENT_CENTRAL_HEATING = 0.90;

/**
this value represents the amount (percentage) to add to the confidence interval for EACH historical property used in the calculation that has a single step difference in TYPE of property 
(see property type list 1 - 4 in Part 5)
*/
const PROPERTY_TYPE_1_STEP_ADJUST = 0.01;
	
/**
this value represents the amount (percentage) to add to the confidence interval for EACH historical property used in the calculation that has a 2 steps difference in TYPE of property 
(see property type list 1 - 4 in Part 5)
*/
const PROPERTY_TYPE_2_STEP_ADJUST = 0.03;
	
/**
this value represents the amount (percentage) to add to the confidence interval for EACH historical property used in the calculation that has a 3 steps difference in TYPE of property 
(see property type list 1 - 4 in Part 5)
*/
const PROPERTY_TYPE_3_STEP_ADJUST = 0.05;

/**
this value represents the amount (percentage) to increase/decrease to the estimated asking price for EACH historical property used in the calculation that has a single step difference in TYPE of property 
(see property type list 1 - 4 in Part 5)

e.g.
a value of 0.02 indicates that:
an historical property that is 1 TYPE less desirable than the user's property type will be valued 2% lower than were it the same property type
*/
const PROPERTY_TYPE_1_STEP_PRICE_DIFF = 0.02;

/**
this value represents the amount (percentage) to increase/decrease to the estimated asking price for EACH historical property used in the calculation that has 2 steps difference in TYPE of property 
(see property type list 1 - 4 in Part 5)
*/
const PROPERTY_TYPE_2_STEP_PRICE_DIFF = 0.04;

/**
this value represents the amount (percentage) to increase/decrease to the estimated asking price for EACH historical property used in the calculation that has 3 steps difference in TYPE of property 
(see property type list 1 - 4 in Part 5)
*/
const PROPERTY_TYPE_3_STEP_PRICE_DIFF = 0.06;


/**
this value represents the proportion of found properties within Neighbout or Max range, for which the system is to present a HIGH confidence of the estimate

e.g. if the value is 0.5, then this indicates that if 50% or more of the desired number of Neighbour or Max-range properties have been found, then the user should see an estimate confidence indication of HIGH
*/
const IN_RANGE_PROPORTION_HIGH = 0.30;

/**
this value represents the proportion of found properties within Neighbout or Max range, for which the system is to present a MEDIUM confidence of the estimate

e.g. if the value is 0.25, then this indicates that if 25% or more of the desired number of Neighbour or Max-range properties have been found, then the user should see an estimate confidence indication of MEDIUM

NOTE
There is no value for LOW, since if less than this medium value, that implies the user should see an estimate confidence indication of LOW
*/
const IN_RANGE_PROPORTION_MEDIUM = 0.10;



} // class

?>