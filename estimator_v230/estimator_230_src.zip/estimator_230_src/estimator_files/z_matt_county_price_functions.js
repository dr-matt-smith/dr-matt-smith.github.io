
//
// //////////////// CALCULATIONS /////////// county price & county price rooms
//

/** give county and number of rooms, return DAFT average price */
function daft_price_county_rooms( c, r )
{
	return county_prices[ c ][ r ];
}

/** give county only, return DAFT average price */
function daft_price_county_average( c )
{

	var temp = "";
	temp += "county_prices[ c ][ 1 ] = '";
	temp += county_prices[ c ][ 1 ];
	temp += "'";

	room1 = county_prices[ c ][1];
	room2 = county_prices[ c ][2];
	room3 = county_prices[ c ][3];
	room4 = county_prices[ c ][4];
	room5 = county_prices[ c ][5];

	county_price_avg = (room1 + room2 + room3 + room4 + room5) / 5;

	return Math.round(county_price_avg);
}


function price_array(p1, p2, p3, p4, p5)
{
	row = new Array(6);
	row[0] = 0;
	row[1] = p1;
	row[2] = p2;
	row[3] = p3;
	row[4] = p4;
	row[5] = p5;
	
	return row;
}


