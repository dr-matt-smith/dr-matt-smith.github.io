<?php

/**
--------------------------------------------
--------------------------------------------
CLASS: EstimatorManager
VERSION: 1.0 (Sep 2011)
AUTHOR: Dr Matt Smith
class to manage the estimation process - i.e. calcualte weighted average based nearby matching properties

--------------------------------------------
--------------------------------------------
*/
class EstimatorManager
{
	
//--------------------------------------------
// CLASS - CONSTANTS
//--------------------------------------------

const CASE_0_NO_MATCHES = 0;
const CASE_1_ALL_NEIGHBOURS = 1;
const CASE_2_ALL_MAX = 2;
const CASE_3_SOME_MAX = 3;

//--------------------------------------------
// PROPERTIES
//--------------------------------------------

/** collection of 2 property sets - neighbouring ones and ones between neighbour and MAX range */
private $referencePropertySets;

/** the property against which the reference sets are matched against */
private $property;

/** the price calculated from the DAFT report */
private $daft_asking_price;

/** the (algorithm) CASE that applies to the set of properties in the reference sets */
private $current_case;

/** average price calculated according to algorithm */
private $average_price;

/** confidence - percentage +/- as calculated by algorithm */
private $confidence;

/** the missing proportion if too few properties within MAX range */
private $missing_proportion;

/** the number of missing properties if too few properties within MAX range */
private $missing_proprties;

/** the in-MAX-range proportion */
private $in_range_proportion;

/** min-asking-price, given confidence */
private $min_asking_price = -1;

/** max-asking-price, given confidence */
private $max_asking_price = -1;

/** min-rent, given confidence */
private $min_rent = -1;

/** mxa-rent, given confidence */
private $max_rent = -1;

// *** debug variables ********
private $temp_string = "";
const SEPARATOR = ";"; 	

//--------------------------------------------
// METHODS - CONSTRUCTOR
//--------------------------------------------

public function __construct($referencePropertySets, $property, $county_id, $daft_asking_price)
{
// debugging
$this->temp_string = "";

	// store the reference sets & property
	$this->referencePropertySets = $referencePropertySets;
	$this->property = $property;
	$this->county_id = $county_id;
	
	// store the DAFT asking price
	$this->daft_asking_price = $daft_asking_price;
	
	// adjust the DAFT asking price (basd on parking, kitchen etc. factors)
	$this->adjust_daft_asking_price();
	
	// match against provided property
	$this->referencePropertySets->match($this->property);

	//------------------------------------------------------------
	// now process the properties collected ... and determine algorithm CASE
	$isSufficientNeighbourProperties = $this->referencePropertySets->isSufficientNeighbourProperties();
	$isSufficientMaxProperties = $this->referencePropertySets->isSufficientMaxProperties();
	
	if( $this->referencePropertySets->isSufficientNeighbourProperties() )
	{
		// case 1 - sufficient neighbour properties
		$this->current_case = EstimatorManager::CASE_1_ALL_NEIGHBOURS;
	}
	else if( $this->referencePropertySets->isSufficientMaxProperties() )
	{
		// case 2 - sufficient max properties
		$this->current_case = EstimatorManager::CASE_2_ALL_MAX;
	}
	else if( $this->referencePropertySets->getNumMaxProperties() > 0)
	{
		// case 3 - at least SOME max properties
		$this->current_case = EstimatorManager::CASE_3_SOME_MAX;
	}
	else
	{
		// default 0 no matches
		$this->current_case = EstimatorManager::CASE_0_NO_MATCHES;
	}
	
	//
	// + need to add PROPORTION of DAFT values here
	//
	if( 
		$this->referencePropertySets->isSufficientNeighbourProperties() 
		||
 		$this->referencePropertySets->isSufficientMaxProperties()
 	  )
	{
		// no missing properties, since sufficient in Neighbour or Max range !	
		$this->num_missing_properties = 0;

		// missing PROPORTION must be zero as well!
		$this->missing_proportion = 0;
	}
	else
	{
		// number missing =  (DESIRABLE in MAX range) - (actual number in MAX range)
		$this->num_missing_properties = (Parameters::DESIRABLE_NUM_VALUES_MAX_RANGE - $this->referencePropertySets->getNumMaxProperties());
		
		// this IF should not be called - legacy code from before previous IF was introduced
		// - but it does no harm, since we don't want NEGATIVE number of missing properties, if number exceeds Max ...
		if( $this->num_missing_properties < 0)
		{
			$this->num_missing_properties = 0;
		}

		// missing PROPORTION relates to MAX desired properties
		$this->missing_proportion = $this->num_missing_properties / Parameters::DESIRABLE_NUM_VALUES_MAX_RANGE;
	}
	
	// clearly the in-range propertion is (1 - the missing propertion)
	// so if 0.8 was missing, the in range proportion must be 0.2 ...
	$this->in_range_proportion = (1 - $this->missing_proportion);

/*	
$s = "";
$s .= ";ENTER:; __construct()";
$s .= ";this->referencePropertySets->getNumMaxProperties() ;= ".$this->referencePropertySets->getNumMaxProperties();
$s .= ";this->referencePropertySets->getNumNeighbourProperties() ;= ".$this->referencePropertySets->getNumNeighbourProperties();

$this->temp_string .= $s;
*/
}

//--------------------------------------------
// METHODS - getters & setters
//--------------------------------------------

/** return the currrent case (one of the CASE constants) */
public function getCurrentCase()
{
	return $this->current_case;
}

/** return the currrent case (one of the CASE constants) */
public function getCurrentCaseString()
{
	$s = "(unknown)";
	switch ($this->current_case) 
	{
		case EstimatorManager::CASE_1_ALL_NEIGHBOURS:
			$s = "CASE_1_ALL_NEIGHBOURS";
			break;
		case EstimatorManager::CASE_2_ALL_MAX:
			$s = "CASE_2_ALL_MAX";
			break;
		case EstimatorManager::CASE_3_SOME_MAX:
			$s = "CASE_3_SOME_MAX";
			break;
		case EstimatorManager::CASE_0_NO_MATCHES:
			$s = "CASE_0_NO_MATCHES";
			break;
		default:
			$s = "(unknown)";
			break;

	}
	
	return $s;
}


//--------------------------------------------
// METHODS
//--------------------------------------------

/**
 * adjust the Daft average price for differences of property to assumtations about properties the Daft average is based upon
 */
function adjust_daft_asking_price()
{
	// retrieve the DB Daft average value
	$adjusted_daft_asking_price = $this->daft_asking_price;

	// adjust for ** 1 ** "central heating"
	$percentage_assumed_with_feature = Parameters::DAFT_ASSUMPTION_ADJUSTMENT_CENTRAL_HEATING;
	$has_feature = $this->property->getCentral_heating();
	$increase_for_feature = Parameters::CENTRAL_HEATING;	 
	$adjusted_daft_asking_price = $this->adjust_for_feature($adjusted_daft_asking_price, $percentage_assumed_with_feature, $has_feature, $increase_for_feature);

	// adjust for ** 2 ** "Loft/attic conversion"
	$percentage_assumed_with_feature = Parameters::DAFT_ASSUMPTION_ADJUSTMENT_CONVERSION;
	$has_feature = $this->property->getConversion();
	$increase_for_feature = Parameters::CONVERSION;	 
	$adjusted_daft_asking_price = $this->adjust_for_feature($adjusted_daft_asking_price, $percentage_assumed_with_feature, $has_feature, $increase_for_feature);

	// adjust for ** 3 ** "Parking"
	$percentage_assumed_with_feature = Parameters::DAFT_ASSUMPTION_ADJUSTMENT_PARKING;
	$has_feature = $this->property->getParking();
	$increase_for_feature = Parameters::PARKING;	 
	$adjusted_daft_asking_price = $this->adjust_for_feature($adjusted_daft_asking_price, $percentage_assumed_with_feature, $has_feature, $increase_for_feature);

	// adjust for ** 4 ** "New kitchen"
	$percentage_assumed_with_feature = Parameters::DAFT_ASSUMPTION_ADJUSTMENT_KITCHEN_NEW;
	$has_feature = $this->property->getKitchen_new();
	$increase_for_feature = Parameters::KITCHEN_NEW;	 
	$adjusted_daft_asking_price = $this->adjust_for_feature($adjusted_daft_asking_price, $percentage_assumed_with_feature, $has_feature, $increase_for_feature);

	// adjust for ** 5 ** "Conservatory"
	$percentage_assumed_with_feature = Parameters::DAFT_ASSUMPTION_ADJUSTMENT_CONSERVATORY;
	$has_feature = $this->property->getConservatory();
	$increase_for_feature = Parameters::CONSERVATORY;	 
	$adjusted_daft_asking_price = $this->adjust_for_feature($adjusted_daft_asking_price, $percentage_assumed_with_feature, $has_feature, $increase_for_feature);

	// adjust for ** 6 ** "Additional bathroom"
	$percentage_assumed_with_feature = Parameters::DAFT_ASSUMPTION_ADJUSTMENT_ADDITIONAL_BATHROOM;
	$num_bedrooms = $this->property->getBedrooms();
	$num_bathrooms = $this->property->getBathrooms();
	$has_feature = $this->has_extra_bathroom($num_bedrooms, $num_bathrooms);
	$increase_for_feature = Parameters::ADDITIONAL_BATHROOM;	 
	$adjusted_daft_asking_price = $this->adjust_for_feature($adjusted_daft_asking_price, $percentage_assumed_with_feature, $has_feature, $increase_for_feature);

	// adjust for ** 7 ** property type
	// assume property is in the middle (i.e. between (2) terraced and (3) semi-detached)
	// so adjustment to price will be changed according to the %age different for half of 1_STEP type difference, or half of 2_STEPS type difference
	switch ($this->property->getProperty_type_id()) 
	{
		case 1:
			$adjusted_daft_asking_price *= 1 - (Parameters::PROPERTY_TYPE_2_STEP_PRICE_DIFF / 2);
			break;

		case 2:
			$adjusted_daft_asking_price *= 1 - (Parameters::PROPERTY_TYPE_1_STEP_PRICE_DIFF / 2);
			break;

		case 3:
			$adjusted_daft_asking_price *= 1 + (Parameters::PROPERTY_TYPE_1_STEP_PRICE_DIFF / 2);
			break;

		case 4:
			$adjusted_daft_asking_price *= 1 + (Parameters::PROPERTY_TYPE_2_STEP_PRICE_DIFF / 2);
			break;
	}
		
	// update the adjusted value
	$this->daft_asking_price = $adjusted_daft_asking_price;
}

/**
 * adjust the Daft average price for differences of property to assumtations about properties the Daft average is based upon
 *
 * the reasoning goes like this:
 * - IF we assumed 80% of the houses for the Daft average had parking
 *   THEN if a property DOES have parking, it should only have its asking_price INCREASED by the 20% of the parking value added
 *        (since 80% of the Daft average was already taking this increase into account)
 *   ELSE if a property does NOT have paring, it should have its asking_price DE-creased by 80% of the the parking value added
 *        (since 20% of the Daft average already took this decrease into account)
 */
function adjust_for_feature($asking_price, $percentage_assumed_with_feature, $has_feature, $increase_for_feature)
{
	$percentage_assumed_without_feature = (1 - $percentage_assumed_with_feature);
	if( $has_feature )
	{
		// increase by proportion of Daft houses that we assumed did NOT have the feature
		$propertion_to_increase_price_by = ($increase_for_feature * $percentage_assumed_without_feature);
		$new_asking_price = $asking_price * (1 + $propertion_to_increase_price_by);
	}
	else
	{
		// decrease by the proportion of Daft houses that we assumed DID have the feature
		$propertion_to_decrease_price_by = ($increase_for_feature * $percentage_assumed_with_feature);
		$new_asking_price = $asking_price * (1 - $propertion_to_decrease_price_by);
	}
	
	return $new_asking_price;
}


/**
 * given number of beds and baths, and Parametes value
 * return true/false as to whether details given indicate an extra bathroom is present or not
 */
function has_extra_bathroom($num_beds, $num_baths)
{
	// default is that house does NOT have additional bathroom
	$has_extra_bathrooms = false;
	
	if( $num_beds >= Parameters::NUM_BEDROOMS_NEEDING_BATHROOM_NUMBER_3 )
	{
		// if has more than 3 bathrooms, is this considered an EXTRA bathroom or the norm?
		if( $num_baths > 3 )
		{
			$has_extra_bathrooms = true;
		}
	}
	else if( $num_beds >= Parameters::NUM_BEDROOMS_NEEDING_BATHROOM_NUMBER_2 )
	{
		// if has more than 2 bathrooms, is this considered an EXTRA bathroom or the norm?
		if( $num_baths > 2 )
		{
			$has_extra_bathrooms = true;
		}
	}
	else
	{
		// if has 2 or more bathrooms, is this considered an EXTRA bathroom or the norm?
		if( $num_baths > 1 )
		{
			$has_extra_bathrooms = true;
		}
	}

	// return the Boolean flag value
	return $has_extra_bathrooms;
}

function match_CASE_0_NO_MATCHES()
{
	//
	// + all DAFT values here
 	//
	$this->average_price = $this->daft_asking_price;
	$this->confidence = Parameters::MAX_CONFIDENCE_INTERVAL;
}

function match_CASE_1_ALL_NEIGHBOURS()
{
	$this->average_price = $this->referencePropertySets->getNeighbourTotalAskingPrice() / $this->referencePropertySets->getNeighbourTotalWeights();
	$this->confidence = $this->referencePropertySets->getNeighbourTotalConfidence();
}

function match_CASE_2_ALL_MAX()
{
	$this->average_price = $this->referencePropertySets->getMaxTotalAskingPrice() / $this->referencePropertySets->getMaxTotalWeights();
	$this->confidence = $this->referencePropertySets->getMaxTotalConfidence();
	
}

function match_CASE_3_SOME_MAX()
{
	$this->average_price = $this->referencePropertySets->getMaxTotalAskingPrice() / $this->referencePropertySets->getMaxTotalWeights();
	$this->confidence = $this->referencePropertySets->getMaxTotalConfidence();
	
	// use the proportions to calculate confidence percentage
	$this->confidence = ($this->confidence * $this->in_range_proportion) + ($this->missing_proportion * Parameters::MAX_CONFIDENCE_INTERVAL);
	
	// use the proportions to calculate average
	$this->average_price = ($this->average_price * $this->in_range_proportion) + ($this->missing_proportion * $this->daft_asking_price);
}

function calculate()
{
	// step 1 - do the calculations
	switch ($this->current_case) 
	{
		case EstimatorManager::CASE_1_ALL_NEIGHBOURS:
			$this->match_CASE_1_ALL_NEIGHBOURS();
			break;
		case EstimatorManager::CASE_2_ALL_MAX:
			$this->match_CASE_2_ALL_MAX();
			break;
		case EstimatorManager::CASE_3_SOME_MAX:
			$this->match_CASE_3_SOME_MAX();
			break;
		case EstimatorManager::CASE_0_NO_MATCHES:
			$this->match_CASE_0_NO_MATCHES();
			break;
		default:
			$this->match_CASE_0_NO_MATCHES();
			break;

	}
	
	//
	// step 2 - calculate min/max price/rent
	//
//	$this->update_price_andrent_estimate();
	
$csv_value_list = "";
$csv_value_list .= $this->update_price_and_rent_estimate();

	//
	// step 3 - create comma separated 1000s for asking price max/min
	//
	$min_asking_price_string = number_format( $this->min_asking_price * 1000);
	$max_asking_price_string = number_format( $this->max_asking_price * 1000);
	
	//
	// step 4 - construct the CSV (actually semi-colons, not commas) string to return in the HTTP reponse
	//

	$csv_value_list .= "min_asking_price = ;$min_asking_price_string";
	$csv_value_list .= ";max_asking_price = ;$max_asking_price_string";
	$csv_value_list .= ";min_rent = ;".$this->min_rent;
	$csv_value_list .= ";max_rent = ;".$this->max_rent;


	$csv_value_list .= ";estimate CONFIDENCE = ;".$this->estimate_confidence_category();

// extra debug info


	$csv_value_list .= "; this->in_range_proportion = ;".$this->in_range_proportion;
	$csv_value_list .= "; properties in NEIGHBOUR range = ;".$this->referencePropertySets->getNumNeighbourProperties();
	$csv_value_list .= "; properties in MAX range = ;".$this->referencePropertySets->getNumMaxProperties();
	$csv_value_list .= ";num_missing_properties = ;".$this->num_missing_properties;
	$csv_value_list .= ";missing_proportion % = ;".round($this->missing_proportion * 100)."%";
	$csv_value_list .= ";current_case = ;".$this->getCurrentCaseString();
	$csv_value_list .= ";average_price = ;".$this->thousands( $this->average_price );
	$csv_value_list .= ";confidence (+/-) % = ;".round($this->confidence)."%";
	$csv_value_list .= ";confidence (+/-) euro = ;".$this->thousands( $this->confidence_price_delta() );
	$csv_value_list .= ";daft_asking_price = ;".$this->thousands( $this->daft_asking_price );
	$csv_value_list .= ";this->property->getBedrooms() = ;".$this->property->getBedrooms();

$csv_value_list .= $this->temp_string;
 	return $csv_value_list;
}


/**
calculate (and store) min/max asking price and rents to be returned to web page
*/

function update_price_and_rent_estimate()
{
	$min_asking_price_float = $this->average_price - $this->confidence_price_delta();
	$this->min_asking_price = round($min_asking_price_float);

	$max_asking_price_float = $this->average_price - (-1 * $this->confidence_price_delta());
	$this->max_asking_price = round($max_asking_price_float);

	// min RENT	
	$min_rent_num = $this->price_to_rent( $this->min_asking_price );
	$this->min_rent = number_format( $min_rent_num );
	
	// max RENT	
	$max_rent_num = $this->price_to_rent( $this->max_asking_price );
	$this->max_rent = number_format( $max_rent_num );     
}


/**
return one of 3 keywords to indicate estimate confidence
low / medium / high
*/
function estimate_confidence_category()
{
	
	if( $this->in_range_proportion > Parameters::IN_RANGE_PROPORTION_HIGH )
	{
		$confidence_string = "high";
	}
	else if( $this->in_range_proportion > Parameters::IN_RANGE_PROPORTION_MEDIUM )
	{
		$confidence_string = "medium";
	}
	else
	{
		$confidence_string = "low";
	}

	return $confidence_string;
}

/**
confidence price error is +/- half of confidence propertion of price 
return this value
*/
function confidence_price_delta()
{
	if( $this->confidence_decimal() > 0)
	{
		return ($this->average_price * $this->confidence_decimal())/2;
	}
	else
	{
		// avoid divide by zero problem
		return 0;
	}
}

/**
return comma (1,000) formatted value * 1000
*/
function thousands( $n )
{
	return number_format( $n * 1000);
}

/**
return the confidence percentage as a decimal value, e.g. 2% would be returned as 0.02
*/
function confidence_decimal()
{
	return ($this->confidence)/100;
}

/**
return rent, given price
*/
function price_to_rent( $price )
{
	$price_thousands = ($price * 1000);
	
	$year_rent = ($price_thousands / Parameters::INVESTMENT_YEARS);
	$monthly_rent = round($year_rent/12);
	
	return $monthly_rent;
}

/**
return rent, given price
*/
function rent_to_price( $monthly_rent )
{
	$year_rent = ($monthly_rent * 12);
	$invesment_rent = (Paramaters::INVESTMENT_YEARS * $year_rent);
	$price_thousands = ($invesment_rent / 1000);
	
	return $investment_rent;
}

} // class

?>