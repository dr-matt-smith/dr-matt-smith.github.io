<?php

class PropertyList
{

//--------------------------------------------
// PROPERTIES
//--------------------------------------------

/** stores an array of Property objects */
private $property_array;

//--------------------------------------------
// METHODS - getters & setters
//--------------------------------------------

public function getTotalWeights()
{
	$total_weights = 0.0;
	for($i = 0; $i < $this->count(); $i++)
	{
		$total_weights += $this->property_array[$i]->getWeight();
	}

	return $total_weights;
}

public function getTotalAskingPrice()
{
	$total_asking_price = 0.0;
	for($i = 0; $i < $this->count(); $i++)
	{
		$weighted_asking_price = $this->property_array[$i]->getAsking_price() * $this->property_array[$i]->getWeight();
		$total_asking_price += $weighted_asking_price;
	}

	return $total_asking_price;
}

public function getTotalConfidence()
{
	$total_confidence = 0.0;
	for($i = 0; $i < $this->count(); $i++)
	{
		$total_confidence += $this->property_array[$i]->getConfidence();
	}

	return $total_confidence;
}


//--------------------------------------------
// METHODS
//--------------------------------------------

public function __construct()
{
	// initialise array to be empty
	$this->property_array = null;
}

public function add_property($p)
{
	// initialise array to be empty
	$this->property_array[] = $p;
}

public function count()
{
	return count($this->property_array);
}

/** match all properties against given client property */
public function match($p)
{
	for($i = 0; $i < $this->count(); $i++)
	{
		$this->property_array[$i]->match($p);
	}
}



//--------------------------------------------
// METHODS - for TESTING ONLY
//--------------------------------------------
public function test_output()
{
	$html = "";
	for($i = 0; $i < $this->count(); $i++)
	{
		$html .= $this->property_array[$i]->test_output();
		$html .= "<hr/><hr/>";
	}
	
	return $html;
}

} // class

?>