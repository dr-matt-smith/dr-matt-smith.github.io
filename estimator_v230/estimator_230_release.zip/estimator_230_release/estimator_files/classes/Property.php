<?php

/**
--------------------------------------------
CLASS: Property
VERSION: 1.0 (Sep 2011)
AUTHOR: Dr Matt Smith
class to store data and perform functions for a single PROPERTY
--------------------------------------------
*/
class Property
{
//--------------------------------------------
// CLASS - CONSTANTS
//--------------------------------------------
const investment_years = 15;

//--------------------------------------------
// STATIC CLASS METHODS
//--------------------------------------------

/**
 * given an integer (representing thousands)
 * return calculation of monthly rent
 * based upon formular given by TheGoodAgent
 */
static public function price_to_rent( $price )
{
	$price = ($price * 1000);
	
	$year_rent = ($price / Parameters::INVESTMENT_YEARS);
	$monthly_rent = Math.round($year_rent/12);
	
	return $monthly_rent;
}

/**
 * given an integer (representing monthly rent)
 * return calculation of how many thousands the property's asking price would be
 * based upon formular given by TheGoodAgent
 */
static public function rent_to_price( $monthly_rent )
{
	$year_rent = ($monthly_rent * 12);
	$investment_rent = (Parameters::INVESTMENT_YEARS * $year_rent);
	$investment_rent = $investment_rent/1000;
	
	return $investment_rent;
}

/**
 * using an appropriate Parameters value
 * return an ASKING PRICE having been given a SELLING PRICE
 */
static public function selling_price_to_asking_price( $selling_price )
{
	$asking_price = $selling_price * (1 + Parameters::ASKING_PRICE_PROPORTION_ABOVE_SELLING_PRICE);
	
	return $asking_price;
}


/**
 * given a number from 1-12, return the corresponding 3 letter month name
 * otherwise return "???" for invalid input
 */
static public function month_name( $month_value )
{
	// some checks in case given a bad string / object / number etc.
	$month_number = intval($month_value);
	
	// return "???" if invalid value
	if( ($month_number < 1) || ($month_number > 12))
	{
		return "???";
	}
	
	switch ($month_number) 
	{
		case 1:
			return "Jan";
		case 2:
			return "Feb";
		case 3:
			return "Mar";
		case 4:
			return "Apr";
		case 5:
			return "May";
		case 6:
			return "Jun";
		case 7:
			return "Jul";
		case 8:
			return "Aug";
		case 9:
			return "Sep";
		case 10:
			return "Oct";
		case 11:
			return "Nov";
		case 12:
			return "Dec";
	}
}

/**
 * given a string in the form "YYYY-MM" (e.g. "2011-12")
 * return the first 4 characters representing the year (e.g. "2011")
 */
static public function get_year_from_year_month_string( $year_month_string )
{
	if( strlen($year_month_string) > 3 )
	{
		return substr($year_month_string, 0, 4);
	}
}

/**
 * given a string in the form "YYYY-MM" (e.g. "2011-12")
 * return the month number (e.g "12")
 */
static public function get_month_from_year_month_string( $year_month_string )
{
	if( strlen($year_month_string) >= 7 )
	{
		return substr($year_month_string, 5, 2);
	}
}

/**
 * given a string in the form "YYYY-MM" (e.g. "2011-12")
 * return string for the next month (e.e. "2012-01")
 */
static public function calc_next_year_month_string( $year_month_string )
{	
	// default - error string
	$next_year = "????";
	$next_month_string = "??";
	
	$month = Property::get_month_from_year_month_string( $year_month_string );
	$year = Property::get_year_from_year_month_string( $year_month_string );

	// get next year
	$year_num = intval($year);
	if( $year_num > 0 )
	{
		$next_year = $year;
	}
	
	$month_num = intval($month);
	if( ($month_num > 0) && ($month_num < 13))
	{
		if( $month_num < 12 )
		{
			$next_month = ($month_num + 1);
			$format= "%02d";
			$next_month_string = sprintf($format, $next_month);
		}
		else
		{
			$next_month_string = "01";
			$next_year++;
		}
	}
	
	// create string to return
	$next_year_month_string = "$next_year-$next_month_string";
	return $next_year_month_string;
}


	
//--------------------------------------------
// PROPERTIES
//--------------------------------------------
private $id = 0;
private $lat = 0.0;
private $long = 0.0;
private $property_type_id = 0;
private $bedrooms = 0;
private $bathrooms = 0;
private $parking = false;
private $conversion = false;
private $kitchen_new = false;
private $conservatory = false;
private $central_heating = false;
private $asking_price = 0;

private $distance = 0.0;
private $distance_to_dublin_center = 0.0;

/** copy of client property details to match against */
private $client_property = null;

/** weighting for this property in the average calculation */
private $weight = 1.0;

/** confidence range contribution for this property */
private $confidence = 0.0;

//--------------------------------------------
// METHODS - getters & setters
//--------------------------------------------

public function getId(){	return $this->id;	}
public function getLong(){	return $this->long;	}
public function getLat(){	return $this->lat;	}
public function getProperty_type_id(){	return $this->property_type_id;	}
public function getBedrooms(){	return $this->bedrooms;	}
public function getBathrooms(){	return $this->bathrooms;	}
public function getParking(){	return $this->parking;	}
public function getConversion(){	return $this->conversion;	}
public function getKitchen_new(){	return $this->kitchen_new;	}
public function getConservatory(){	return $this->conservatory;	}
public function getCentral_heating(){	return $this->central_heating;	}
public function getAsking_price(){	return $this->asking_price;	}

public function getWeight(){	return $this->weight;	}
public function getConfidence(){	return $this->confidence;	}


// number format gets ...
public function getLat_nf(){	return number_format($this->lat,3);	}
public function getLong_nf(){	return number_format($this->long,3);	}
public function getDistance_nf(){	return number_format($this->distance,3);	}


//--------------------------------------------
// METHODS - boolean inferred properties
//--------------------------------------------
public function isWithinNeighbourRange()
{
	return $this->distance < Parameters::NEIGHBOUR_RANGE; 	
}

public function isBetweenNeighbourMaxRange()
{
	// must be within MAX_RANGE, but not within NEIGHBOUR_RANGE
	return ($this->distance < Parameters::MAX_RANGE) && ($this->distance >= Parameters::NEIGHBOUR_RANGE);
}

public function isDublinProperty()
{
	// distance to Dublin center must be withing the Parameters RADIUS value ...
	return ($this->distance_to_dublin_center < Parameters::DUBLIN_CENTER_RADIUS);
}

//--------------------------------------------
// METHODS - constructor
//--------------------------------------------

// extract properties from from DB row 
function __construct($row)
{
    $this->id = $row["id"];
    $this->lat = $row["latitude"];
    $this->long = $row["longitude"];
    $this->property_type_id = $row["property_type_id"];
    $this->bedrooms = $row["bedrooms"];
    $this->bathrooms = $row["bathrooms"];
    $this->parking = $row["parking"];
    $this->conversion = $row["conversion"];
    $this->kitchen_new = $row["kitchen_new"];
    $this->conservatory = $row["conservatory"];
    $this->central_heating = $row["central_heating"];
    $this->asking_price = $row["asking_price"];
	$this->distance = $row["distance"];
	$this->distance_to_dublin_center = $row["distance_to_dublin_center"];
}


//--------------------------------------------
// METHODS
//--------------------------------------------

/**
given the CSO-adjusted Dublin / National asking prices
appropriately set (adjust) the asking price of thsi property according to whether it is within the Dublin city center radius or not ...
*/
public function adjust_price_for_cso( $adjusted_dublin_asking_price, $adjusted_national_asking_price )
{
	if( $this->isDublinProperty() )
	{
		$this->asking_price = $adjusted_dublin_asking_price;
	}
	else
	{
		$this->asking_price = $adjusted_national_asking_price;
	}
}


/**
reset the weight and confidence range contribution
- ready for new matching calculations
*/
private function reset_weights()
{
	// default - start weight at 1
	$this->weight = 1.0;
	
	// adjust weight if a NEIGHBOUR property
	if( $this->isWithinNeighbourRange() )
	{
		$this->weight = Parameters::NEIGHBOUR_WEIGHTING;
	}
	
	$this->confidence = 0.0;
}

/**
run a match between contents of this property, and stored client property
setting asking_price and confidence_value appropriately

?? and weighting value ??
*/
public function match($p)
{
	// store the user's property
	$this->client_property = $p;
	
	// reset weight / confidence contribution
	$this->reset_weights();

	// call the matching functions for each feature
	$this->match_bedrooms();
	$this->match_bathrooms();
	$this->match_parking();
	$this->match_kitchen_new();
	$this->match_conversion();
	$this->match_conservatory();
	$this->match_central_heating();
	$this->match_property_type();
}

/** -------------------- */
private function match_bedrooms()
{
	$bedroom_difference = ($this->client_property->getBedrooms() - $this->bedrooms);

	// Additional bedroom (useful if we don't have a property that has exactly the same number of bedrooms as the searched property): +6%
	if( $bedroom_difference <> 0 )
	{
		// reduce weighting for this property since not full match
		$this->weight -= Parameters::WEIGHTING_REDUCTION_FOR_ADJUST;
$this->debug_string .= "1";
		
		// adjust asking price appropriately (add +6% for each extra bedroom client house has / subject same for each fewer client house has)
		$this->asking_price *= 1 + (Parameters::ADDITIONAL_BEDROOM *  $bedroom_difference);
		
		// retrieve appropriate adjustment %age depending on feature AND whether this property is a Neighbour
		$adjustment = Parameters::BEDBATH_NEIGHBOUR_AJUST;
		if( !$this->isWithinNeighbourRange() )
		{
			$adjustment = Parameters::BEDBATH_MAX_RANGE_AJUST;
		}

		// adjust confidence range appropriately - for number of differences
		// NOTE - since confidence is +/-, always add ABSOLUTE (postitive) values to confidence
		$this->confidence += abs($adjustment * $bedroom_difference);
	}
}

/** -------------------- */
private function match_bathrooms()
{
	$bathroom_difference = ($this->client_property->getBathrooms() - $this->bathrooms);

	// Additional bathrooms (useful if we don't have a property that has exactly the same number of bathrooms as the searched property): +5%
	if( $bathroom_difference <> 0 )
	{
		// reduce weighting for this property since not full match
		$this->weight -= Parameters::WEIGHTING_REDUCTION_FOR_ADJUST;
$this->debug_string .= "2";
	
		// adjust asking price appropriately (add +6% for each extra bedroom client house has / subject same for each fewer client house has)
		$this->asking_price *= 1 + (Parameters::ADDITIONAL_BATHROOM *  $bathroom_difference);
		
		// retrieve appropriate adjustment %age depending on feature AND whether this property is a Neighbour
		$adjustment = Parameters::BEDBATH_NEIGHBOUR_AJUST;
		if( !$this->isWithinNeighbourRange() )
		{
			$adjustment = Parameters::BEDBATH_MAX_RANGE_AJUST;
		}

		// adjust confidence range appropriately - for number of differences
		// NOTE - since confidence is +/-, always add ABSOLUTE (postitive) values to confidence
		$this->confidence += abs($adjustment * $bathroom_difference);
	}
}

/** -------------------- */
private function match_parking()
{
	$parking_difference = ($this->client_property->getParking() - $this->parking);

	// Additional parking (useful if we don't have a property that has exactly the same number of parking as the searched property): +5%
	if( $parking_difference <> 0 )
	{
		// reduce weighting for this property since not full match
		$this->weight -= Parameters::WEIGHTING_REDUCTION_FOR_ADJUST;
$this->debug_string .= "3";
		
		// adjust asking price appropriately (add +6% for each extra bedroom client house has / subject same for each fewer client house has)
		$this->asking_price *= 1 + (Parameters::PARKING *  $parking_difference);
		
		// retrieve appropriate adjustment %age depending on feature AND whether this property is a Neighbour
		$adjustment = Parameters::FIVE_FEATURE_NEIGHBOUR_AJUST;
		if( !$this->isWithinNeighbourRange() )
		{
			$adjustment = Parameters::FIVE_FEATURE_MAX_RANGE_AJUST;
		}

		// adjust confidence range appropriately - for number of differences
		// NOTE - since confidence is +/-, always add ABSOLUTE (postitive) values to confidence
		$this->confidence += abs($adjustment * $parking_difference);
	}
}


/** -------------------- */
private function match_kitchen_new()
{
	$kitchen_new_difference = ($this->client_property->getKitchen_new() - $this->kitchen_new);

	// Additional kitchen_new (useful if we don't have a property that has exactly the same number of kitchen_new as the searched property): +5%
	if( $kitchen_new_difference <> 0 )
	{
		// reduce weighting for this property since not full match
		$this->weight -= Parameters::WEIGHTING_REDUCTION_FOR_ADJUST;
$this->debug_string .= "4";
		
		// adjust asking price appropriately (add +6% for each extra bedroom client house has / subject same for each fewer client house has)
		$this->asking_price *= 1 + (Parameters::KITCHEN_NEW * $kitchen_new_difference);
		
		// retrieve appropriate adjustment %age depending on feature AND whether this property is a Neighbour
		$adjustment = Parameters::FIVE_FEATURE_NEIGHBOUR_AJUST;
		if( !$this->isWithinNeighbourRange() )
		{
			$adjustment = Parameters::FIVE_FEATURE_MAX_RANGE_AJUST;
		}

		// adjust confidence range appropriately - for number of differences
		// NOTE - since confidence is +/-, always add ABSOLUTE (postitive) values to confidence
		$this->confidence += abs($adjustment * $kitchen_new_difference);
	}
}

/** -------------------- */
private function match_conversion()
{
	$conversion_difference = ($this->client_property->getConversion() - $this->conversion);

	// Additional conversion (useful if we don't have a property that has exactly the same number of conversion as the searched property): +5%
	if( $conversion_difference <> 0 )
	{
		// reduce weighting for this property since not full match
		$this->weight -= Parameters::WEIGHTING_REDUCTION_FOR_ADJUST;
$this->debug_string .= "5";
		
		// adjust asking price appropriately (add +6% for each extra bedroom client house has / subject same for each fewer client house has)
		$this->asking_price *= 1 + (Parameters::CONVERSION *  $conversion_difference);
		
		// retrieve appropriate adjustment %age depending on feature AND whether this property is a Neighbour
		$adjustment = Parameters::FIVE_FEATURE_NEIGHBOUR_AJUST;
		if( !$this->isWithinNeighbourRange() )
		{
			$adjustment = Parameters::FIVE_FEATURE_MAX_RANGE_AJUST;
		}

		// adjust confidence range appropriately - for number of differences
		// NOTE - since confidence is +/-, always add ABSOLUTE (postitive) values to confidence
		$this->confidence += abs($adjustment * $conversion_difference);
	}
}

/** -------------------- */
private function match_conservatory()
{
	$conservatory_difference = ($this->client_property->getConservatory() - $this->conservatory);

	// Additional conservatory (useful if we don't have a property that has exactly the same number of conservatory as the searched property): +5%
	if( $conservatory_difference <> 0 )
	{
		// reduce weighting for this property since not full match
		$this->weight -= Parameters::WEIGHTING_REDUCTION_FOR_ADJUST;
$this->debug_string .= "6";
		
		// adjust asking price appropriately (add +6% for each extra bedroom client house has / subject same for each fewer client house has)
		$this->asking_price *= 1 + (Parameters::CONSERVATORY *  $conservatory_difference);
		
		// retrieve appropriate adjustment %age depending on feature AND whether this property is a Neighbour
		$adjustment = Parameters::FIVE_FEATURE_NEIGHBOUR_AJUST;
		if( !$this->isWithinNeighbourRange() )
		{
			$adjustment = Parameters::FIVE_FEATURE_MAX_RANGE_AJUST;
		}

		// adjust confidence range appropriately - for number of differences
		// NOTE - since confidence is +/-, always add ABSOLUTE (postitive) values to confidence
		$this->confidence += abs($adjustment * $conservatory_difference);
	}
}

/** -------------------- */
private function match_central_heating()
{
	$central_heating_difference = ($this->client_property->getCentral_heating() - $this->central_heating);

	// Additional central_heating (useful if we don't have a property that has exactly the same number of central_heating as the searched property): +5%
	if( $central_heating_difference <> 0 )
	{
		// reduce weighting for this property since not full match
		$this->weight -= Parameters::WEIGHTING_REDUCTION_FOR_ADJUST;
$this->debug_string .= "7";
		
		// adjust asking price appropriately (add +6% for each extra bedroom client house has / subject same for each fewer client house has)
		$this->asking_price *= 1 + (Parameters::CENTRAL_HEATING *  $central_heating_difference);
		
		// retrieve appropriate adjustment %age depending on feature AND whether this property is a Neighbour
		$adjustment = Parameters::FIVE_FEATURE_NEIGHBOUR_AJUST;
		if( !$this->isWithinNeighbourRange() )
		{
			$adjustment = Parameters::FIVE_FEATURE_MAX_RANGE_AJUST;
		}

		// adjust confidence range appropriately - for number of differences
		// NOTE - since confidence is +/-, always add ABSOLUTE (postitive) values to confidence
		$this->confidence += abs($adjustment * $central_heating_difference);
	}
}


/**
adjustments - if mismatch between propety TYPE (apartment / terraced etc.)

property type list (from least to most valuable):
	1 = apartment
	2 = terraced
	3 = semi-detatched
	4 = detached
	(max difference is between 1 and 4 = 3 step difference)
*/
private function match_property_type()
{
	$property_type_difference = ($this->client_property->getProperty_type_id() - $this->property_type_id);

	switch ($property_type_difference) 
	{
		case -3:
			// reduce weighting for this property since not full match
			$this->weight -= Parameters::WEIGHTING_REDUCTION_FOR_ADJUST;
		
			// adjust confidence range appropriately - for number of differences
			$this->confidence += Parameters::PROPERTY_TYPE_3_STEP_ADJUST;

			// reduce price by appropriate amount
			$this->asking_price *= 1 - (Parameters::PROPERTY_TYPE_3_STEP_PRICE_DIFF);
			break;

		case -2:
			// reduce weighting for this property since not full match
			$this->weight -= Parameters::WEIGHTING_REDUCTION_FOR_ADJUST;
			
			// adjust confidence range appropriately - for number of differences
			$this->confidence += Parameters::PROPERTY_TYPE_2_STEP_ADJUST;

			// reduce price by appropriate amount
			$this->asking_price *= 1 - (Parameters::PROPERTY_TYPE_2_STEP_PRICE_DIFF);
			break;

		case -1:
			// reduce weighting for this property since not full match
			$this->weight -= Parameters::WEIGHTING_REDUCTION_FOR_ADJUST;

			// adjust confidence range appropriately - for number of differences
			$this->confidence += Parameters::PROPERTY_TYPE_1_STEP_ADJUST;

			// reduce price by appropriate amount
			$this->asking_price *= 1 - (Parameters::PROPERTY_TYPE_1_STEP_PRICE_DIFF);			
			break;
			
		case 1:
			// reduce weighting for this property since not full match
			$this->weight -= Parameters::WEIGHTING_REDUCTION_FOR_ADJUST;
$this->debug_string .= "8";

			// adjust confidence range appropriately - for number of differences
			$this->confidence += Parameters::PROPERTY_TYPE_1_STEP_ADJUST;

			// increase price by appropriate amount
			$this->asking_price *= 1 + (Parameters::PROPERTY_TYPE_1_STEP_PRICE_DIFF);			
			break;

		case 2:
			// reduce weighting for this property since not full match
			$this->weight -= Parameters::WEIGHTING_REDUCTION_FOR_ADJUST;
			
			// adjust confidence range appropriately - for number of differences
			$this->confidence += Parameters::PROPERTY_TYPE_2_STEP_ADJUST;

			// increase price by appropriate amount
			$this->asking_price *= 1 + (Parameters::PROPERTY_TYPE_2_STEP_PRICE_DIFF);
			break;


		case 3:
			// reduce weighting for this property since not full match
			$this->weight -= Parameters::WEIGHTING_REDUCTION_FOR_ADJUST;
		
			// adjust confidence range appropriately - for number of differences
			$this->confidence += Parameters::PROPERTY_TYPE_3_STEP_ADJUST;

			// increase price by appropriate amount
			$this->asking_price *= 1 + (Parameters::PROPERTY_TYPE_3_STEP_PRICE_DIFF);


		case 0:
		default:
			// do nothing, since same property type!
	}
}


//--------------------------------------------
// METHODS - for TESTING ONLY
//--------------------------------------------

private $debug_string = "";

public function test_output()
{
	$html = "";
	$html .= "id = ".$this->id;
	$html .= "/ asking_price = ".$this->asking_price;
	$html .= "/ weight = ".$this->weight;
	$html .= "/ confidence = ".$this->confidence;
	$html .= "<br/>".$this->debug_string;
	return $html;
}

} // class

?>