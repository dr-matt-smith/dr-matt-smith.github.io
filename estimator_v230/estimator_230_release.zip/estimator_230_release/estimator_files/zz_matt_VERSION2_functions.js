/**
 * constants for "actor" in current interaction
 *
 * this is required since Human can change a drop down menu, and so can Computer (after geocoding an address for example)
 * if computer has changed, say, County menu, then it should not lead to the same actions as if a Human did
 *
 * DEFAULT is that action is from a HUMAN
 * default should be reset after each estimate data/message update
 */
var ACTOR_HUMAN = 0;
var ACTOR_COMPUTER = 1;

var stored_actor = ACTOR_HUMAN;

// GLOBAL VARIABLE - for animation
var g_stored_html_string = "";

/**
error capture - --------- remove for production version 
matt was ere
*/
var newline = "\n";

onerror = function (msg, url, line)
{
	alert("ERROR" + newline + msg + newline + "url = " + url + newline + "at line " + line);
}

/**
if ENTER pressed, call same function as if button clicked
*/
$("#google_address_form").submit( gui_event_move_to_address_button_click );
$("#move_to_address_button").click( gui_event_move_to_address_button_click );
$("#move_pin_to_center_button").click( gui_event_move_pin_to_center_button_click );

function gui_event_move_pin_to_center_button_click()
{
	// call button event handler
	move_marker_to_center2();
	
}

function gui_event_move_to_address_button_click()
{
	// call button event handler
	code_address();
	
	// do not let form submit - this would reload whole page
	return false;
}

$("#search_property_type_option").change( gui_event_minor_property_feature_change );
$("#bedrooms").change( gui_event_minor_property_feature_change );
$("#bathrooms").change( gui_event_minor_property_feature_change );
$("#central_heating").change( gui_event_minor_property_feature_change );
$("#conservatory").change( gui_event_minor_property_feature_change );
$("#parking").change( gui_event_minor_property_feature_change );
$("#kitchen_new").change( gui_event_minor_property_feature_change );
$("#conversion").change( gui_event_minor_property_feature_change );

/**
do action when any of the minor features have been changed (i.e. not changing county or town)
(property type / bedrooms / bathrooms / central heating / other tick box features)
*/
function gui_event_minor_property_feature_change()
{
	version2_update_display();
}

// declare event hander for TOWN menu change
$("#search_town_option").change( gui_event_town_menu_change );

/**
 * if TOWN menu changed && HUMAN actor
 * then update map position and update display with msg/new valudation
 * 
 */
function gui_event_town_menu_change()
{
//alert("zz_matt_VERSION2_functins.js :: calling :: gui_event_town_menu_change() ")
//alert("stored_actor = " + stored_actor);

	if( stored_actor == ACTOR_HUMAN )
	{
		// (1) get lat/long for town
		//
		// get town & county id's
		var county_id = $("#search_county_option").val();
		var town_index = $("#search_town_option").val();
		
		// get lat/lng position of selected town
		var town_position = get_town_position( county_id, town_index  )
		
		// (2) update pin on map
		//
		// make MAP realign to new position (and move marker)		
		version2_update_MAP_POSITION( town_position );
	
		// (3) update display (get and show new estimate, if all required features chosen)
		version2_update_display();		
	}
}

// define menu COUNTY change event handler 
$("#search_county_option").change(gui_event_county_menu_change );

/**
 * if COUNTY menu changed THEN
 * (1) update town menu
 * (2) IF  HUMAN actor
 *     THEN update map position and update display with msg/new valudation
 * 
 */
function gui_event_county_menu_change()
{
	if( stored_actor == ACTOR_HUMAN )
	{
		// (1) update TOWN menu based on COUNTY menu id
		update_town_list_from_county_id();
		
		// (2) get lat/long for COUNTY
		var county_id = $("#search_county_option").val();
		var county_position = county_center( county_id );
		
		// (3) update pin on map
		//
		// make MAP realign to new position (and move marker)		
		version2_update_MAP_POSITION( county_position );
	
		// (4) update display (get and show new estimate, if all required features chosen)
		version2_update_display();					
	}
}

function update_town_list_from_county_id()
{
	// get county id from menu
	var county_id = $("#search_county_option").val();
	
	// update the list of towns for the county id
	load_towns( county_id );
}


/**
return true if any of the required features are missing
*/
function missing_required_features_html_list_builder()
{
	// get all 4 required features
	var county_id = $("#search_county_option").val();
	var property_type_id = $("#search_property_type_option").val();
	var bedrooms = $("#bedrooms").val();
	var bathrooms = $("#bathrooms").val();
	
	// check if all have values - any zero value indicate missing feature
	var missing_value_msg = "";
	var count = 0;
	
	if( county_id == 0 )
	{
		missing_value_msg += "<li class='matt_required'>County</li>";
	}

	if( property_type_id == 0 )
	{
		missing_value_msg += "<li class='matt_required'>Property-type</li>";
	}

	if( bathrooms == 0 )
	{
		missing_value_msg += "<li class='matt_required'>Number of Bathrooms</li>";
	}

	if( bedrooms == 0 )
	{
		missing_value_msg += "<li class='matt_required'>Number of Bedrooms</li>";
	}
	
	if( missing_value_msg != "" )
	{
		missing_value_msg = "<ul>" + missing_value_msg + "</ul>";
	}

	return missing_value_msg;
}


/**
 * time to update display for user
 * IF missing required fields
 * THEN display missing fields messag
 * ELSE calculate and then display new estimates based on current location of the "pin"
 */
function version2_update_display()
{
	// reset default - that interactions are Human unless this variable says otherwise
	stored_actor = ACTOR_HUMAN;
	
	// update message / data depending of whether all required features have been set
	if( missing_required_features_html_list_builder() != "" )
	{
		version2_update_display_warning_message( missing_required_features_html_list_builder() );
	}
	else
	{
		version2_ajax_update_and_display_estimate();
	}
}

/**
 * set up the new HTML content
 * then animate via a SLIDE DOWN
 */
function slide_back_down_again()
{
	var html_string = g_stored_html_string;
	$("#estimater_results_block").html( html_string );
	$("#estimater_results_block").slideDown();
}


// intialise values and message in estimator results DIV of HTML
var MISSING_FEATURES_MESSAGE =  "INCOMPLETE PROPERTY DATA";

/**
 * replace any existing contents of the main results display block with the given message
 */
function version2_update_display_warning_message( missing_features_html_list )
{
	var html_string = "<h3>" + MISSING_FEATURES_MESSAGE + "</h3>";
	html_string += '<p class="missing_features">The following required features (<span class="matt_required">*</span>) have yet to be selected:</p>';
	html_string += missing_features_html_list;

	g_stored_html_string = html_string;	
	$("#estimater_results_block").slideUp( slide_back_down_again );	

}

/**
hide any previous message, and show these asking price estimates
*/

function version2_update_display_estimate_values( min_asking_price, max_asking_price, min_rent, max_rent, estimate_confidence)
{
	var html_string = "";
	html_string += '<h3><span class="estimate_header">Asking price: </span>';
	html_string += "&euro; " + min_asking_price + " to &euro; " + max_asking_price + "</h3>";
	html_string += '<h3><span class="estimate_header">Monthly rent: </span>';
	html_string += "&euro; " + min_rent + " to &euro; " + max_rent + "</h3>";

	html_string += "<p>";
	html_string += "Any values and/or estimates on this page should be taken as approximates and should not be used as proof of property value.";
	html_string += "</p>";

	html_string += generate_estimate_confidence_html( estimate_confidence );
	
	g_stored_html_string = html_string;	
	$("#estimater_results_block").slideUp( slide_back_down_again );	
}

function generate_estimate_confidence_html( estimate_confidence )
{
	var estimate_confidence_image = calc_estimate_confidence_image( estimate_confidence );

	var confidence_html_string = "<p>";
	
	confidence_html_string += "<img src='" + estimate_confidence_image + "' alt='confidence image' />";
	
	// if LOW confidence, then add message to recommend adding some more history values to the DB
	if( estimate_confidence == "low")
	{
		// add an additional; message to the user suggesting they add some nearby property details
		confidence_html_string += "<br />";
		confidence_html_string += "To increase accuracy of the estimate, ";
		confidence_html_string += "<br />";
		confidence_html_string += "you could <a href='estimator_new_data.php'>add some nearby property prices to the estimator database ...";
	}

	// and close the paragraph
	confidence_html_string += "</p>";
	
	return confidence_html_string;
}

/**
return one of the 3 confidence image file paths
low / meduim / high - default to low
*/
function calc_estimate_confidence_image( estimate_confidence )
{
	var image_path = "images";
	var image_filename = "matt_estimate_confidence_1_low.png";
	
	if( isset( estimate_confidence) )
	{
		if( estimate_confidence == "medium")
		{
			image_filename = "matt_estimate_confidence_2_medium.png";
		}
		else if( estimate_confidence == "high")
		{
			image_filename = "matt_estimate_confidence_3_high.png";
		}
		
	}
	
	var image_path_file = image_path + "/" + image_filename;
	return image_path_file;
}


/**
return true if variable has a value (i.e. != 'undefined')
*/
function isset( variable_name )
{
	return typeof variable_name != 'undefined';
}