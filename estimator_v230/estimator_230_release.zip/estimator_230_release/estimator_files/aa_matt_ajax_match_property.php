<?php

//
// (1)
// get record set containing properties likely to be within MAX = $rs
require_once("aa_matt_geo_recordset.php");

//
// (2)
// get data from GET
$county_id = -1;
if( filter_has_var(INPUT_GET, "county_id") ) 
{
	$county_id = filter_input(INPUT_GET, "county_id");
}	

$property_type_id = 0;
if( filter_has_var(INPUT_GET, "property_type_id") ) 
{
	$property_type_id = filter_input(INPUT_GET, "property_type_id");
}	

$bedrooms = 0;
if( filter_has_var(INPUT_GET, "bedrooms") ) 
{
	$bedrooms = filter_input(INPUT_GET, "bedrooms");
}	

$bathrooms = 0;
if( filter_has_var(INPUT_GET, "bathrooms") ) 
{
	$bathrooms = filter_input(INPUT_GET, "bathrooms");
}	

$central_heating = 0;
if( filter_has_var(INPUT_GET, "central_heating") ) 
{
	$central_heating = filter_input(INPUT_GET, "central_heating");
}	

$parking = 0;
if( filter_has_var(INPUT_GET, "parking") ) 
{
	$parking = filter_input(INPUT_GET, "parking");
}	

$kitchen_new = 0;
if( filter_has_var(INPUT_GET, "kitchen_new") ) 
{
	$kitchen_new = filter_input(INPUT_GET, "kitchen_new");
}	

$conservatory = 0;
if( filter_has_var(INPUT_GET, "conservatory") ) 
{
	$conservatory = filter_input(INPUT_GET, "conservatory");
}	

$conversion = 0;
if( filter_has_var(INPUT_GET, "conversion") ) 
{
	$conversion = filter_input(INPUT_GET, "conversion");
}	


//
// (3)
// create OBJECT to contain set of properties within NEIGHBOUR range & set withing MAX range
$referencePropertySets = new ReferencePropertySets();

//
// (4)
// add properties into the property sets
while( $row = mysql_fetch_assoc($rs) )
{
	// (1) get next property
	$p = new Property($row);
	
	// (2) adjust asking price based on latest CSO figures
	$adjusted_dublin_asking_price = $row["adjusted_dublin_asking_price"];
	$adjusted_national_asking_price = $row["adjusted_national_asking_price"];
	
	$p->adjust_price_for_cso( $adjusted_dublin_asking_price, $adjusted_national_asking_price );
	
	// (3) add property to approprite set (neighbour/max) if appropriate
	$referencePropertySets->add_property($p);

}


//
// (5)
// now process the proeprties collected ....
$client_p = construct_client_property();

//$central_heating = $client_p->central_heating;
// print("<srcipt>alert('central_heating = $central_heating');</script>");

$daft_asking_price = retrieve_daft_average($county_id, $bedrooms);
$estimator_manager = new EstimatorManager( $referencePropertySets, $client_p, $county_id, $daft_asking_price);

// output the comma separated values
print $estimator_manager->calculate();

// housekeeping - close DB connection
mysql_close($connection);


?>


<?php

//
// functions for use in this script
//

/**
 given county_id and num_bedroms, return the daft average
 (extracted from database)
*/
function retrieve_daft_average($county_id, $num_bedrooms)
{
	// let us use connection in this function 
	global $connection;
	
	// create SQL query string
	$query = "SELECT * FROM county WHERE region_id = $county_id";
	
	// run query and store the "result set"
	$rs = mysql_query($query, $connection);
	
	// error message if no result set from query ...
	if( !$rs ) die( "ERROR: query did not return a result set: $query");
	
	// extract first (only!) row from record set
	$row = mysql_fetch_assoc($rs);
	
	switch( $num_bedrooms )
	{
		case 1:
			return $row["1bed"];
		case 2:
			return $row["2bed"];
		case 3:
			return $row["3bed"];
		case 4:
			return $row["4bed"];
		case 5:
			return $row["5bed"];
		default:
			// fail safe!
			return $row["3bed"];		
	}
}

/**
 create and return a Property object from the GET data received in the HTTP request
*/
function construct_client_property() 
{
	global $property_type_id;
	global $bedrooms;
	global $bathrooms;
	global $central_heating;
	global $parking;
	global $kitchen_new;
	global $conservatory;
	global $conversion;
	
	//// create a client property to match against ...
	$client_row = null;
	$client_row["id"] = 99;
	$client_row["latitude"] = 1;
	$client_row["longitude"] = 2;
	$client_row["property_type_id"] = $property_type_id;
	$client_row["bedrooms"] = $bedrooms;
	$client_row["bathrooms"] = $bathrooms;
	$client_row["parking"] = $parking;
	$client_row["conversion"] = $conversion;
	$client_row["kitchen_new"] = $kitchen_new;
	$client_row["conservatory"] = $conservatory;
	$client_row["central_heating"] = $central_heating;
	$client_row["asking_price"] = 0;
	$client_row["distance"] = 0;
	$client_row["distance_to_dublin_center"] = 0;
	
	$client = new Property($client_row);
	return $client;
}

?>