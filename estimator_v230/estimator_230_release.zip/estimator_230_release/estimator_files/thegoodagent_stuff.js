
	$(document).ready(function() {
		$('#paypalform').submit();
		/* Load latest post from twitter (for the footer) */
		$("#twitter").getTwitter({
			userName: "AskTheGoodAgent",
			numTweets: 1,
			loaderText: "Loading tweets...",
			slideIn: true,
			slideDuration: 750,
			showHeading: false,
			headingText: "",
			showProfileLink: false,
			showTimestamp: true
		});
		
		/* Horizontal scrollable featured properties */
		jQuery('#feature_properties_brws').jcarousel({
			wrap: 'circular',
			scroll: 1,
			auto:3
		});

		/* Hide sign up text when clicking in the text input */
		var defaultNewsletterText = "Sign Up For Our Newsletter";
		$("#newsletter_input").focus(function(){if($(this).attr("value")==defaultNewsletterText){$(this).attr("value", "");}});
		$("#newsletter_input").blur(function(){if($(this).attr("value")==""){$(this).attr("value", defaultNewsletterText);}});
		
		
		/* Detect click outside of login form to hide it */
		var mouse_is_login = false;
		var login_is_visible = false;
		$('#signin_btn').hover(function()
		{ 
			mouse_is_login=true; 
		},
		function()
		{ 
			mouse_is_login=false; 
		});
		$('#login_cntr').hover(function()
		{ 
			mouse_is_login=true; 
		},
		function()
		{ 
			mouse_is_login=false; 
		});
		
		$('body').mouseup(function(){ 
			if(! mouse_is_login)
			{
				//hide and reset login box
				$("#signin_btn").removeClass("active");
				$('#login_cntr').removeClass("active");
				login_is_visible = false;
				
			}
		});

		/* Toggle show/hide login form - events on sign in button */
		$("#signin_btn").click(function()
		{
			if(login_is_visible == false)
			{
				$(this).addClass("active");
				$('#login_cntr').addClass("active");
				login_is_visible = true;
			}
			else
			{
				$("#signin_btn").removeClass("active");
				$('#login_cntr').removeClass("active");
				login_is_visible = false
			}
			return false;
		});
		
		 
		/* JAVASCRIPT FOR SIDE TABS */
		//Get all the LI from the #top_tab_menu UL
		$('#side_tab_menu > li').click(function(){

			//remove the selected class from all LI    
			$('#side_tab_menu > li').removeClass('selected');

			//Reassign the LI
			$(this).addClass('selected');

			//Hide all the DIV in .top_tab_body
			$('.side_tab_body div').slideUp('1500');

			//Look for the right DIV in top_tab_body according to the Navigation UL index, therefore, the arrangement is very important.
			$('.side_tab_body div:eq(' + $('#side_tab_menu > li').index(this) + ')').slideDown('1500');

			}).mouseover(function() {

			//Add and remove class, Personally I dont think this is the right way to do it, anyone please suggest    
			$(this).addClass('mouseover');
			$(this).removeClass('mouseout');   

			}).mouseout(function() {

			//Add and remove class
			$(this).addClass('mouseout');
			$(this).removeClass('mouseover');    

		});
		
		/* FORM SUBMIT ROLLOVERS */
		(function($) {
		var cache = [];
		// Arguments are image paths relative to the current page.
		$.preLoadImages = function() {
			var args_len = arguments.length;
			for (var i = args_len; i--;) {
				var cacheImage = document.createElement('img');
				cacheImage.src = arguments[i];
				cache.push(cacheImage);
			}
		}
		})(jQuery)
		/********************/
		/* popup box */
		/*******************/
		//thickbox replacement
		var closeModal = function(hash)
		{
			var $modalWindow = $(hash.w);
	 
			//$('#jqmContent').attr('src', 'blank.html');
			$modalWindow.fadeOut('2000', function()
			{
				hash.o.remove();
				//refresh parent
	 
				if (hash.refreshAfterClose === 'true')
				{
					 window.location.href = document.location.href;
				}
			});
		};
		var openInFrame = function(hash)
		{
			var $trigger = $(hash.t);
			var $modalWindow = $(hash.w);
			var $modalContainer = $('iframe', $modalWindow);
			var myUrl = $trigger.attr('href');
			var myTitle = $trigger.attr('title');
			var newWidth = 0, newHeight = 0, newLeft = 0, newTop = 0;
			$modalContainer.html('').attr('src', myUrl);
			$('#jqmTitleText').text(myTitle);
			myUrl = (myUrl.lastIndexOf("#") > -1) ? myUrl.slice(0, myUrl.lastIndexOf("#")) : myUrl;
			var queryString = (myUrl.indexOf("?") > -1) ? myUrl.substr(myUrl.indexOf("?") + 1) : null;
	 
			if (queryString != null && typeof queryString != 'undefined')
			{
				var queryVarsArray = queryString.split("&");
				for (var i = 0; i < queryVarsArray.length; i++)
				{
					if (unescape(queryVarsArray[i].split("=")[0]) == 'width')
					{
						var newWidth = queryVarsArray[i].split("=")[1];
					}
					if (escape(unescape(queryVarsArray[i].split("=")[0])) == 'height')
					{
						var newHeight = queryVarsArray[i].split("=")[1];
					}
					if (escape(unescape(queryVarsArray[i].split("=")[0])) == 'jqmRefresh')
					{
						// if true, launches a "refresh parent window" order after the modal is closed.
	 
						hash.refreshAfterClose = queryVarsArray[i].split("=")[1]
					} else
					{
	 
						hash.refreshAfterClose = false;
					}
				}
				// let's run through all possible values: 90%, nothing or a value in pixel
				if (newHeight != 0)
				{
					if (newHeight.indexOf('%') > -1)
					{
	 
						newHeight = Math.floor(parseInt($(window).height()) * (parseInt(newHeight) / 100));
	 
					}
					var newTop = Math.floor(parseInt($(window).height() - newHeight) / 2);
				}
				else
				{
					newHeight = $modalWindow.height();
				}
				if (newWidth != 0)
				{
					if (newWidth.indexOf('%') > -1)
					{
						newWidth = Math.floor(parseInt($(window).width() / 100) * parseInt(newWidth));
					}
					var newLeft = Math.floor(parseInt($(window).width() / 2) - parseInt(newWidth) / 2);
	 
				}
				else
				{
					newWidth = $modalWindow.width();
				}
	 
				// do the animation so that the windows stays on center of screen despite resizing
				$modalWindow.css({
					width: newWidth,
					height: newHeight,
					opacity: 0
				}).jqmShow().animate({
					width: newWidth,
					height: newHeight,
					top: newTop,
					left: newLeft,
					marginLeft: 0,
					opacity: 1
				}, 'slow');
			}
			else
			{
				// don't do animations
				$modalWindow.jqmShow();
			}
	 
		}
		//pressing view basket
		var baskIsVis = 0;
		$('#basket_reminder').click(function()
		{
			baskIsVis = 1 - baskIsVis;
			if(baskIsVis==1)
			{//show the "hide basket" button instead
				$('.basket_btn').addClass("hide_basket");
			}
			else
			{
				$('.basket_btn').removeClass("hide_basket");
			}
			$('.sbasket_full').slideToggle("fast");
			
			//alert(email_form_name);
			return false;
		});

		
		$('#modalWindow').jqm
		({
				overlay: 70,
				modal: true,
				trigger: 'a.thickbox',
				target: '#jqmContent',
				onHide: closeModal,
				onShow: openInFrame
		});
		
	});
