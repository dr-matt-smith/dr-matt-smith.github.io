	<?php

// get record set containing properties likely to be within MAX = $rs
require_once("aa_matt_geo_recordset.php");

// get data from GET
$property_type_id = 0;
if( filter_has_var(INPUT_GET, "property_type_id") ) 
{
	$property_type_id = filter_input(INPUT_GET, "property_type_id");
}	

$bedrooms = 0;
if( filter_has_var(INPUT_GET, "bedrooms") ) 
{
	$bedrooms = filter_input(INPUT_GET, "bedrooms");
}	

$bathrooms = 0;
if( filter_has_var(INPUT_GET, "bathrooms") ) 
{
	$bathrooms = filter_input(INPUT_GET, "bathrooms");
}	

$central_heating = 0;
if( filter_has_var(INPUT_GET, "central_heating") ) 
{
	$central_heating = filter_input(INPUT_GET, "central_heating");
}	

$parking = 0;
if( filter_has_var(INPUT_GET, "parking") ) 
{
	$parking = filter_input(INPUT_GET, "parking");
}	

$kitchen_new = 0;
if( filter_has_var(INPUT_GET, "kitchen_new") ) 
{
	$kitchen_new = filter_input(INPUT_GET, "kitchen_new");
}	

$conservatory = 0;
if( filter_has_var(INPUT_GET, "conservatory") ) 
{
	$conservatory = filter_input(INPUT_GET, "conservatory");
}	

$conversion = 0;
if( filter_has_var(INPUT_GET, "conversion") ) 
{
	$conversion = filter_input(INPUT_GET, "conversion");
}	


function construct_client_property() 
{
	global $property_type_id;
	global $bedrooms;
	global $bathrooms;
	global $central_heating;
	global $parking;
	global $kitchen_new;
	global $conservatory;
	global $conversion;
	
	//// create a client property to match against ...
	$client_row = null;
	$client_row["id"] = 99;
	$client_row["latitude"] = 1;
	$client_row["longitude"] = 2;
	$client_row["property_type_id"] = $property_type_id;
	$client_row["bedrooms"] = $bedrooms;
	$client_row["bathrooms"] = $bathrooms;
	$client_row["parking"] = $parking;
	$client_row["conversion"] = $conversion;
	$client_row["kitchen_new"] = $kitchen_new;
	$client_row["conservatory"] = $conservatory;
	$client_row["central_heating"] = $central_heating;
	$client_row["asking_price"] = 0;
	$client_row["distance"] = 0;
	$client_row["distance_to_dublin_center"] = 0;
	
	$client = new Property($client_row);
	return $client;
}

// OBJECT containing set of properties within NEIGHBOUR range
$referencePropertySets = new ReferencePropertySets();

while( $row = mysql_fetch_assoc($rs) )
{
	// get next property
	$p = new Property($row);
	
	// add it to approprite set (neighbour/max) if appropriate
	$referencePropertySets->add_property($p);

}

// housekeeping - close DB connection
mysql_close($connection);

// now process the proeprties collected ....
// now process the proeprties collected ....
// now process the proeprties collected ....

$np = $referencePropertySets->getNumNeighbourProperties();
$mp = $referencePropertySets->getNumMaxProperties();

$isSufficientNeighbourProperties = $referencePropertySets->isSufficientNeighbourProperties();
if( $isSufficientNeighbourProperties )
{
	$isSufficientNeighbourProperties = "true";
}
else
{
	$isSufficientNeighbourProperties = "false";
}

$isSufficientMaxProperties = $referencePropertySets->isSufficientMaxProperties();
if( $isSufficientMaxProperties )
{
	$isSufficientMaxProperties = "true";
}
else
{
	$isSufficientMaxProperties = "false";
}

// test matching algorithm	
$client_p = construct_client_property();

$html1 = $referencePropertySets->test_output();
$referencePropertySets->match($client_p);
$html2 = $referencePropertySets->test_output();

$html3 = "";
$html3 .= "<br/>referencePropertySets->getTotalWeights() = ".$referencePropertySets->getMaxTotalWeights();
$html3 .= "<br/>referencePropertySets->getTotalAskingPrice() = ".$referencePropertySets->getMaxTotalAskingPrice();
$html3 .= "<br/>referencePropertySets->getTotalConfidence() = ".$referencePropertySets->getMaxTotalConfidence();

$average = $referencePropertySets->getMaxTotalAskingPrice() / $referencePropertySets->getMaxTotalWeights();
$html3 .= "<br/>average asking price = referencePropertySets->getTotalAskingPrice() / referencePropertySets->getTotalWeights(); = $average";
$html = <<<HERE


<html>
<body>
<p>
property_type_id = $property_type_id
<br/>
bedrooms = $bedrooms
<br/>
bathrooms = $bathrooms
<br/>
heating = $central_heating
<br/>
parking = $parking
<br/>
kitchen_new = $kitchen_new
<br/>
conversion = $conversion
<br/>
conservatory = $conservatory
<br/>

</p>

<p>
number of neighbour properties = $np

<p>
number of max properties = $mp

<p>
isSufficientNeighbourProperties = $isSufficientNeighbourProperties

<p>
isSufficientMaxProperties = $isSufficientMaxProperties

<hr/>
<h2>test property BEFORE matching</h2>
$html1;
<hr/>
<h2>test property AFTER matching</h2>
$html2;

<hr/>
<h2>total weights for calculation</h2>
$html3;

</body>
</html>

HERE;

print $html;
?>


