<?php
// load classes
require_once("classes/class_loader.php");

// get connection to DB "$connection, $db"
require_once("zz_matt_db_connect.php");

// create SQL query string
$query = "SELECT * FROM county ORDER BY menu_sequence";

// run query and store the "result set"
$rs = mysql_query($query, $connection);

// error message if no result set from query ...
if( !$rs ) die( "ERROR: query did not return a result set: $query");

//  loop for each row, building up "message" string
$county_menu_html = "";
while( $row = mysql_fetch_assoc($rs) )
{
	$region_id = $row["region_id"];
	$county_name = $row["county_name"];
	
	// county name
	$county_menu_html .= "<option value='$region_id'>$county_name</option>";
	$county_menu_html .= "\n";
}

// housekeeping - close DB connection
mysql_close($connection);

echo $county_menu_html;
?>



