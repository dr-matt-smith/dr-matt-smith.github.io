<?php
//------------------------------------------------------
// (1) prep - start session and set defaults to error ...
//------------------------------------------------------

//
// first thing always - ensure session continued (or new one started)
session_start();

// default to error page
$redirect_page = "DISPLAY_error.php";

// get name of this file
$thisPage = $_SERVER['PHP_SELF'];
$filename = ltrim(strrchr($thisPage, '/'), '/');

// default error message is unknown error from this page!
$error_message = "unkown error - source 'filename'";
$_SESSION["error_message"] = $error_message;

// check whether user already logged in ...
require_once("SECURE_INCLUDE_check_login_status.php");

//------------------------------------------------------
// (2) error redirect if not logged in ...
//------------------------------------------------------

//
// IF
//		NOT logged in
// THEN
//		NOT AUTHORISED to view this page !
//		redirect with error message
//
if( TRUE != $is_logged_in )
{
	// ensure not logged in as anyone
	$_SESSION["login_username"] = NULL;

	// error message tells user bad username or password
	// and gives link to login again
	$error_message = "you are not authroised to view this page without first <a href='DISPLAY_login.php'>logging in ...</a>";
	$_SESSION["error_message"] = $error_message;
	
	//------------------------------------------------------
	// *** REDIRECT to another page
	//------------------------------------------------------
	header("Location: $redirect_page");
}



//------------------------------------------------------
// (3) get values from POST
//------------------------------------------------------

//
// get timestamp
//
$year_month = "";
if( filter_has_var(INPUT_POST, "year_month") ) 
{
	$year_month = filter_input(INPUT_POST, "year_month");
}	

//
// get dublin_percentage
//
$dublin_percentage = "";
if( filter_has_var(INPUT_POST, "dublin_percentage") ) 
{
	$dublin_percentage = filter_input(INPUT_POST, "dublin_percentage");
}	

//
// get national_percentage
//
$national_percentage = "";
if( filter_has_var(INPUT_POST, "national_percentage") ) 
{
	$national_percentage = filter_input(INPUT_POST, "national_percentage");
}	


//------------------------------------------------------
// (4) check numeric values 
//------------------------------------------------------

$all_numeric = TRUE;

if( !is_numeric( $dublin_percentage ) ||  !is_numeric( $national_percentage ) )
{
	$all_numeric = FALSE;
}

//------------------------------------------------------
// (4) attempt to delete CSO record with given ID
//------------------------------------------------------

if( $all_numeric )
{
	// get connection to DB "$connection, $db"
	require_once("../zz_matt_db_connect.php");
	
/*
	$sql_update_string = "INSERT INTO cso_rppi ";
	$sql_update_string .= "(dublin, national, year_month) ";
	$sql_update_string .= " VALUES ";
	$sql_update_string .= "( $dublin_percentage, $national_percentage, '$year_month' )";
*/

	$sql_update_string = "INSERT INTO `cso_rppi` (`id`, `dublin`, `national`, `year_month`) VALUES ";
	$sql_update_string .= "( NULL, $dublin_percentage, $national_percentage, '$year_month' )";


/*
INSERT INTO `mattsmit_dev`.`cso_rppi` (
`id` ,
`dublin` ,
`national` ,
`year_month`
)
VALUES (
NULL , '23', '23', '2020-01'
);

	*/
	
//INSERT INTO `mattsmit_dev`.`cso_rppi` (`id`, `dublin`, `national`, `year_month`) VALUES (NULL, '88', '77', '2013-11');

/*
INSERT INTO 
`cso_rppi` 
(`dublin`, `national`, `year_month`) 
VALUES 
('88', '77', '2013-11')
*/
	
	$insert_was_successful = mysql_query($sql_update_string, $connection);

	if( $insert_was_successful )
	{
		$redirect_page = "SECURE_DISPLAY_cso.php";
	}
	else
	{
		// problem with DELETE, so will redirect to Error page ...
		$error_message = "Error - there was a problem attempting to INSERT CSO record with the following SQL query: $sql_update_string";
		$_SESSION["error_message"] = $error_message;
	}
}
else
{
		// problem with non-numeric data
		$error_message = "Error - there was a problem with the received new record data (NON-numeric?): ";
		$error_message .= "year_month = '$year_month', ";
		$error_message .= "dublin_percentage = '$dublin_percentage', ";
		$error_message .= "national_percentage = '$national_percentage'";
		$_SESSION["error_message"] = $error_message;
}

//------------------------------------------------------
// (5)  *** REDIRECT to appropriate page
//------------------------------------------------------
header("Location: $redirect_page");

?>