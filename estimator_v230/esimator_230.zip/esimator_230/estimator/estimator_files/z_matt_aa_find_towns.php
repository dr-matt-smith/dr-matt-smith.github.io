<?php
// load classes
require_once("classes/class_loader.php");

// get connection to DB "$connection, $db"
require_once("zz_matt_db_connect.php");

  /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
  /*  Selection of points within specified radius of given lat/lon (c) Chris Veness 2008-2010       */
  /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */


/*
  $lat = $_GET['lat'];  // latitude of centre of bounding circle in degrees
  $lon = $_GET['lon'];  // longitude of centre of bounding circle in degrees
  $rad = $_GET['rad'];  // radius of bounding circle in kilometers
 */
  
  // search 2Km from Leixlip ...
  $lat = 53.3658333;
  $lon = -6.4955556;
  $rad = 5; 
  
  $R = 6371;  // earth's radius, km
  
  // first-cut bounding box (in degrees)
  $maxLat = $lat + rad2deg($rad/$R);
  $minLat = $lat - rad2deg($rad/$R);
  // compensate for degrees longitude getting smaller with increasing latitude
  $maxLon = $lon + rad2deg($rad/$R/cos(deg2rad($lat)));
  $minLon = $lon - rad2deg($rad/$R/cos(deg2rad($lat)));
  
  // convert origin of filter circle to radians
  $lat = deg2rad($lat);
  $lon = deg2rad($lon);
  
  $query = "
    Select Latitude, Longtitude, 
           acos(sin($lat)*sin(radians(Latitude)) + cos($lat)*cos(radians(Latitude))*cos(radians(Longitude)-$lon))*$R As D
    From (
      Select *
      From MyTable
      Where Latitude>$minLat And Latitude<$maxLat
        And Longtitude>$minLon And Longtitude<$maxLon
      ) As FirstCut 
    Where acos(sin($lat)*sin(radians(Latitude)) + cos($lat)*cos(radians(Latitude))*cos(radians(Longitude)-$lon))*$R < $rad
    Order by D";

  $query = "
    Select *
      From city
      Where Latitude>$minLat And Latitude<$maxLat
        And Longitude>$minLon And Longitude<$maxLon
      ";

  $query = "
    Select latitude, longitude, city, 
             acos(sin($lat)*sin(radians(latitude)) + cos($lat)*cos(radians(latitude))*cos(radians(longitude)-$lon))*$R As D

      From city
      Where latitude>$minLat And latitude<$maxLat
        And longitude>$minLon And longitude<$maxLon
      ";

  
 // $points = $db->query($sql, PDO::FETCH_OBJ);
  
  
// run query and store the "result set"
$rs = mysql_query($query, $connection);

// error message if no result set from query ...
if( !$rs ) die( "ERROR: query did not return a result set: $query");


//  loop for each row, building up "message" string
$html = "";
while( $row = mysql_fetch_assoc($rs) )
{
    $town_name = $row["city"];
    $lat = $row["latitude"];
    $long = $row["longitude"];
    $distance = $row["D"];
    
    $lat_nf = number_format($lat,3);
    $long_nf = number_format($long,3);
    $distance_nf = number_format($distance,3);
                
$html .= "<tr>";
$html .= "\n";
$html .= "<td>$town_name</td>";
$html .= "\n";
$html .= "<td>$distance_nf</td>";
$html .= "\n";
$html .= "<td>$lat_nf</td>";
$html .= "\n";
$html .= "<td>$long_nf</td>";
$html .= "\n";
$html .= "</tr>";
$html .= "\n";
    
    
}

// housekeeping - close DB connection
mysql_close($connection);
?>



<html>
<body>
    <h3>Towns within <?php print($rad); ?> of Leixlip</h3>
<table border="1">
    <tr>
        <th>Town name</th>
        <th>Distance from Leixlip</th>
        <th>Latitude</th>
        <th>Longitude</th>
    </tr>
<?php 
    print( $html );
?>
</table>
</body>
</html>


<?php

/* orig code

  
  require 'inc/dbparams.inc.php';  // defines $dsn, $username, $password
  
  $lat = $_GET['lat'];  // latitude of centre of bounding circle in degrees
  $lon = $_GET['lon'];  // longitude of centre of bounding circle in degrees
  $rad = $_GET['rad'];  // radius of bounding circle in kilometers
  
  $R = 6371;  // earth's radius, km
  
  // first-cut bounding box (in degrees)
  $maxLat = $lat + rad2deg($rad/$R);
  $minLat = $lat - rad2deg($rad/$R);
  // compensate for degrees longitude getting smaller with increasing latitude
  $maxLon = $lon + rad2deg($rad/$R/cos(deg2rad($lat)));
  $minLon = $lon - rad2deg($rad/$R/cos(deg2rad($lat)));
  
  // convert origin of filter circle to radians
  $lat = deg2rad($lat);
  $lon = deg2rad($lon);

  $db = new PDO($dsn, $username, $password);
  
  $sql = "
    Select ID, Postcode, Lat, Lon, 
           acos(sin($lat)*sin(radians(Lat)) + cos($lat)*cos(radians(Lat))*cos(radians(Lon)-$lon))*$R As D
    From (
      Select ID, Postcode, Lat, Lon
      From MyTable
      Where Lat>$minLat And Lat<$maxLat
        And Lon>$minLon And Lon<$maxLon
      ) As FirstCut 
    Where acos(sin($lat)*sin(radians(Lat)) + cos($lat)*cos(radians(Lat))*cos(radians(Lon)-$lon))*$R < $rad
    Order by D";
  
  $points = $db->query($sql, PDO::FETCH_OBJ);
*/


/*
<html>
<body>
<table>
<?php foreach ($points as $point): ?>
  <tr>
    <td><?= $point->Postcode ?></td>
    <td><?= number_format($point->D,1) ?></td>
    <td><?= number_format($point->Lat,3) ?></td>
    <td><?= number_format($point->Lon,3) ?></td>
  </tr>
<? endforeach ?>
</table>
</body>
</html>
  

 */
?>