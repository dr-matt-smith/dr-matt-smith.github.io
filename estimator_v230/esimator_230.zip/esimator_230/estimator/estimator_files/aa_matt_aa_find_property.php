<?php
<?php
// load classes
require_once("classes/class_loader.php");

// get connection to DB "$connection, $db"
require_once("zz_matt_db_connect.php");

  /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
  /*  Selection of points within specified radius of given lat/lon (c) Chris Veness 2008-2010       */
  /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */


/*
  $lat = $_GET['lat'];  // latitude of centre of bounding circle in degrees
  $lon = $_GET['lon'];  // longitude of centre of bounding circle in degrees
  $rad = $_GET['rad'];  // radius of bounding circle in kilometers
 */
  
  // search 2Km from Leixlip ...
  $lat = 53.32599;
  $lon = -6.26765;
  
  // radius of area to search for properties
  $rad = 10.0; 
  
  $R = 6371;  // earth's radius, km
  
  // first-cut bounding box (in degrees)
  $maxLat = $lat + rad2deg($rad/$R);
  $minLat = $lat - rad2deg($rad/$R);
  // compensate for degrees longitude getting smaller with increasing latitude
  $maxLon = $lon + rad2deg($rad/$R/cos(deg2rad($lat)));
  $minLon = $lon - rad2deg($rad/$R/cos(deg2rad($lat)));
  
  // convert origin of filter circle to radians
  $lat = deg2rad($lat);
  $lon = deg2rad($lon);
  
  $query = "
    Select Latitude, Longtitude, 
           acos(sin($lat)*sin(radians(Latitude)) + cos($lat)*cos(radians(Latitude))*cos(radians(Longitude)-$lon))*$R As D
    From (
      Select *
      From MyTable
      Where Latitude>$minLat And Latitude<$maxLat
        And Longtitude>$minLon And Longtitude<$maxLon
      ) As FirstCut 
    Where acos(sin($lat)*sin(radians(Latitude)) + cos($lat)*cos(radians(Latitude))*cos(radians(Longitude)-$lon))*$R < $rad
    Order by D";

  $query = "
    Select *
      From city
      Where Latitude>$minLat And Latitude<$maxLat
        And Longitude>$minLon And Longitude<$maxLon
      ";

  $query = "
    Select latitude, longitude, id, rent, asking_price,
             acos(sin($lat)*sin(radians(latitude)) + cos($lat)*cos(radians(latitude))*cos(radians(longitude)-$lon))*$R As D

      From property
      Where latitude>$minLat And latitude<$maxLat
        And longitude>$minLon And longitude<$maxLon
      ";

  
 // $points = $db->query($sql, PDO::FETCH_OBJ);
  
  
// run query and store the "result set"
$rs = mysql_query($query, $connection);

// error message if no result set from query ...
if( !$rs ) die( "ERROR: query did not return a result set: $query");


//  loop for each row, building up "message" string
$html = "";
while( $row = mysql_fetch_assoc($rs) )
{
    $id = $row["id"];
    $lat = $row["latitude"];
    $long = $row["longitude"];
    $rent = $row["rent"];
    $p = $row["asking_price"];
    $distance = $row["D"];
    
    $lat_nf = number_format($lat,3);
    $long_nf = number_format($long,3);
    $distance_nf = number_format($distance,3);
    
    $asking_price = Property::rent_to_price( $rent );
                
$html .= "<tr>";
$html .= "\n";
$html .= "<td>$id</td>";
$html .= "\n";
$html .= "<td>$distance_nf</td>";
$html .= "\n";
$html .= "<td>$lat_nf</td>";
$html .= "\n";
$html .= "<td>$long_nf</td>";
$html .= "\n";
$html .= "<td>$rent</td>";
$html .= "\n";
$html .= "<td>$asking_price (calc)</td>";
$html .= "\n";
$html .= "<td>$p (from DB)</td>";
$html .= "\n";
$html .= "</tr>";
$html .= "\n";
    
    
}

// housekeeping - close DB connection
mysql_close($connection);
?>



<html>
<body>
    <h3>Towns within <?php print($rad); ?> of ?? Rathmines town centre ??</h3>
<table border="1">
    <tr>
        <th>Property ID</th>
        <th>Distance from LOCATION</th>
        <th>Latitude</th>
        <th>Longitude</th>
        <th>Rent</th>
        <th>Asking price</th>
    </tr>
<?php 
    print( $html );
?>
</table>
</body>
</html>
