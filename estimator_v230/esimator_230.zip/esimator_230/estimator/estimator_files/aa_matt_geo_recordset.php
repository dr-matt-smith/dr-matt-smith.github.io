<?php
// load classes
require_once("classes/class_loader.php");

// get connection to DB "$connection, $db"
require_once("zz_matt_db_connect.php");

?>

<?php

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
/*  Selection of points within specified radius of given lat/lon (c) Chris Veness 2008-2010       */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */

// source of geo-neighbour code ...

?>

<?php

//*********
//*** 1 *** default values
//*********

// rad is MAX RANGE Km
$rad = Parameters::MAX_RANGE;

// note - assume lat/lon are initially in DEGREES (a la GoogleMaps API ...)

// default lat/long location = Rathmines
$lat = 53.32599;
$lon = -6.26765;

//*********
//*** 2 *** extract lat/long from GET parameters
//*********
// if lat/long are found as GET parameters, then use these new values
if( filter_has_var(INPUT_GET, "lat") ) 
{
	$lat = filter_input(INPUT_GET, "lat");
}

if( filter_has_var(INPUT_GET, "lon") ) 
{
	$lon = filter_input(INPUT_GET, "lon");
}

//*********
//*** 3 *** calcualte (over-generous) bounding box for fast subset of property database
//*********

// radius of the Earth in Km 
$R = Geofunctions::R;

// first-cut bounding box (in degrees)
$maxLat = $lat + rad2deg($rad/$R);
$minLat = $lat - rad2deg($rad/$R);
// compensate for degrees longitude getting smaller with increasing latitude
$maxLon = $lon + rad2deg($rad/$R/cos(deg2rad($lat)));
$minLon = $lon - rad2deg($rad/$R/cos(deg2rad($lat)));
  
// convert origin of filter circle to radians
$lat = deg2rad($lat);
$lon = deg2rad($lon);

$lat_dublin_center = Parameters::DUBLIN_CENTER_LAT;
$lon_dublin_center = Parameters::DUBLIN_CENTER_LON;


/*
the following returns current_dublin and current_national
can then apply formula to make get net_asking_price

net_asking_price_dublin = price * (current_dublin / dublin);
net_asking_price_national = price * (current_national / national);

SELECT cso_rppi.dublin as dublin_current, cso_rppi.national as national_current FROM cso_rppi WHERE cso_rppi.year_month = (SELECT MAX(cso_rppi.year_month) FROM cso_rppi)

created a VIEW using the following:
----
WORKS:
----
SELECT cso_rppi.dublin as dublin_current, cso_rppi.national as national_current FROM cso_rppi WHERE cso_rppi.year_month = (SELECT MAX(cso_rppi.year_month) FROM cso_rppi)

----
useful VIEW to have ...
----
CREATE VIEW cso_current_view
(dublin_current, national_current)
AS
SELECT cso_rppi.dublin as dublin_current, cso_rppi.national as national_current FROM cso_rppi WHERE cso_rppi.year_month = (SELECT MAX(cso_rppi.year_month) FROM cso_rppi)


so can now talk about: 
	SELECT dublin_current, national_current FROM cso_current_view
	
	
	
	
(2) need to use JOIN WITH cso_current_view to convert from historic to net_asking_price values;

SELECT Property.*, cso_rppi.*
FROM Property JOIN cso_rppi
ON Property.valuation_month = cso_rppi.year_month


*/

$query = "
			SELECT
				latitude, 
				longitude, 
				id, 
				property_type_id, 
				bedrooms, 
				bathrooms, 
				parking, 
				conversion, 
				kitchen_new, 
				conservatory, 
				central_heating, 
				asking_price,
				valuation_month,
				adjusted_dublin_asking_price,
				adjusted_national_asking_price,
				acos(sin($lat)*sin(radians(latitude)) + cos($lat)*cos(radians(latitude))*cos(radians(longitude)-$lon))*$R As distance,
				acos(sin($lat_dublin_center)*sin(radians(latitude)) + cos($lat_dublin_center)*cos(radians(latitude))*cos(radians(longitude)-$lon_dublin_center))*$R As distance_to_dublin_center
				
			FROM 
				property_cso_adjusted_valuation
			WHERE 
				latitude>$minLat And latitude<$maxLat
				And longitude>$minLon And longitude<$maxLon
		";

  
// run query and store the "result set"
$rs = mysql_query($query, $connection);

// error message if no result set from query ...
if( !$rs ) die( "ERROR: query did not return a result set: $query");

?>
