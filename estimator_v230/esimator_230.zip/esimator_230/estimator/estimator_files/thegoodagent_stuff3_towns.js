
	$(document).ready(function() {
	
		jQuery.preLoadImages('http://www.thegoodagent.ie/assets/images/logon/btn_vw.png', 'http://www.thegoodagent.ie/assets/images/layout/properties/search_btn_h.png');
		$("#sales_search_submit").hover
		(
			function ()
			{
				var src = "http://www.thegoodagent.ie/assets/images/layout/properties/search_btn_h.png";
				$(this).attr("src", src);
			}, 
			function ()
			{
				var src = "http://www.thegoodagent.ie/assets/images/layout/properties/search_btn.png";
				$(this).attr("src", src);
				$(this).find("span:last").remove();
			}
		);
	});
	
$(function()
	{

		$("#number_results").change(function() { this.form.submit(); }); 
		$("#sort_by").change(function() { this.form.submit(); }); 
		
		//pressing a thumbnail on a property and loading a new image
		$('.email_btn').click(function()
		{
			
			//$('this').parent.show('slow');
			var email_form_name = $(this).attr("id");
			$('#form_'+email_form_name).slideToggle("fast");
			
			//alert(email_form_name);
			return false;
		});
	});

