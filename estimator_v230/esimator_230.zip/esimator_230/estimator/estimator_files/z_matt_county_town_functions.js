

function estimator_town_record(town_name, lat, long)
{
	row = new Array(3);
	row[0] = town_name;
	row[1] = lat;
	row[2] = long;
	
	return row;
}

//format of data:
	// dimension 1 | county id
	// dimension 2 | town_index (town number for county)
	// dimension 3 | town data field
//
// example
	// county_id = 1 (unique county integer)
	// town_index = 2
	// town name = Townville
	// lat = 22
	// long = 33
//
// estimator_town_array[1][8][0] = "Townville"
// estimator_town_array[1][8][1] = 22;
// estimator_town_array[1][8][2] = 33;
//


function load_towns( county_id )
{	
	$("#search_town_option").children().remove() ;		// clear select box
	var options = '' ;
	options += '<option value="0">- Choose a town -</option>'; 
	
/*
	if( (0 == county_id) || (county_id > 31))
	{
	
	}
	else
	{
*/		var num_towns = estimator_town_array[county_id].length;
		for (var i = 0; i < num_towns; i++)
		{
			if((estimator_town_array[county_id][i] != null)&&(estimator_town_array[county_id][i] != undefined))
			{
				options += '<option value="' + i + '">' + estimator_town_array[county_id][i][0] + '</option>'; 
			}
		}
//	}
	$("#search_town_option").html(options);   // populate select box with array
}

//
var default_town = "";
$("#search_town_option").val(default_town);


//
//
//
function get_town_position( county_id, town_index  )
{
    var town_lat = estimator_town_array[county_id][town_index][1];
    var town_long = estimator_town_array[county_id][town_index][2];

    var town_lat_long_array = my_latlong_aray(town_lat, town_long);
    
    return google_maps_latlong( town_lat_long_array );
}
