<?php
// include - to create connection to DB for given username/password 

// define username and password
$username = "thegooda_ad31est";
$password = "tree62puppyBBC";

// specify location of internet host computer that is running mysql
$host = "localhost";

// try to get connection to this mysql for given host / username / password
$connection = mysql_connect($host, $username, $password) or die( "ERROR: could not connect to mysql on host '$host'");

// try to select database "itb" with the mysql database connection
$db = "thegooda_estimator";

mysql_select_db($db, $connection) or die( "ERROR: could not select database '$db'");

?>
