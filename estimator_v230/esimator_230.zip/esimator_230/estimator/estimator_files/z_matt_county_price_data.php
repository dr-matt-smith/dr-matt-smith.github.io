<?php
// load classes
require_once("classes/class_loader.php");

// get connection to DB "$connection, $db"
require_once("zz_matt_db_connect.php");

// create SQL query string
$query = "SELECT * FROM county ORDER BY menu_sequence";

// run query and store the "result set"
$rs = mysql_query($query, $connection);

// error message if no result set from query ...
if( !$rs ) die( "ERROR: query did not return a result set: $query");

//  loop for each row, building up "message" string
$county_prices_array = "";
$bed1_total = 0;
$bed2_total = 0;
$bed3_total = 0;
$bed4_total = 0;
$bed5_total = 0;

$count = 0;
while( $row = mysql_fetch_assoc($rs) )
{
	$region_id = $row["region_id"];
	$bed1 = $row["1bed"];
	$bed2 = $row["2bed"];
	$bed3 = $row["3bed"];
	$bed4 = $row["4bed"];
	$bed5 = $row["5bed"];
	
	// update totals
	$bed1_total += $bed1;
	$bed2_total += $bed2;
	$bed3_total += $bed3;
	$bed4_total += $bed4;
	$bed5_total += $bed5;
	$count++;
	
	// county price JS array construction
	// create array statements in the form:
	//	county_prices[1] = price_array(70, 101, 153, 196, 295);
	$county_prices_array .= "county_prices[$region_id] = price_array($bed1, $bed2, $bed3, $bed4, $bed5);";
	$county_prices_array .= "\n";
	
}

// calculate the mean prices
$bed1_mean = $bed1_total / $count;
$bed2_mean = $bed2_total / $count;
$bed3_mean = $bed3_total / $count;
$bed4_mean = $bed4_total / $count;
$bed5_mean = $bed5_total / $count;

$bed1_mean = round($bed1_mean);
$bed2_mean = round($bed2_mean);
$bed3_mean = round($bed3_mean);
$bed4_mean = round($bed4_mean);
$bed5_mean = round($bed5_mean);


// append for all counties - element 0
$county_prices_array .= "county_prices[0] = price_array($bed1_mean, $bed2_mean, $bed3_mean, $bed4_mean, $bed5_mean);";
$county_prices_array .= "\n";


// housekeeping - close DB connection
mysql_close($connection);
?>


var county_prices = new Array();
<?php
	print $county_prices_array; 
?>




