<?php
// load classes
require_once("classes/class_loader.php");

// get connection to DB "$connection, $db"
require_once("zz_matt_db_connect.php");

// create SQL query string
$query = "SELECT * FROM county ORDER BY menu_sequence";

// run query and store the "result set"
$rs = mysql_query($query, $connection);

// error message if no result set from query ...
if( !$rs ) die( "ERROR: query did not return a result set: $query");

//  loop for each row, building up "message" string
$county_name_array = "";
$county_latlong_array = "";
while( $row = mysql_fetch_assoc($rs) )
{
	$region_id = $row["region_id"];
	$county_name = $row["county_name"];
	$lat = $row["lat"];
	$long = $row["long"];
	
	// county name
	$county_name_array .= "county_name_array[$region_id] = ".'"'."$county_name".'";';
	$county_name_array .= "\n";
	
	// county location
	$county_latlong_array .= "county_latlong[$region_id] = my_latlong_aray($lat, $long);";
	$county_latlong_array .= "\n";
}

// housekeeping - close DB connection
mysql_close($connection);
?>


//
// county name
//
function county_name( county_id )
{
	return county_name_array[ county_id ];
}


var county_name_array = new Array();
<?php
	print $county_name_array; 
?>



//
// county/town location
//
var county_latlong = new Array();

function my_latlong_aray(lat, long)
{
	row = new Array(2);
	row[0] = lat;
	row[1] = long;
	
	return row;
}

function google_maps_latlong( my_latlong )
{
	var lat = my_latlong[0];
	var long = my_latlong[1];
	
	return new google.maps.LatLng(lat, long);
}

<?php
	print $county_latlong_array; 
?>




