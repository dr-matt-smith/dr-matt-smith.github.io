<?php

// load classes for property matching

require_once("Geofunctions.php");
require_once("Parameters.php");
require_once("Property.php");
require_once("PropertyList.php");
require_once("ReferencePropertySets.php");
require_once("EstimatorManager.php");

?>