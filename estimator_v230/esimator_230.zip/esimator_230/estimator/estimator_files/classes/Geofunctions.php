<?php

/**
--------------------------------------------
CLASS: Geofunctions
VERSION: 1.0 (Sep 2011)
AUTHOR: Dr Matt Smith
class to define geo-locational functions and constants
--------------------------------------------
*/
class Geofunctions
{
//--------------------------------------------
// CLASS - CONSTANTS
//--------------------------------------------

/** earth's radius, km */
const R = 6371;  

//--------------------------------------------
// STATIC CLASS METHODS
//--------------------------------------------

static public function price_to_rent( $price )
{
	$price = ($price * 1000);
	
	$year_rent = ($price / Parameters::INVESTMENT_YEARS);
	$monthly_rent = Math.round($year_rent/12);
	
	return $monthly_rent;
}

////////
static public function rent_to_price( $monthly_rent )
{
	$year_rent = ($monthly_rent * 12);
	$investment_rent = (Parameters::INVESTMENT_YEARS * $year_rent);
	$investment_rent = $investment_rent/1000;
	
	return $investment_rent;
}
	
//--------------------------------------------
// PROPERTIES
//--------------------------------------------
private $id = 0;
private $lat = 0.0;
private $long = 0.0;
private $property_type_id = 0;
private $bedrooms = 0;
private $bathrooms = 0;
private $parking = false;
private $conversion = false;
private $kitchen_new = false;
private $conservatory = false;
private $central_heating = false;
private $asking_price = 0;

private $distance = 0.0;


//--------------------------------------------
// METHODS - getters & setters
//--------------------------------------------

public function getId(){	return $this->id;	}
public function getLong(){	return $this->long;	}
public function getLat(){	return $this->lat;	}
public function getProperty_type_id(){	return $this->property_type_id;	}
public function getBedrooms(){	return $this->bedrooms;	}
public function getBathrooms(){	return $this->bathrooms;	}
public function getParking(){	return $this->parking;	}
public function getConversion(){	return $this->conversion;	}
public function getKitchen_new(){	return $this->kitchen_new;	}
public function getConservatory(){	return $this->conservatory;	}
public function getCentral_heating(){	return $this->central_heating;	}
public function getAsking_price(){	return $this->asking_price;	}

// number format gets ...
public function getLat_nf(){	return number_format($this->lat,3);	}
public function getLong_nf(){	return number_format($this->long,3);	}
public function getDistance_nf(){	return number_format($this->distance,3);	}


//--------------------------------------------
// METHODS - boolean inferred properties
//--------------------------------------------
public function isWithinNeighbourRange()
{
	return $this->distance < Parameters::NEIGHBOUR_RANGE; 	
}

public function isBetweenNeighbourMaxRange()
{
	// must be within MAX_RANGE, but not within NEIGHBOUR_RANGE
	return ($this->distance < Parameters::MAX_RANGE) && ($this->distance >= Parameters::NEIGHBOUR_RANGE);
}

//--------------------------------------------
// METHODS
//--------------------------------------------

// extract properties from from DB row 
function __construct($row)
{
    $this->id = $row["id"];
    $this->lat = $row["latitude"];
    $this->long = $row["longitude"];
    $this->property_type_id = $row["property_type_id"];
    $this->bedrooms = $row["bedrooms"];
    $this->bathrooms = $row["bathrooms"];
    $this->parking = $row["parking"];
    $this->conversion = $row["conversion"];
    $this->kitchen_new = $row["kitchen_new"];
    $this->conservatory = $row["conservatory"];
    $this->central_heating = $row["central_heating"];
    $this->asking_price = $row["asking_price"];
	$this->distance = $row["distance"];
}

/*
only allowed 1 constructor

function __construct(	$lat, 
						$long, 
						$property_type_id, 
						$bedrooms, 
						$bathrooms, 
						$parking,
						$conversion,
						$kitchen_new,
						$conservatory,
						$central_heating,
						$asking_price
					)
{
	$this->lat = $lat;
	$this->long = $long;
	$this->property_type_id = $property_type_id;
	$this->bedrooms = $bedrooms;
	$this->bathrooms = $bathrooms;
	$this->parking = $parking;
	$this->conversion = $conversion;
	$this->kitchen_new = $kitchen_new;
	$this->conservatory = $conservatory;
	$this->central_heating = $central_heating;
	$this->asking_price = $asking_price;
}
*/


} // class

?>