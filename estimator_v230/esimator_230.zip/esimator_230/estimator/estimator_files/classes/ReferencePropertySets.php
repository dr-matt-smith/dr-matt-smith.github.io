<?php

/**
--------------------------------------------
--------------------------------------------
CLASS: ReferencePropertySets
VERSION: 1.0 (Sep 2011)
AUTHOR: Dr Matt Smith
class to store and reason about the 2 sets of data for the estimation process 
- i.e. calculate weighted average based nearby matching properties

--------------------------------------------
--------------------------------------------
*/
class ReferencePropertySets
{

//--------------------------------------------
// PROPERTIES
//--------------------------------------------

/** set of properties within NEIGHBOUR range */
private $neighbour_plist;

/** set of properties between NEIGHBOUR and MAX range */
private $max_plist;

//--------------------------------------------
// METHODS - CONSTRUCTOR
//--------------------------------------------

public function __construct()
{
	// create the 2 property lists required
	$this->neighbour_plist = new PropertyList();
	$this->max_plist = new PropertyList();
}

//--------------------------------------------
// METHODS - getters & setters
//--------------------------------------------

/** 
return the number of properties within NEIGHBOUR range
i.e. inside the Neighbour Plist
*/
public function getNumNeighbourProperties()
{
	return $this->neighbour_plist->count();	
}

/** 
return the number of properties within MAX range
i.e. number of objects inside the Neighbour Plist PLUS the number inside the Max Plist
*/
public function getNumMaxProperties()
{
	return ($this->max_plist->count() + $this->neighbour_plist->count());	
}

public function getNeighbourTotalWeights()
{
	return $this->neighbour_plist->getTotalWeights();
}

public function getMaxTotalWeights()
{
	return ($this->neighbour_plist->getTotalWeights() + $this->max_plist->getTotalWeights());
}

public function getNeighbourTotalAskingPrice()
{
	return $this->neighbour_plist->getTotalAskingPrice();
}

public function getMaxTotalAskingPrice()
{
	return ($this->neighbour_plist->getTotalAskingPrice() + $this->max_plist->getTotalAskingPrice());
}

public function getNeighbourTotalConfidence()
{
	return $this->neighbour_plist->getTotalConfidence();
}

public function getMaxTotalConfidence()
{
	return ($this->neighbour_plist->getTotalConfidence() + $this->max_plist->getTotalConfidence());
}

//--------------------------------------------
// METHODS
//--------------------------------------------

/** function to return BOOLEAN as to whether number of Properties in neighbour list meets desirable NEIGHBOUR number */
public function isSufficientNeighbourProperties()
{
	return ($this->getNumNeighbourProperties() >= Parameters::DESIRABLE_NUM_VALUES_NEIGHBOUR_RANGE);
}

/** function to return BOOLEAN as to whether number of Properties in (neighbour list + max list) meets desirable MAX number */
public function isSufficientMaxProperties()
{
	$total_properties = $this->getNumNeighbourProperties() + $this->getNumMaxProperties();
	return ($total_properties >= Parameters::DESIRABLE_NUM_VALUES_MAX_RANGE);
}


/** add a property - to appropriate list */
public function add_property($p)
{
	if( $p->isWithinNeighbourRange())
	{
		$this->neighbour_plist->add_property($p);
	}
	else if( $p->isBetweenNeighbourMaxRange())
	{
		$this->max_plist->add_property($p);
	}
	else
	{
		// do nothing - reject property since it is too far from property to be estimated
	}
}

/** given details of client property, match all neighbour / max properties against its features */
public function match($p)
{
	$this->neighbour_plist->match($p);
	$this->max_plist->match($p);
}

//--------------------------------------------
// METHODS - for TESTING ONLY
//--------------------------------------------

public function test_output()
{
	return $this->neighbour_plist->test_output().$this->max_plist->test_output();
}

} // class

?>