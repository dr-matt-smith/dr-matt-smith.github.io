<?php

// load classes
require_once("classes/class_loader.php");

// get today's date as YEAR (YYYY) and MONTH (MM) numbers
$year_string = date("Y");
$month_string = date("m");

$year_num = intval( $year_string );
$month_num = intval( $month_string );

//  loop for each row, building up "message" string
$valuation_month_menu_html = "";

for( $i = 0; $i < 10; $i++)
{
	$format= "%02d";
	$month_string = sprintf($format, $month_num);
			
	$year_month = "$year_num-$month_string";
	$month_name = Property::month_name( $month_string );
	$year_month_name = "$month_name $year_num";

	// county name
	$valuation_month_menu_html .= "<option value='$year_month'>$year_month_name</option>";
	$valuation_month_menu_html .= "\n";

	// go back 1 month, 
	// so valuation month list is in reverse chronological order...
	$month_num--;
	if( $month_num < 1)
	{
		$month_num = 12;
		$year_num--;
	}

}


echo $valuation_month_menu_html;
?>




