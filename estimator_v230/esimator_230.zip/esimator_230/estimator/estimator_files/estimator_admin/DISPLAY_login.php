<?php session_start();

// first thing always - ensure session continued (or new one started)

// check whether user already logged in ...
require_once("SECURE_INCLUDE_check_login_status.php");

// HTML code for a login form
$login_page_HTML_string = <<<HERE
	<form
		name="login"
		action="SECURE_LOGIC_process_login.php"
		method="POST"
	/>
	
	<p>
		Username:
		<input type="text" name="username"/>
	</p>
	
	<p>
		Password:
		<input type="password" name="password"/>
	</p>
	
	<p>
		<input type="submit" value="Login"/>
	</p>
	
	</form>
HERE;


//
// IF
//		logged in
// THEN
//		instead of form, display message telling they are already logged-in
//
if( TRUE == $is_logged_in )
{
$login_page_HTML_string = <<<HERE
	<p>
		You are already logged in as <strong>$login_username</strong> !!
		<br/>
		do you wish to <a href="SECURE_LOGIC_logout.php">logout? </a> 
	</p>
HERE;

}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    
	<title>The Good Agent - estimator - admin login</title>
</head>

<body>

<h3>The Good Agent - estimator - admin login</h3>

<?php
	// ---------- display login form / message to logout here--------	
	print $login_page_HTML_string;
?>

</body>
</html>