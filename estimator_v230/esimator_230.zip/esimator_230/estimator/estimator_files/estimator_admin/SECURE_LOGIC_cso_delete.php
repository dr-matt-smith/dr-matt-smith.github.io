<?php
//------------------------------------------------------
// (1) prep - start session and set defaults to error ...
//------------------------------------------------------

//
// first thing always - ensure session continued (or new one started)
session_start();

// default to error page
$redirect_page = "DISPLAY_error.php";

// get name of this file
$thisPage = $_SERVER['PHP_SELF'];
$filename = ltrim(strrchr($thisPage, '/'), '/');

// default error message is unknown error from this page!
$error_message = "unkown error - source 'filename'";
$_SESSION["error_message"] = $error_message;

// check whether user already logged in ...
require_once("SECURE_INCLUDE_check_login_status.php");

//------------------------------------------------------
// (2) error redirect if not logged in ...
//------------------------------------------------------

//
// IF
//		NOT logged in
// THEN
//		NOT AUTHORISED to view this page !
//		redirect with error message
//
if( TRUE != $is_logged_in )
{
	// ensure not logged in as anyone
	$_SESSION["login_username"] = NULL;

	// error message tells user bad username or password
	// and gives link to login again
	$error_message = "you are not authroised to view this page without first <a href='DISPLAY_login.php'>logging in ...</a>";
	$_SESSION["error_message"] = $error_message;
	
	//------------------------------------------------------
	// *** REDIRECT to another page
	//------------------------------------------------------
	header("Location: $redirect_page");
}


//------------------------------------------------------
// (3) display record and ask for confirmation of delete action
//------------------------------------------------------
//
// get username from USER form data
//
$id = "";
if( filter_has_var(INPUT_GET, "id") ) 
{
	$id = filter_input(INPUT_GET, "id");
}	

//------------------------------------------------------
// (4) attempt to delete CSO record with given ID
//------------------------------------------------------

// get connection to DB "$connection, $db"
require_once("../zz_matt_db_connect.php");

$sql_query_string = "DELETE FROM cso_rppi WHERE id=$id";
$delete_was_successful = mysql_query($sql_query_string, $connection);

//------------------------------------------------------
// (5) set redirect page according to success (or not) of delete ...
//------------------------------------------------------

if( $delete_was_successful )
{
	$redirect_page = "SECURE_DISPLAY_cso.php";
}
else
{
	// problem with DELETE, so will redirect to Error page ...
	$error_message = "Error - there was a problem attempting to delete CSO record with id = $id";
	$_SESSION["error_message"] = $error_message;
}

//------------------------------------------------------
// (6)  *** REDIRECT to CSO list page
//------------------------------------------------------
header("Location: $redirect_page");

?>