<?php
// load classes
require_once("classes/class_loader.php");

// get connection to DB "$connection, $db"
require_once("zz_matt_db_connect.php");

//
// (1) get list of county id's ( id < 40, so only regions (whole counties) no city or county sub-divisions)
//
// create SQL query string
//$query = "SELECT * FROM county WHERE region_id < 40 ORDER BY region_id";
$query = "SELECT * FROM county ORDER BY region_id";

// run query and store the "result set"
$rs = mysql_query($query, $connection);

// error message if no result set from query ...
if( !$rs ) die( "ERROR: query did not return a result set: $query");

//  loop for each row, building up "message" string
$town_builder_html = "";
		
while( $row = mysql_fetch_assoc($rs) )
{
	$county_id = $row["region_id"];

	//
	// (2) for each county (region) get list of towns with their names and lat/long positon
	//
	
	// create SQL query string
//	$query = "SELECT * FROM city WHERE region_id = $county_id ORDER BY id ";
// 
// try using the new VIEW ...
//
	$query = "SELECT * FROM city WHERE region_id = $county_id ORDER BY id ";
	
	// run query and store the "result set"
	$rs2 = mysql_query($query, $connection);
	
	// error message if no result set from query ...
	if( !$rs2 ) die( "ERROR: query did not return a result set: $query");
	
	//  loop for each row, building up "message" string
	$town_builder_html .= "estimator_town_array[$county_id] = new Array();";
	$town_builder_html .= "\n";
	
	$town_index = 0;
	while( $row = mysql_fetch_assoc($rs2) )
	{
		/*
		PHP is writing JS to make use of this JS function:
		
		function estimator_town_record(index, town_id, town_name, lat, long)
		{
			row = new Array(4);
			row[0] = town_name;
			row[1] = lat;
			row[2] = long;
			
			return row;
		}
		*/

		$town_id = $row["id"];
		$town_name = $row["city"];
		$lat = $row["latitude"];
		$long = $row["longitude"];
		$town_builder_html .= "estimator_town_array[$county_id][$town_index] = estimator_town_record(".'"'.$town_name.'"'.", $lat, $long);";
		$town_builder_html .= "\n";
		
		$town_index++;
	}
	

	
	
}



// housekeeping - close DB connection
mysql_close($connection);
?>

var estimator_town_array = new Array();

<?php
	print $town_builder_html; 
?>

