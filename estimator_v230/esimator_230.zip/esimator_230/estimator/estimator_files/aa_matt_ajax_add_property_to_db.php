<?php

// load classes
require_once("classes/class_loader.php");

$g_temp = ";===============";



/**
 * given a value, and a value type, return the value converted into asking price
	html_string += '				<input type="radio" name="asking_price_or_rent_radio" id="asking_price_or_rent_radio" value="asking_price" checked="checked"/>';
	html_string += '				Asking Price';
	html_string += '				<br/>';
	html_string += '				<input type="radio" name="asking_price_or_rent_radio" id="asking_price_or_rent_radio" value="sold_price" checked="checked"/>';
	html_string += '				Price Sold At';
	html_string += '				<br/>';
	html_string += '				<input type="radio" name="asking_price_or_rent_radio" id="asking_price_or_rent_radio" value="rent"/>';
	html_string += '				Monthly rent';

 */
function convert_to_asking_price( $historic_value, $value_type )
{
	// default is that value given IS the asking price
	$asking_price = $historic_value;
	
	if( "sold_price" == $value_type )
	{
		// assume asking price was higher
		$asking_price = Property::selling_price_to_asking_price( $historic_value );
	}
	else if( "rent" == $value_type )
	{
		$asking_price = Property::rent_to_price( $historic_value );
	}

	return $asking_price;
}


?>



<?php

//
// (1)
// get connection to DB "$connection, $db"
require_once("zz_matt_db_connect.php");

//
// (2)
// get data from GET
$county_id = -1;
if( filter_has_var(INPUT_GET, "county_id") ) 
{
	$county_id = filter_input(INPUT_GET, "county_id");
}	

$property_type_id = 0;
if( filter_has_var(INPUT_GET, "property_type_id") ) 
{
	$property_type_id = filter_input(INPUT_GET, "property_type_id");
}	

$bedrooms = 0;
if( filter_has_var(INPUT_GET, "bedrooms") ) 
{
	$bedrooms = filter_input(INPUT_GET, "bedrooms");
}	

$bathrooms = 0;
if( filter_has_var(INPUT_GET, "bathrooms") ) 
{
	$bathrooms = filter_input(INPUT_GET, "bathrooms");
}	

$central_heating = 0;
if( filter_has_var(INPUT_GET, "central_heating") ) 
{
	$central_heating = filter_input(INPUT_GET, "central_heating");
}	

$parking = 0;
if( filter_has_var(INPUT_GET, "parking") ) 
{
	$parking = filter_input(INPUT_GET, "parking");
}	

$kitchen_new = 0;
if( filter_has_var(INPUT_GET, "kitchen_new") ) 
{
	$kitchen_new = filter_input(INPUT_GET, "kitchen_new");
}	

$conservatory = 0;
if( filter_has_var(INPUT_GET, "conservatory") ) 
{
	$conservatory = filter_input(INPUT_GET, "conservatory");
}	

$conversion = 0;
if( filter_has_var(INPUT_GET, "conversion") ) 
{
	$conversion = filter_input(INPUT_GET, "conversion");
}	

$value_type = 0;
if( filter_has_var(INPUT_GET, "value_type") ) 
{
	$value_type = filter_input(INPUT_GET, "value_type");
}	

$historic_value = 0;
if( filter_has_var(INPUT_GET, "historic_value") ) 
{
	$historic_value = filter_input(INPUT_GET, "historic_value");
}	

$value_type = "asking_price";
if( filter_has_var(INPUT_GET, "value_type") ) 
{
	$value_type = filter_input(INPUT_GET, "value_type");
}	

// need to convert depending on value type ...
$asking_price = convert_to_asking_price( $historic_value, $value_type );

// default to zeros (will record TODAY as date)
$valuation_month = "2011-12";
if( filter_has_var(INPUT_GET, "valuation_month") ) 
{
	$valuation_month = filter_input(INPUT_GET, "valuation_month");
}	

$latitude = 0;
if( filter_has_var(INPUT_GET, "lat") ) 
{
	$latitude = filter_input(INPUT_GET, "lat");
}	

$longitude = 0;
if( filter_has_var(INPUT_GET, "lon") ) 
{
	$longitude = filter_input(INPUT_GET, "lon");
}	


//
// (3)
// add new property to DB
// create SQL query string
$sql_update_string = "";

$sql_update_string .= "INSERT INTO property ";
$sql_update_string .= "(region_id, property_type_id, bedrooms, bathrooms, parking, conversion, kitchen_new, conservatory, central_heating, asking_price, latitude, longitude, valuation_month) ";
$sql_update_string .= " VALUES ";
$sql_update_string .= "($county_id, $property_type_id, $bedrooms, $bathrooms, $parking, $conversion, $kitchen_new, $conservatory, $central_heating, $asking_price, '$latitude', '$longitude', '$valuation_month' )";

/*

INSERT INTO property 
(region_id, property_type_id, bedrooms, bathrooms, parking, conversion, kitchen_new, conservatory, central_heating, asking_price, latitude, longitude, valuation_month)  
VALUES 
(78, 1, 3, 1, 0, 1, 1, 0, 1, 35, '53.354983819697665', '-6.287366142773408', '2011-11' )


*/

/*
(1, 76, 7834, 3, 'House', 3, 1, '1', 0, 0, 0, 0, 1400, 252, '53.32541', '-6.27023', '0000-00-00');

  `id` int(11) NOT NULL DEFAULT '0',
  `region_id` int(2) DEFAULT NULL,
  `town_id` int(4) DEFAULT NULL,
  `property_type_id` int(1) DEFAULT NULL,
  `type` varchar(9) DEFAULT NULL,
  `bedrooms` int(1) DEFAULT NULL,
  `bathrooms` int(1) DEFAULT NULL,
  `parking` varchar(1) DEFAULT NULL,
  `conversion` tinyint(1) NOT NULL,
  `kitchen_new` tinyint(1) NOT NULL,
  `conservatory` tinyint(1) NOT NULL,
  `central_heating` tinyint(1) NOT NULL,
  `rent` int(4) DEFAULT NULL,
  `asking_price` int(11) NOT NULL,
  `latitude` varchar(8) DEFAULT NULL,
  `longitude` varchar(8) DEFAULT NULL,
  `valuation_month` varchar(7) NOT NULL,
  

*/

// run query and store the "result set"
$update_was_successful = mysql_query($sql_update_string, $connection);

// housekeeping - close DB connection
mysql_close($connection);


// ***********************
// *** LOGIC - forward to appropriate page ...
// ***********************
// forward to approprite page depending on whether errors or not
$message = "message from; aa_matt_ajax_add_property_to_db.php"; 

if( $update_was_successful )
{
	print 1;
} 
else
{
	print 0;
}

print ";valuation_month = $valuation_month";
print ";value_type = $value_type";

print $g_temp;

?>