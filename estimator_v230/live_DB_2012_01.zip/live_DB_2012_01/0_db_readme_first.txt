ABOUT THIS FILE: These are the steps to complete to create the MySQL databse to support the asking price estimator

Step (1) 
use file: 1_db_user_details.txt

setup database and database user

Step (2)
use file: 2_goodagent_2012_01_04_weds.sql

create the tables and insert the data

step (3) 
use file: 3_view_sql

create the 'views', in the sequence in this file

======================== notes =================

the folder "99_exported_sql" contains the actual SQL exported from MySQL
howver, the "CREATE ALGORITHM=UNDEFINED" statements require superuser user prividges, which aren't usually possible for hosted databases

so the same effect can be achieved by steps (2) and (3) above ...


=============== author ===================

.. matt smith .. Jan 2012

email:
dr_matt_smith@me.com

tel: 
086 818 5945
