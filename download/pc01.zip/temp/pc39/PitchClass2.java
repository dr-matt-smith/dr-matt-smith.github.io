//
// set of utility methods
// to return different representations of pitch class 0..11
//
//

import java.awt.*;

public class PitchClass2{

// instance variable, stores Pitch Class as a integer (0..11)
	public int value;

//******************
// constructor(...)
//******************
// make the instance variable "value" become equal to the given integer
PitchClass2(int startPC)
{
	value= startPC;
} // end constructor method

//**************
// int pcAsInt()
//**************
// return the integer value of the instance variable "value"
public int pcAsInt()
{
	return value;
} // pcAsInt()

//********************
// String pcAsString()
//********************
// return an appropriate string corresponding to the instance variable "value"
// e.g. "C", "C#" etc.
public String pcAsString()
{
	String myPC = "";
	switch (value)
	{
		case 0: myPC = "C"; break;
		case 1: myPC = "C#"; break;
		case 2: myPC = "D"; break;
		case 3: myPC = "D#"; break;
		case 4: myPC = "E"; break;
		case 5: myPC = "F"; break;
		case 6: myPC = "F#"; break;
		case 7: myPC = "G"; break;
		case 8: myPC = "G#"; break;
		case 9: myPC = "A"; break;
		case 10: myPC = "A#"; break;
		case 11: myPC = "B"; break;
	} // end switch

	return myPC;

} // pcAsString()

//********************
// String pcAsAlpha()
//********************
// return an appropriate AlphaNumeric (0,1,2..8,9,a,b) 
// corresponding to the instance variable "value"
public String pcAsAlpha()
{
	String myPC = "";
	switch (value){
		case 0 : case 1 : case 2: case 3: case 4: case 5: 
		case 6: case 7: case 8: case 9:
			myPC = "" + value;
			break;

		case 10:
			myPC = "a";
			break;
		case 11:
			myPC = "b";
			break;
	} // switch

	return myPC;

} // pcAsAlpha()

} // class

