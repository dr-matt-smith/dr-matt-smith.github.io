public class M
{
	public M()
	{
		MIDIPlayer midi = new MIDIPlayer();
		midi.noteOn( 78 );
	}

	public static void main( String args[] )
	{
		M mm = new M();
	}
}