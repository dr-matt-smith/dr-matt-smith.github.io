//
// this class stores the radii for each of the 
// 7 concentric circles to be drawn
//
// the constructor works from a MAXIMUM X and Y 
// and the radius for the inner circle
//
// an even gap between each circle is calculated
// and this value used to increment the radii
// for each larger concentric circle

public class CircleStuff{
	public 	int[] psRadii = new int[7];
	public int circleGap;


	public CircleStuff(int maxX, int maxY, int ycenter, int innerRadius){

		// if 7 circles, there are 7 gaps between then
		circleGap = (ycenter - innerRadius) / 7;
	
		int currRadius;	
		int ps;	

		currRadius = innerRadius;

		// 7 circles (so array is from 0..6)
		for(ps = 0; ps < 6; ps++){
			psRadii[ps] = currRadius;
			currRadius += circleGap;
		}

	}

	// for a given pitch class (0..11)
	// return the angle for that position
	// in a CLOCK FACE (0/12 North (0 degrees), 6 South (180 degrees) etc.)
	public int arcAngle(int pitchClass){
		int degrees;
		// pitchClass/12 gives a %age of 360 degrees
		degrees = (int) (360 * ( (float)(pitchClass) / 12));
		return (360 - (degrees + (360 / 12 / 2) - 90)) % 360;
	}

}

