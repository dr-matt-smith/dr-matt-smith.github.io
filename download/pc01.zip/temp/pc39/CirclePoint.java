//
// calculate and record point co-ordinates (x, y) 
// on the CIRCUMFERECE of a circle
// for the given centre and radius
// for the given angle

public class CirclePoint{
	public int x, y;

	CirclePoint(int angle, int xCentre, int yCentre, int circleRadius){
		x = (int)(Math.cos(2 * angle * 3.14f/360 - 3.14f/2) * circleRadius + xCentre);
		y = (int)(Math.sin(2 * angle * 3.14f/360 - 3.14f/2) * circleRadius + yCentre);
	} // end constructor method


} // end class

