//
// a class to open a MIDI channel and play MIDI on() messages
//
// and set the instrument number
//

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import javax.swing.event.*;
import javax.sound.midi.*;
import java.util.Vector;

import java.io.File;
import java.io.IOException;

//*******************
// class MIDIPlayer
//*******************
public class MIDIPlayer
{

//*******************
// CONSTANTS
//*******************
	static final int ON = 0;
	static final int OFF = 1;

//*******************
// variables
//*******************
    Synthesizer synthesizer;
    Instrument instruments[];
    ChannelData cc;    // current channel

//*******************
// CONSTRUCTOR
//*******************
public MIDIPlayer() 
{
	// open a MIDI channel
	open();

} // constructor()

//**********
// open()
//**********
// open a new MIDI channel 
// and create a new synthesizer object
public void open() 
{

try {
	if (synthesizer == null) 
	{
		if ((synthesizer = MidiSystem.getSynthesizer()) == null) 
		{
			System.out.println("getSynthesizer() failed!");
			return;
                } // if
	} // if

	// open new SYNTHESIZER object
	synthesizer.open();

        
} catch (Exception ex) { ex.printStackTrace(); return; }

	// open SOUND BANK
        Soundbank sb = synthesizer.getDefaultSoundbank();

	if (sb != null) {
            instruments = synthesizer.getDefaultSoundbank().getInstruments();
            synthesizer.loadInstrument(instruments[0]);
        }

	// get MIDI  channels and choose channel ZERO
	MidiChannel midiChannels[] = synthesizer.getChannels();
	cc = new ChannelData( midiChannels[0], 0 );

} // open()

//**********
// close()
//**********
// set object references to "null" so they will 
// be deleted when garbage collection occurs
public void close() 
{
	synthesizer = null;
	instruments = null;

} // close()

//****************
// noteOn(...)
//****************
// send a NOTE ON message for the given note number and current instrument
public void noteOn( int noteNum )
{
	cc.channel.noteOn( noteNum, cc.velocity);

} // noteOn()

//********************
// setInstrument(...)
//********************
// set the current instrument (for future noteON messages)
// to the given instrument number
public void setInstrument( int instrument_num )
{
	synthesizer.loadInstrument(instruments[ instrument_num ]);
	cc.channel.programChange( instrument_num );

} // setInstrument()

//*****************
//** inner class ** STARTS 
//*****************
	//********************
	// ChannelData CLASS
	//********************
	// Stores MidiChannel information.
    	class ChannelData 
	{
		//**********
		// variables
		//**********
	        MidiChannel channel;
	        boolean solo, mono, mute, sustain;
	        int velocity, pressure, bend, reverb;
	        int row, col, num;
 
	        public ChannelData(MidiChannel channel, int num) 
		{
            		this.channel = channel;
            		this.num = num;
            		velocity = pressure = bend = reverb = 64;

        	} // method()
	
	}  // ** inner class **
//*****************
//** inner class ** ENDS
//*****************


////////////
} // class
