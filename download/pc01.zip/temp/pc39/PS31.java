import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import javax.swing.*;


public class PS31 extends JPanel
{
//**************
// CONSTANTS
//**************
// set up maximum values for region, chord and display values
	static final int REGION_ROOT_MAX = 11;
	static final int CHORD_ROOT_MAX = 11;
	static final int DISPLAY_MODE_MAX = 2;

// size of panel for drawing circles
	static final int PANEL_WIDTH = 500;
	static final int PANEL_HEIGHT = 500;
	static final int WINDOW_EXTRA = 100;
	
//**************
// VARIABLES
//**************
	
// initialise region, chord and display variables
	private PitchClass2 region1RootPC = new PitchClass2(0);
	private PitchClass2 chord1RootPC = new PitchClass2(0);	
	private int displayMode = 0;

// buttons
	public JButton chord1Clock;
	public JButton chord1Anticlock;
	public JButton region1Clock;
	public JButton region1Anticlock;
	public JButton displayClock;
	public JButton displayAnticlock;

// info panel and labels
	JPanel infoPanel;
	JLabel chordRootLabel;
	JLabel regionRootLabel;

// PSPANEL object
	PSPanel pspanel;

//**************
// CONSTRUCTOR
//**************
public PS31()
{
	// the PS panel
	pspanel = new PSPanel(
			0,			// displayMode
			PANEL_WIDTH,		// width
			PANEL_HEIGHT,		// height
			0, 			// basePC
			0, 			// regionStartPC
			region1RootPC.value, 	// regionRoot
			0,			// regionType
			chord1RootPC.value,	// chordRoot
			0			// chordType
		);

	// buttons for rotating chord and region roots
	// button for changing display symbols

	//********************
	// create the buttons
	chord1Anticlock = new JButton("< Chord1");
	chord1Clock = new JButton("Chord1 >");

	region1Anticlock = new JButton("< Region1");
	region1Clock = new JButton("Region1 >");

	displayAnticlock = new JButton("< Display");
	displayClock = new JButton("Display>");

	//********************
	// add the button click event handlers
	chord1Anticlock.addActionListener(
		new ActionListener()
		{
			public void actionPerformed( ActionEvent e )
			{
				chord1RootPC.value = (chord1RootPC.value - 1 + 12) % (CHORD_ROOT_MAX + 1);
				pspanel.setChordRoot( chord1RootPC.value );
				repaint();
			}
		});
	chord1Clock.addActionListener(
		new ActionListener()
		{
			public void actionPerformed( ActionEvent e )
			{
				chord1RootPC.value = (chord1RootPC.value + 1) % (CHORD_ROOT_MAX + 1);
				pspanel.setChordRoot( chord1RootPC.value );
				repaint();
			}
		});
	region1Anticlock.addActionListener(
		new ActionListener()
		{
			public void actionPerformed( ActionEvent e )
			{
				region1RootPC.value = (region1RootPC.value - 1 + 12) % (REGION_ROOT_MAX + 1);
				pspanel.setRegionRoot( region1RootPC.value );
				repaint();
			}
		});
	region1Clock.addActionListener(
		new ActionListener()
		{
			public void actionPerformed( ActionEvent e )
			{
				region1RootPC.value = (region1RootPC.value + 1) % (REGION_ROOT_MAX + 1);
				pspanel.setRegionRoot( region1RootPC.value );
				repaint();
			}
		});
	displayAnticlock.addActionListener(
		new ActionListener()
		{
			public void actionPerformed( ActionEvent e )
			{
				int newDisplayMode = (pspanel.displayMode - 1 + 12) % (DISPLAY_MODE_MAX + 1);
				pspanel.setDisplayMode( newDisplayMode );
				repaint();
			}
		});
	displayClock.addActionListener(
		new ActionListener()
		{
			public void actionPerformed( ActionEvent e )
			{
				int newDisplayMode = (pspanel.displayMode + 1) % (DISPLAY_MODE_MAX + 1);
				pspanel.setDisplayMode( newDisplayMode );
				repaint();
			}
		});

	//********************
	// add the buttons to a button Panel
	JPanel buttonPanel = new JPanel();
	buttonPanel.add( chord1Anticlock );
	buttonPanel.add( chord1Clock) ;
	buttonPanel.add( region1Anticlock );
	buttonPanel.add( region1Clock );
	buttonPanel.add( displayAnticlock );
	buttonPanel.add( displayClock );

// the info panel
	infoPanel = new JPanel();
	chordRootLabel = new JLabel();
	regionRootLabel = new JLabel();

	chordRootLabel.setForeground( Color.red );
	chordRootLabel.setFont( new Font("TimesRoman", Font.PLAIN, 14) );

	regionRootLabel.setForeground( Color.magenta );
	regionRootLabel.setFont( new Font("TimesRoman", Font.PLAIN, 14) );

	// add the labels to the info panel
	infoPanel.add( chordRootLabel );
	infoPanel.add( regionRootLabel );


// main panel
// set the layout manager and add the panels
	this.setLayout( new BorderLayout() );	
	this.add( buttonPanel, BorderLayout.NORTH );
	this.add( pspanel, BorderLayout.CENTER );
	this.add( infoPanel, BorderLayout.SOUTH );

	repaint();
	this.setVisible( true );

} // constructor()

//*********************
// paintComponent(...)
//*********************
public void paintComponent( Graphics g ) 
{
	super.paintComponent( g );

	// update info panel (for new roots)
	chordRootLabel.setText( "Chord1Root: " + chord1RootPC.pcAsString() );
	regionRootLabel.setText( "Region1Root: " + region1RootPC.pcAsString() );

} // paintComponent()


//**************
// main(...)
//**************
public static void main( String args[] )
{
	JFrame appWindow = new JFrame("Pitch Circles");
	appWindow.addWindowListener(
		new WindowAdapter()
		{
			public void windowClosing( WindowEvent e )
			{
				System.exit( 0 );
			}
		} );

	PS31 app = new PS31();

	appWindow.getContentPane().add( app, BorderLayout.CENTER );
	appWindow.pack();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	// centre the window in the screen
        appWindow.setLocation( screenSize.width/2 - PANEL_WIDTH/2, screenSize.height/2 - (PANEL_HEIGHT + WINDOW_EXTRA)/2);
        appWindow.setSize(PANEL_WIDTH, PANEL_HEIGHT + WINDOW_EXTRA);
	appWindow.setVisible( true );

} // main()

/////
} // class

