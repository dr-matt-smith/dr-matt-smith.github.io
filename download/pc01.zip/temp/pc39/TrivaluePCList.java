//
// array of 12 values - three possible states 0, 1, 2
//
// to indicate which segements of circles should be coloured
//
//

public class TrivaluePCList
{
//***********
// CONSTANTS
//***********
	public static final int OFF = 0;
	public static final int INNER = 1;
	public static final int OUTER = 2;


// instance variable, array [0..11] of int
	public int[] values = new int[12];

//***************
// constructor()
//***************
// initialise all members of array to "OFF"
TrivaluePCList()
{
	int pc;

	for(pc = 0; pc <= 11; pc++)
	{
		values[pc] = OFF;
	}

} // constructor()

} // class

