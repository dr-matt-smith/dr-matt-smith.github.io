//
// display pitch space as set of labelled and coloured 
// concentric circles / segments of circles
//
//
//

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;


public class PSPanel extends JPanel 
{

//************
// CONSTANTS
//************
	final int innerRadius = 40;
	final int textRadius = 7;
	final int textWidth = 18;
	final int textHeight = 10;

	static final int MIDDLE_C = 60;

	static final int CHROMATIC_SPACE = 0;
	static final int DIATONIC_SPACE = 1;
	static final int TRIADIC_SPACE = 2;
	static final int FIFTH_SPACE = 3;
	static final int ROOT_SPACE = 4;

//***********
// variables
//***********
	int basePC;
	int regionStartPC;
	int regionRoot;	
	int regionType;
	int chordRoot;
	int chordType;

	private int xcenter;
	private int ycenter;

	private int panel_width;
	private int panel_height;

// display mode state
	public int displayMode;
//?? should really be private !!

	public int[] psRadii = new int[7];

// MIDI object
	MIDIPlayer myMIDI;

////////////////////////////////////

//************
// CONSTRUCTOR
//************
public PSPanel( int _displayMode,
		int _panel_width,
		int _panel_height,
		int _basePC,
		int _regionStartPC,
		int _regionRoot,	
		int _regionType,
		int _chordRoot,
		int _chordType )
{
	// record initialisation parameters
	displayMode = _displayMode;

	basePC = _basePC;
	regionStartPC = _regionStartPC;
	regionRoot = _regionRoot;
	regionType = _regionType;
	chordRoot = _chordRoot;
	chordType = _chordType;

	panel_width = _panel_width;
	panel_height = _panel_height;

	// re-calculate centre of panel area
	xcenter = panel_width / 2;
	ycenter = panel_height / 2;

	// size this component and make visible
	this.setSize( new Dimension( panel_width, panel_height ) );
	this.setVisible( true );

	// add adapater to update panel_width and panel_height if component is resized
	this.addComponentListener(
		new ComponentAdapter()
		{
			//**********************
			// componentResized(...)
			//**********************
			// respond to RESIZEing of this panel
			// to change height and width state variables
			public void componentResized( ComponentEvent e )
			{
				panel_width = getWidth();
				panel_height = getHeight();

				// re-calculate centre of panel area
				xcenter = panel_width / 2;
				ycenter = panel_height / 2;

				repaint();
			}
		} );

	// create new MIDI object
	myMIDI = new MIDIPlayer();

} // constructor

//*********************
// paintComponent(...)
//*********************
public void paintComponent( Graphics g )
{
	super.paintComponent( g );

	CirclePoint myPoint1, myPoint2;
	
	int angle;
	int pc;
	PitchClass2 myPC;

	CircleStuff mystuff = new CircleStuff(panel_width, panel_height, ycenter, innerRadius);
	
	TrivaluePCList currLevel;

	int ps;
	int currRadius;

	// draw the filled arcs from the outside in for each pitch space
	for(ps = 4; ps > -1; ps--){
		currRadius = mystuff.psRadii[ps + 1];
		currLevel = levelPCsAsTrivalue(ps);

		// fill the whole circle for the current pitch space
		// (i.e. remove inner parts of arcs from previous (outer) rings
		g.setColor(Color.lightGray);	
		g.fillArc(xcenter - currRadius, ycenter - currRadius, currRadius * 2, currRadius * 2, 0, 360);

		// loop for each of the 12 pitch classes
		// drawing arc in appropriate colour if PC is active for current space
		for(pc = 0; pc < 12; pc++){
			angle = (int)(pc * (360 / 24));

			if (currLevel.values[pc] > 0)
			{
				// if current pitch is active for this level
				// set colour for filling in arc according to level
				switch(ps)
				{
					case CHROMATIC_SPACE:
						g.setColor(Color.white);
						break;
					case DIATONIC_SPACE:
						g.setColor(Color.magenta);
						break;
					case TRIADIC_SPACE: case FIFTH_SPACE: 
						g.setColor(Color.pink);	
						break;
					case ROOT_SPACE:
						// root space
						g.setColor(Color.pink);	
				} // switch	


				// fill arc for pitch at current level
				g.fillArc(xcenter - currRadius, ycenter - currRadius, currRadius * 2, currRadius * 2, mystuff.arcAngle(pc), 360/12);
				
			} // if

		} // for
	}

	// if going around outer circle draw the lines dividing each of the 12 PCs
	// (for the 5 inner circles display the text for the PC)
	g.setFont(new Font("TimesRoman", Font.PLAIN, 14));
	for(ps = 0; ps < 6; ps++){
		currRadius = mystuff.psRadii[ps];
		currLevel = levelPCsAsTrivalue(ps);

		g.setColor(Color.blue);
		g.drawOval(xcenter - currRadius,ycenter - currRadius,currRadius*2,currRadius*2);

		for(pc = 0; pc < 12; pc++){

			angle = (int)(pc * (360 / 12));
			myPC = new PitchClass2(pc);
			
			// for inner circles draw the text
			if (ps < 5){
				myPoint1 = new CirclePoint(angle, xcenter, ycenter, (int)(currRadius + mystuff.circleGap/2));

				if (   (currLevel.values[pc] == 2) && (  (ps == 1) || (ps == 4)  )    ){
					myPoint2 = new CirclePoint(angle - (360/40), xcenter, ycenter, (int)(currRadius + mystuff.circleGap*3/4));
					g.setColor(Color.yellow);
					g.fillArc(myPoint2.x - textRadius/2, myPoint2.y - textRadius/2, textRadius, textRadius, 0, 360);					
				}

				if (   (currLevel.values[pc] == 2) && (  (ps == 1) || (ps == 4)  )    ){
					myPoint2 = new CirclePoint(angle + (360/40), xcenter, ycenter, (int)(currRadius + mystuff.circleGap*3/4));
					g.setColor(Color.red);
					g.fillArc(myPoint2.x - textRadius/2, myPoint2.y - textRadius/2, textRadius, textRadius, 0, 360);					
				}

				g.setColor(Color.blue);	
				switch(displayMode){
					case 0:
						g.drawString("" + myPC.pcAsString(), myPoint1.x - 8, myPoint1.y + 5);
						break;
					case 1:
						g.drawString("" + myPC.pcAsAlpha(), myPoint1.x, myPoint1.y);
						break;
					case 2:
						g.drawString("" + myPC.pcAsInt(), myPoint1.x, myPoint1.y);
						break;
				}
			} else{
				// for outer circle draw line for current PC
				myPoint1 = new CirclePoint((int)(angle + (360/12)/2), xcenter, ycenter, currRadius);
				g.setColor(Color.blue);
				g.drawLine(xcenter, ycenter, myPoint1.x, myPoint1.y);
			} // else
		} // for2
	} // for1

	//******************************
	// play the notes of the triad
	//******************************

/* simple attempt - get the modulus inversions
	// triadic space is ps==2;
	boolean triadic_space = (ps == 2);

	// curr PitchClass is part of triad
	boolean triad_pc = (currLevel.values[pc] > 0);

	if( triadic_space && triad_pc )
	{
		// sound the note (MIDDLE_C + pitch_class)
		myMIDI.noteOn( MIDDLE_C + pc );
	}
*/



	// find out where the root is
	currLevel = levelPCsAsTrivalue( ROOT_SPACE );
	int root_pc = 0;
	for(pc = 0; pc < 12; pc++)
	{
		if( currLevel.values[pc] > 0)
		{
			// "pc" must be root pitch class
			root_pc = pc;
		}		
	}

	// using root_pc as offset so we can play chord in ROOT INVERSION
	// find pc's in triadic space and play these intervals above MIDDLE_C
	currLevel = levelPCsAsTrivalue( TRIADIC_SPACE );
	for(int i = 0; i < 12; i++)
	{
		// pc to check starts at root_pc
		pc = (root_pc + i);

		// use modulus 12 so we stay within array bounds
		if( currLevel.values[pc % 12] > 0)
		{
			// play this note
			int note = MIDDLE_C + pc;
			myMIDI.noteOn( note );
		}
	}
		
} // paintComponent()


////////////////////////
//

//*****************
// int pcAsInt(...)
//*****************
// return a PC as a string (given roots for this space)
public int pcAsInt( int PC )
{
	PitchClass2 myPC;
	myPC = new PitchClass2( (12 + PC + basePC) % 12 );

	return myPC.pcAsInt();

} // pcAsInt()

//********************
// String pcAsString()
//********************
// return a PC as a string (given roots for this space)
public String pcAsString( int PC )
{
	PitchClass2 myPC;
	myPC = new PitchClass2( (12 + PC + basePC) % 12 );

	return myPC.pcAsString();

} // pcAsString()

//************************************
// TrivaluePCList levelPCsAsTrivalue()
//************************************
// given a level, return a TrivaluePCList
public TrivaluePCList levelPCsAsTrivalue( int level )
{
	TrivaluePCList rawPCs = new TrivaluePCList ();
	TrivaluePCList chromPCs = new TrivaluePCList ();
	TrivaluePCList regionPCs = new TrivaluePCList ();
	TrivaluePCList returnPCs = new TrivaluePCList ();

	int pc;

	switch (level){
		case 0:
			rawPCs.values[0] = 2;
			for(pc = 1; pc <= 11; pc++){
				rawPCs.values[pc] = 1;
			}
			break;
		case 1:
			rawPCs.values[2] = 1;
			rawPCs.values[5] = 1;
			rawPCs.values[9] = 1;
			rawPCs.values[11] = 1;
		case 2:
			rawPCs.values[4] = 1;
		case 3:
			rawPCs.values[7] = 1;
		case 4:
			rawPCs.values[0] = 2;
			break;
	} // switch

	// convert/rotate raw PCs to PCs for Chromatic (i.e. adjust all PCs by basePC)
////////// this is currently WRONG !!!!!!!!!!!!!!!!
////////// this is currently WRONG !!!!!!!!!!!!!!!!
////////// this is currently WRONG !!!!!!!!!!!!!!!!
////////// this is currently WRONG !!!!!!!!!!!!!!!!
////////// this is currently WRONG !!!!!!!!!!!!!!!!
////////// this is currently WRONG !!!!!!!!!!!!!!!!
	for(pc = 0; pc <= 11; pc++){
		chromPCs.values[((pc + 12 + basePC) % 12)] = rawPCs.values[pc];
	}

	// convert/rotate Chromatic PCs to PCs for Region (i.e. adjust all PCs by regionRoot)
	for(pc = 0; pc <= 11; pc++){
		regionPCs.values[((pc + 12 + regionRoot) % 12)] = chromPCs.values[pc];
	}

	if (level > 1)
	{
		// convert/rotate Region PCs to PCs for Chord (i.e. adjust all PCs by ChordRoot)
		for(pc = 0; pc <= 11; pc++)
		{
			returnPCs.values[((pc + 12 + chordRoot) % 12)] = chromPCs.values[pc];
		}
	} else {
		for(pc = 0; pc <= 11; pc++)
		{
			returnPCs.values[pc] = regionPCs.values[pc];
		}
	} // if/else

	return returnPCs;
		
} // levelPCsAsTrivalue()


//**********************
// setDisplayMode(...)
//**********************
public void setDisplayMode( int _displayMode )
{
	displayMode = _displayMode;
}

//**********************
// setChordRoot(...)
//**********************
public void setChordRoot( int _chordRoot )
{
	chordRoot = _chordRoot;
}

//**********************
// setRegionRoot(...)
//**********************
public void setRegionRoot( int _regionRoot )
{
	regionRoot = _regionRoot;
}

///////////////
} // class

