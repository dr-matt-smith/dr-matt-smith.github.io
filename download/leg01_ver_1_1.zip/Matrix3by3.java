
import javax.swing.*;

public class Matrix3by3
{

///////////////////////
//                   //
//      private      //
//                   //
///////////////////////
// the matrix object is stored as a 3x3 array called "m"
	private double m[][] = new double[3][3];

// Concatenate premulitiplies the matrix "m2" with the matrix
// data of the matrix that calls this function.
//
// The result is overwritten into the "m" data of the matrix
// that called this function
//
// This is a private method.
///////////////////////////////////////////////////////////////////
public void concatenate(Matrix3by3 m2)
{
Matrix3by3 tmp = new Matrix3by3();
int r,c;
int i,k;

	// concatenate the internal "m" array with "m2"s
	// putting result into "tmp"
	for (r=0;r<3;r++)
		for(c=0;c<3;c++)
			tmp.m[r][c] = 	( m[r][0] * m2.m[0][c] ) +
					( m[r][1] * m2.m[1][c] ) +
					( m[r][2] * m2.m[2][c] );

	// copy values from "tmp" into "m"
	for(r=0;r<3;r++)
		for(c=0;c<3;c++)
			m[r][c]=tmp.m[r][c];

}

///////////////////////////
//                       //
//      constructor      //
//                       //
///////////////////////////
// The Matrix constructor sets the matrix entries in the
// "m" array to the identity matrix
////////////////////////////////////////////////////////////////
public Matrix3by3()
{
	setIdentity();
}

public Matrix3by3(
		double double_1_1,
		double double_1_2,
		double double_1_3,
		double double_2_1,
		double double_2_2,
		double double_2_3,
		double double_3_1,
		double double_3_2,
		double double_3_3)
{
	setIdentity();

	m[0][0] = double_1_1;
	m[0][1] = double_1_2;
	m[0][2] = double_1_3;
	m[1][0] = double_2_1;
	m[1][1] = double_2_2;
	m[1][2] = double_2_3;
	m[2][0] = double_3_1;
	m[2][1] = double_3_2;
	m[2][2] = double_3_3;
}

// SetIdentity resets the matrix to the identity matrix
////////////////////////////////////////////////////////////////
public void setIdentity()
{
	 m[0][0] = 1;	m[0][1] = 0;	m[0][2] = 0;
	 m[1][0] = 0;	m[1][1] = 1;	m[1][2] = 0;
	 m[2][0] = 0;	m[2][1] = 0;	m[2][2] = 1;
}



///////////////////////
//                   //
//      public       //
//                   //
///////////////////////


// "rotate()"
// (2D rotation about the Z axis)
//////////////////////////////////////////////////
public void rotate(double a)
{
	Matrix3by3 tmp = new Matrix3by3();
	int r,c;
	double aRad;

	// C++ trig functions  (Sin, Cos etc.) are for angles in
	// RADIANS, not DEGREES
	//
	//	angleRadians 	= (AngleDegrees / 360 ) * ( 2 * PI)
	//                 	= AngleDegrees * (PI / 180)
	aRad = a*(3.142/180.0);

	//	[ cosA  	-SinA  		0 ]
	// R = 	[ sinA   	 CosA  		0 ]
	//	[  0       	   0        	1 ]
	tmp.m[0][0] = (float) Math.cos(aRad);
	tmp.m[0][1] = (float) -Math.sin (aRad);
	tmp.m[1][0] = (float) Math.sin(aRad);
	tmp.m[1][1] = (float) Math.cos(aRad);
	// (since "tmp" is initialised to identity,
	//  only non-identify array values need to be set)

	concatenate(tmp);
}

// Scale sets up a matrix for scaling where xf,yf is the fixed point for
// scaling and sx and sy are the parameters for scaling in the x and y
// directions respectively
//
// This function concatenates the scaling matrix with the matrix data
// for the matrix that called it eg:
//		myMatrix.Scale(xf,yf,sx,sy);
// The matrix myMatrix would be set to the result of concatenating
// myMatrix with the scaling matrix.
// The scaling would be performed BEFORE other transformations previously
// encoded in myMatrix.
/////////////////////////////////////////////////////////////////////
public void scale(double xf, double yf, double sx, double sy)
{
Matrix3by3 tmp = new Matrix3by3();
int r,c;
	//	[ Sx  0   Xf(1 - Sx)    ]
	// S = 	[ 0   Sy  Yf(1 - Sy)    ]
	//  	[ 0   0   1 		]
	tmp.m[0][0] = sx;
	tmp.m[1][1] = sy;
	tmp.m[0][2] = xf * (1.0 - sx);
	tmp.m[1][2] = yf * (1.0 - sy);

	concatenate(tmp);
}

// Translate sets up a matrix for translation where tx and ty are the
//translation factors for the x and y directions respectively.
//
// This function concatenates the tramslation matrix with the matrix data for
// the matrix that called it eg:
// 		myMatrix.Translate(tx,ty);
// The matrix myMatrix would be set to the result of concatenating myMatrix with
// the translation matrix.
// The translation would be performed BEFORE other transformations previously
// encoded in myMatrix.
////////////////////////////////////////////////////////
public void translate(double tx, double ty)
{
Matrix3by3 tmp = new Matrix3by3();
int r,c;

	//	[ 1   0   Tx ]
	// T = 	[ 0   1   Ty ]
	//	[ 0   0   1  ]
	tmp.m[0][2] = tx;
	tmp.m[1][2] = ty;

	concatenate(tmp);
}

public void reflectAboutXAxis()
{
Matrix3by3 tmp = new Matrix3by3();
int r,c;

	//	[ 1   0   0 ]
	// T = 	[ 0   -1   0 ]
	//	[ 0   0   1  ]
	tmp.m[1][1] = -1;

	concatenate(tmp);
}


// TransformPoly transform points using the matrix that called this function.
//
// eg:
//		myMatrix.TransformPoly(3,poly)
// transforms the points in the array poly by myMatrix.
// Note that points in poly are changed to their new values.
//
// "p" is a pointer to an array of double values where x and y values are
// stored successively (as the TC++ fillrect function will only accept
// points using this unintuitive representation).
//
// numpoints is the number of points ie: (length of array / 2)
////////////////////////////////////////////////////////////////////////
public void transformPoly(Point2D points[], int numpoints)
{
	//	[ a1   a2    a3 ]   [ x ]   [ (a1 * x) + (a2 * y) + a3 ] 
	// M = 	[ b1   b2    b3 ] * [ y ] = [ (b1 * x) + (b2 * y) + b3 ]
	//	[ c1   c2    c3 ]   [ 1 ]   [            1             ]

int k;
double x, y;
double newX, newY;

	for(k=0; k < numpoints; k++ ){
		x = points[k].getX();
		y = points[k].getY();

		newX = (m[0][0] * x) + (m[0][1] * y) + m[0][2];
		newY = (m[1][0] * x) + (m[1][1] * y) + m[1][2];

		points[k].setX( newX );
		points[k].setY( newY );
	}
}

public void println()
{
	System.out.println(
		" m[0][0] = " + m[0][0] + " m[0][1] = " + m[0][1] + " m[0][2] = " + m[0][2] 
			); 

	System.out.println(
		" m[1][0] = " + m[1][0] + " m[1][1] = " + m[1][1] + " m[1][2] = " + m[1][2] 
			); 

	System.out.println(
		" m[2][0] = " + m[2][0] + " m[2][1] = " + m[2][1] + " m[2][2] = " + m[2][2] 
			); 

}


}// class