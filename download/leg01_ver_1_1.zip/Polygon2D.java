
import java.awt.*;
//import java.awt.event.*;
import javax.swing.*;
import java.text.*;

/////////////////////////////////////////////////////////
// Class "Polygon3D"
// Author: Matt Smith
// Created: Nov 2000
// Last changed: May 2000 by Matt Smith
// Purpose: example 3D graphic object class for polygons
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
public class Polygon2D{

	static final int MAX_NUM_POINTS = 1000;

	public Point2D points[] = new Point2D[ MAX_NUM_POINTS ];

	private int numPoints;

	private	Color lineColor;
	private	Color fillColor;
	private boolean filled;

// arrays for integer values to pass to drawLine/fillPoly etc.
	int xValues[];
	int yValues[];

Polygon2D()
{
	// default
	numPoints = 0;
	lineColor = Color.black;
	filled = false;
}

public void addPoint( double x, double y)
{
	// should throw an exception if go over max points

	// should really use a Vector not an array
	points[ numPoints ] = new Point2D( x, y);	
	numPoints++;
}

public void addPoint( Point2D p)
{
	addPoint( p.getX(), p.getY() );
}

public void clearAllPoints()
{
	numPoints = 0;
}

public void transform( Matrix3by3 m )
{
	m.transformPoly( points, numPoints );
}

public void setLineColor( Color _lineColor )
{
	lineColor = _lineColor;
}

public void setFilled( boolean _filled )
{
	filled = _filled;
}

public boolean getFilled()
{
	return filled;
}

public Color getLineColor()
{
	return lineColor;
}

public void setFillColor( Color _fillColor )
{
	fillColor = _fillColor;
}

public Color getFillColor()
{
	return fillColor;
}


public void paint( Graphics g )
{
	// get integer version of Points array
	// (into variables xValues, yValues)
	convertToInt();

	g.setColor( lineColor );

	if( filled)
		g.fillPolygon( xValues, yValues, numPoints );

	else
		g.drawPolygon( xValues, yValues, numPoints );
}

/////////
private void convertToInt()
{
	// set size of these arrays according to number of points
	xValues = new int[numPoints];
	yValues = new int[numPoints];

	// copy x and y value from each point into the parallel arrays
	for( int i = 0; i < numPoints; i++)
	{
		xValues[i] = (int) points[i].getX();	
		yValues[i] = (int) points[i].getY();	
	}
}

public void listPoints()
{
	System.out.println("numPoints : " + numPoints);
	for(int i=0; i < numPoints; i++)
	{	
		System.out.println(
			"** Point " + i + " : (" 
			+ points[i].getX() + ", "
			+ points[i].getY() + ") "
				);
	}
}


public void popupPoints()
{
	JOptionPane.showMessageDialog( null, toString() );
}

String asString()
{	
//	DecimalFormat myformatter = new DecimalFormat("##0.00");
	NumberFormat nf = NumberFormat.getInstance();

	String s = "";
	s += "numPoints : " + numPoints;
	for(int i=0; i < numPoints; i++)
	{	
		s +=	"\nPoint " + i + " : (" 
			+ nf.format( points[i].getX() ) + ", "
			+ nf.format( points[i].getY() ) + ") ";
	}
	return s;
}



public double meanAverageX()
{
	float total = 0;
	for( int i = 0; i < numPoints; i++)
	{
		total += points[i].getX();
	}

	return (total / numPoints);
}

public double meanAverageY()
{
	float total = 0;
	for( int i = 0; i < numPoints; i++)
	{
		total += points[i].getY();
	}

	return (total / numPoints);
}


public Polygon2D copy()
{
	Polygon2D myCopy = new Polygon2D();

	myCopy.setLineColor( getLineColor() );
	myCopy.setFillColor( getFillColor() );
	myCopy.setFilled( getFilled() );
	

	for(int i = 0; i < numPoints; i++)
	{
		double x = points[i].getX();
		double y = points[i].getY();

		myCopy.addPoint( x, y );
	}


	return myCopy;
}

} // class

