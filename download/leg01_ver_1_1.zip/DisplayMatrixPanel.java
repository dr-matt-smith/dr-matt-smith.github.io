import  java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.lang.reflect.*;

class DisplayMatrixPanel extends JPanel
{
	int width = 100;
	int height = 100;
	
DisplayMatrixPanel()
{
	setMinimumSize( new Dimension( width, height ) );
	setMaximumSize( new Dimension( width, height ) );

	setVisible( true );

	// init values here

}

public void paintComponent( Graphics g )
{
	super.paintComponent( g );

	// paint stuff here
}

public void updateLEDdisplay()
{
	// update state of model from arguments here

	// update view display	
	repaint();
} // method

} // class
