/*
 Things for Matt to do

(1) ensure there is only 1 "(" and 1 ")" and they are in the right order
(2) require parentheses around argument?
(3) allow other trig (in addition to Sin and Cos?)

*/




// expression in a string parse class

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.lang.*; // for Math class

public class ExpressionParser
{

//-----------------------
//   PRIVATE instance variables
//-----------------------
	// expression string, e.g. "- sin( 23.0 )"
	String expressionString;

	// boolean variables for features of expression
	boolean isSINFunction;
	boolean isCOSFunction;
	boolean isNEGATIVE;

	// boolean parse error indicator
	boolean parseError;

	// value of inner expression (e.g. 23.0 if "-sin(23.0)")
	double innerExpressionValue;

	// variable to store real value of parsed expression
	double expressionValue;

// trace
boolean trace;

//-----------------------
//   constructor
//-----------------------
ExpressionParser(String _expressionString)
{
// --- trace
//tron();
troff();

	// set expressionValue to -1, in case of future error
	//(users of this class should always check the 'parseError' value first
	expressionValue = -1;

	// store provided string
	expressionString = removeSpaces( _expressionString );

	// inially we don't know expression features
	isSINFunction = false;
	isCOSFunction = false;
	isNEGATIVE = false;

	// no errors yet
	parseError = false;

	//-------------------
	// parse in stages
	//-------------------

	// "- sin( 45.2 ) >> isNEGATIVE "sin(45.2)"
	parseNegative();
trace();
	// "sin( 45.2 ) >> isSINFunction "45.2"
	// "cos( 45.2 ) >> isCOSFunction "45.2"
	if( !parseError )
		parseTrig();
trace();

	// "45.2" >> innerExpressionValue=45.2
	if( !parseError )
		parseArgument();
trace();

	// -1 * sin( 45.2 )
	if( !parseError )
		buildExpressionValue();
trace();
}

//------------------------
//    parseNegative()
//------------------------
void parseNegative()
{
	// if leading "-" sign remove it and set negative
	if (expressionString.charAt(0) == '-')
	{
		isNEGATIVE = true;
		expressionString = expressionString.substring(1, expressionString.length());
	}
} // method


//--------------------------
//    parseArgument()
//--------------------------
void parseArgument()
{
	try
	{
		Double tempDouble = new Double( expressionString );

		innerExpressionValue = tempDouble.doubleValue();

	} catch (NumberFormatException nfe)
	{
		parseError = true;
	}
} // method

//--------------------------
//    buildExpressionValue()
//--------------------------
void buildExpressionValue()
{
	expressionValue = innerExpressionValue;

	// convert from degrees to radians for
	// trig functions  (Sin, Cos etc.) are for angles in RADIANS, not DEGREES
	//
	// so we convert angle "a" from degrees to RADIANS
	// there are (2 * PI) radians in a circle
	// there are 360 degrees in a circle
	// so
	//	angleRadians 	= (AngleDegrees / 360 ) * ( 2 * PI)
	//                 	= AngleDegrees * (PI / 180)
	double angleAsRadians = innerExpressionValue * (Math.PI / 180.0);

	// apply trig function
	if( isSINFunction )
	{
		// use inner expression value as angle in radians
		expressionValue = Math.sin( angleAsRadians );
	}
	
	if( isCOSFunction )
	{
		// use inner expression value as angle in radians
		expressionValue = Math.cos( angleAsRadians );
	}
	
	// if negative make negative
	if( isNEGATIVE )
		expressionValue = -1 * expressionValue;
} // method

//------------------------
//    parseTrig
//------------------------
void parseTrig()
{
	// if sin( X ) or cos( X ) then extract the X
	expressionString.toLowerCase();    // (so "Sin" "SIN" "sin" all okay etc.)

	// sin( X )
	if( (expressionString.length() > 2) && 
		(expressionString.substring(0, 3).equals("sin") ) )
	{
		isSINFunction = true;
	}

	// cos( X )
	if( (expressionString.length() > 2) && 
		(expressionString.substring(0, 3).equals("cos") ))
	{
		isCOSFunction = true;
	}

	// if sin/cos found, remove these chars (and any parentheses) from expression string
	if( isSINFunction || isCOSFunction )
	{
		// remove the first 3 characers (i.e. "cos" or "sin")
		expressionString = expressionString.substring(3, expressionString.length() );		

		// replace parentheses with spaces and remove them!
		expressionString = expressionString.replace( '(', ' ' );
		expressionString = expressionString.replace( ')', ' ' );
		expressionString = removeSpaces( expressionString );
	}
} // method

//------------------------
//   removeSpaces()
//------------------------
String removeSpaces( String s )
{
	// remove leading and training spaces
	s = s.trim();


	// remove the rest of the spaces using a char array
	char charArray[] = new char[ s.length() ];
	s.getChars(0, s.length(), charArray, 0 );

	String newString = "";

	// add each non-space character to "newString"
	for(int i = 0; i < s.length();  i++)
	{

		if( charArray[i] != ' ')
		{
			newString += charArray[i];
		}
	}

	return newString;
} // method

//------------------------
//   getParseError()
//------------------------
boolean getParseError()
{
	return parseError;
}

//------------------------
//   getExpressionValue()
//------------------------
double getExpressionValue()
{
	return expressionValue;
}

//------ trace state ------
void trace()
{
	if( trace )
	{
		String s = "expressionString '" + expressionString;
		s += "\n isNEGATIVE " + isNEGATIVE;
		s += "\n isSINFunction " +  isSINFunction;
		s += "\n isCOSFunction " + isCOSFunction;
		s += "\n parseError " + parseError;
		s += "\n expressionValue " + expressionValue;
		System.out.println(s);

	}
}

//----- tron - trace on
void tron()
{
	trace = true;
}

//---- troff - trace off
void troff()
{
	trace = false;
}

} // class