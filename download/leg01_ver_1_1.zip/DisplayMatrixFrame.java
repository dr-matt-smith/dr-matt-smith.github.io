// DIsplayMatrix Frame

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DisplayMatrixFrame extends JFrame 
{

	DisplayMatrixPanel myDisplayMatrixPanel; 

public DisplayMatrixFrame()
{
	super( "Frame displaying any matrix" );
	setSize( 275, 65 );

	// create an LEDPanel for displaying
	myDisplayMatrixPanel = new DisplayMatrixPanel();

	// add LEDPanel to the content pane of the JFrame
	Container c = getContentPane();
	c.add( myDisplayMatrixPanel );

	// don't show the frame until "LED panel" button pressed ...
	setVisible( false );
}

public DisplayMatrixPanel getDisplayMatrixPanel()
{
	return myDisplayMatrixPanel;	
}


void pause( int delayPeriod )
// wait 'delayPeriod' milliseconds
{
	try {
		Thread.sleep( delayPeriod );
	} catch (InterruptedException e ) {}
} // method pause()




} // class