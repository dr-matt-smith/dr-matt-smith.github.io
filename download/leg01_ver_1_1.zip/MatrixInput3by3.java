
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MatrixInput3by3
		extends JPanel
{

// numeric values
	private double double_1_1;
	private double double_1_2;
	private double double_1_3;
	private double double_2_1;
	private double double_2_2;
	private double double_2_3;
	private double double_3_1;
	private double double_3_2;
	private double double_3_3;

// text fields
	private JTextField text_1_1;
	private JTextField text_1_2;
	private JTextField text_1_3;
	private JTextField text_2_1;
	private JTextField text_2_2;
	private JTextField text_2_3;
	private JTextField text_3_1;
	private JTextField text_3_2;
	private JTextField text_3_3;

// buttons
	JButton setIdentityButton;
	JButton translateButton;
	JButton scaleButton;
	JButton rotateButton;
	JButton shearXButton;
	JButton shearYButton;
	JButton reflectAboutXAxisButton;
	JButton reflectAboutYAxisButton;

	JButton revertButton;

// parent
	LEG01 parent;

public MatrixInput3by3(LEG01 _parent)
{
// set up reference to parent applet
	parent = _parent;

// create handler for events from buttons and text boxes
	ButtonAndTextListener eventHandler = new ButtonAndTextListener();

//----------------------
// set up the panels
//----------------------
/*

	|-------------------
	|  main button panel
	|  NORTH
	|---------------------
	| matrix panel
	| CENTER
	|-----------------
	|  REVERT button panel
	|  SOUTH
	|-----------------

*/

// set up 3x3 text inputs for panel
	JPanel textInputs = new JPanel();

	textInputs.setLayout(new GridLayout( 3, 3, 5, 5 ) );	

	int fieldSize = 6;

	text_1_1 = new JTextField( fieldSize );
	textInputs.add( text_1_1 );
	text_1_1.addActionListener( eventHandler );

	text_1_2 = new JTextField( fieldSize );
	textInputs.add( text_1_2 );
	text_1_2.addActionListener( eventHandler );

	text_1_3 = new JTextField( fieldSize );
	textInputs.add( text_1_3 );
	text_1_3.addActionListener( eventHandler );

	text_2_1 = new JTextField( fieldSize );
	textInputs.add( text_2_1 );
	text_2_1.addActionListener( eventHandler );

	text_2_2 = new JTextField( fieldSize );
	text_2_2.addActionListener( eventHandler );

	textInputs.add( text_2_2 );
	text_2_3 = new JTextField( fieldSize );
	text_2_3.addActionListener( eventHandler );

	textInputs.add( text_2_3 );
	text_3_1 = new JTextField( fieldSize );
	text_3_1.addActionListener( eventHandler );

	textInputs.add( text_3_1 );
	text_3_2 = new JTextField( fieldSize );
	text_3_2.addActionListener( eventHandler );

	textInputs.add( text_3_2 );
	text_3_3 = new JTextField( fieldSize );
	text_3_3.addActionListener( eventHandler );

	textInputs.add( text_3_3 );

	setIdentity();

	setLayout( new BorderLayout() );
	add( textInputs, BorderLayout.CENTER );


// REVERT BUTTON PANEL
	JPanel revertButtonPanel = new JPanel();
	add( revertButtonPanel, BorderLayout.SOUTH );

	// REVERT button
	revertButton = new JButton("undo all transformations");
	revertButtonPanel.add( revertButton );
	revertButton.addActionListener( eventHandler );


// BUTTON PANEL
	JPanel buttonPanel = new JPanel();
	buttonPanel.setLayout( new GridLayout( 8, 1, 5, 5 ) );
	add( buttonPanel, BorderLayout.NORTH );

// IDENTITY button
	setIdentityButton = new JButton("identity");
	buttonPanel.add( setIdentityButton );
	setIdentityButton.addActionListener( eventHandler );

// TRANSLATE button
	translateButton = new JButton("translate");
	buttonPanel.add( translateButton );
	translateButton.addActionListener( eventHandler );

// SCALE button
	scaleButton = new JButton("scale");
	buttonPanel.add( scaleButton );
	scaleButton.addActionListener( eventHandler );

// ROTATE button
	rotateButton = new JButton("rotate");
	buttonPanel.add( rotateButton );
	rotateButton.addActionListener( eventHandler );

// SHEAR-X button
	shearXButton = new JButton("shear X");
	buttonPanel.add( shearXButton );
	shearXButton.addActionListener( eventHandler );

// SHEAR-Y button
	shearYButton = new JButton("shear Y");
	buttonPanel.add( shearYButton );
	shearYButton.addActionListener( eventHandler );

// reflect about X axis button
	reflectAboutXAxisButton = new JButton("reflect about X axis");
	buttonPanel.add( reflectAboutXAxisButton );
	reflectAboutXAxisButton.addActionListener( eventHandler );

// reflect about Y axis button
	reflectAboutYAxisButton = new JButton("reflect about Y axis");
	buttonPanel.add( reflectAboutYAxisButton );
	reflectAboutYAxisButton.addActionListener( eventHandler );

} // method


//----------------
// setIdentity()
//----------------
// set all the text fields to show the identity matrix
void setIdentity()
{
	text_1_1.setText( "1" );
	text_1_2.setText( "0" );
	text_1_3.setText( "0" );

	text_2_1.setText( "0" );
	text_2_2.setText( "1" );
	text_2_3.setText( "0" );

	text_3_1.setText( "0" );
	text_3_2.setText( "0" );
	text_3_3.setText( "1" );
}

/////// inner class for handling button events
private class ButtonAndTextListener implements ActionListener
{

public void actionPerformed( ActionEvent e )
{
	boolean errors = false;

	// if RETURN pressed in any text field process matrix strings from them
	if( 
		( e.getSource() == text_1_1 ) ||
		( e.getSource() == text_1_2 ) ||
		( e.getSource() == text_1_3 ) ||
		( e.getSource() == text_2_1 ) ||
		( e.getSource() == text_2_2 ) ||
		( e.getSource() == text_2_3 ) ||
		( e.getSource() == text_3_1 ) ||
		( e.getSource() == text_3_2 ) ||
		( e.getSource() == text_3_3 )   )
	{
		applyMatrixFromTextBoxes();
	}


	if( e.getSource() == setIdentityButton )
	{
		setIdentity();
		applyMatrixFromTextBoxes();
	}

	if( e.getSource() == translateButton )
	{
		String xString = JOptionPane.showInputDialog( "Enter X amount to translate (e.g. 0.1 or -1) " );
		String yString = JOptionPane.showInputDialog( "Enter Y amount to translate (e.g. 0.1 or -1) " );

		try
		{
			Double xDouble = new Double( xString );
			Double yDouble = new Double( yString );

			double x = xDouble.doubleValue();
			double y = yDouble.doubleValue();

			setIdentity();
			text_1_3.setText( "" + x );
			text_2_3.setText( "" + y );
			applyMatrixFromTextBoxes();


		} catch (NumberFormatException nfe)
		{
			JOptionPane.showMessageDialog( null, "one of the values entered was not a valid number" );
			errors = true;
		}
	}

	if( e.getSource() == scaleButton )
	{
		String xString = JOptionPane.showInputDialog( "Enter X amount to scale by (e.g. 0.1 or -1) " );
		String yString = JOptionPane.showInputDialog( "Enter Y amount to scale by (e.g. 0.1 or -1) " );

		try
		{
			Double xDouble = new Double( xString );
			Double yDouble = new Double( yString );

			double x = xDouble.doubleValue();
			double y = yDouble.doubleValue();

			setIdentity();
			text_1_1.setText( "" + x );
			text_2_2.setText( "" + y );
			applyMatrixFromTextBoxes();
		} catch (NumberFormatException nfe)
		{
			JOptionPane.showMessageDialog( null, "one of the values entered was not a valid number" );
			errors = true;
		}
	}

	if( e.getSource() == rotateButton )
	{
		String rotationString = JOptionPane.showInputDialog( "Enter rotation in degrees (positive is anti-clockwise. e.g. 5 or -5)" );
		try
		{
			Double rotationDouble = new Double( rotationString );
			double rotation = rotationDouble.doubleValue();

			setIdentity();
			text_1_1.setText("cos( " + rotation + ")");
			text_1_2.setText("-sin( " + rotation + ")");
			text_2_1.setText("sin( " + rotation + ")");
			text_2_2.setText("cos( " + rotation + ")");
			applyMatrixFromTextBoxes();
		} catch (NumberFormatException nfe)
		{
			JOptionPane.showMessageDialog( null, "value entered is not a valid number" );
			errors = true;
		}
	}

	if( e.getSource() == shearXButton )
	{
		String xString = JOptionPane.showInputDialog( "Enter amount to X shear by (e.g. 0.1)" );
		try
		{
			Double xDouble = new Double( xString );
			double x = xDouble.doubleValue();

			setIdentity();
			text_1_2.setText("" + x);
			applyMatrixFromTextBoxes();
		} catch (NumberFormatException nfe)
		{
			JOptionPane.showMessageDialog( null, "value entered is not a valid number" );
			errors = true;
		}
	}

	if( e.getSource() == shearYButton )
	{
		String yString = JOptionPane.showInputDialog( "Enter amount to Y shear by (e.g. 0.1)" );
		try
		{
			Double yDouble = new Double( yString );
			double y = yDouble.doubleValue();

			setIdentity();
			text_2_1.setText("" + y);
			applyMatrixFromTextBoxes();
		} catch (NumberFormatException nfe)
		{
			JOptionPane.showMessageDialog( null, "value entered is not a valid number" );
			errors = true;
		}
	}

	if( e.getSource() == reflectAboutXAxisButton )
	{
		setIdentity();
		text_2_2.setText("-1");
		applyMatrixFromTextBoxes();
	}

	if( e.getSource() == reflectAboutYAxisButton )
	{
		setIdentity();
		text_1_1.setText("-1");
		applyMatrixFromTextBoxes();
	}


	if( e.getSource() == revertButton )
	{
		parent.revertToOriginal();
		setIdentity();
		applyMatrixFromTextBoxes();
	}

//	text_1_1.requestFocus();




} // method 

} //------------------ end of inner class

//-----------------------------
// applyMatrixFromTextBoxes()
//-----------------------------
void applyMatrixFromTextBoxes()
{
	boolean errors = false;

	String s_1_1 =  text_1_1.getText();
	String s_1_2 =  text_1_2.getText();
	String s_1_3 =  text_1_3.getText();
	String s_2_1 =  text_2_1.getText();
	String s_2_2 =  text_2_2.getText();
	String s_2_3 =  text_2_3.getText();
	String s_3_1 =  text_3_1.getText();
	String s_3_2 =  text_3_2.getText();
	String s_3_3 =  text_3_3.getText();

//////// 1 1
	ExpressionParser parse1_1 = new ExpressionParser( s_1_1 );
	double_1_1 = parse1_1.getExpressionValue();
	if( parse1_1.getParseError() )
	{
		JOptionPane.showMessageDialog( null, "element 1 1 not valid expression" );
		errors = true;
	}

//////// 1 2
	ExpressionParser parse1_2 = new ExpressionParser( s_1_2 );
	double_1_2 = parse1_2.getExpressionValue();
	if( parse1_2.getParseError() )
	{
		JOptionPane.showMessageDialog( null, "element 1 2 not valid expression" );
		errors = true;
	}

//////// 1 3
	ExpressionParser parse1_3 = new ExpressionParser( s_1_3 );
	double_1_3 = parse1_3.getExpressionValue();
	if( parse1_3.getParseError() )
	{
		JOptionPane.showMessageDialog( null, "element 1 3 not valid expression" );
		errors = true;
	}

//////// 2 1
	ExpressionParser parse2_1 = new ExpressionParser( s_2_1 );
	double_2_1 = parse2_1.getExpressionValue();
	if( parse2_1.getParseError() )
	{
		JOptionPane.showMessageDialog( null, "element 2 1 not valid expression" );
		errors = true;
	}

//////// 2 2
	ExpressionParser parse2_2 = new ExpressionParser( s_2_2 );
	double_2_2 = parse2_2.getExpressionValue();
	if( parse2_2.getParseError() )
	{
		JOptionPane.showMessageDialog( null, "element 2 2 not valid expression" );
		errors = true;
	}

//////// 2 3
	ExpressionParser parse2_3 = new ExpressionParser( s_2_3 );
	double_2_3 = parse2_3.getExpressionValue();
	if( parse2_3.getParseError() )
	{
		JOptionPane.showMessageDialog( null, "element 2 3 not valid expression" );
		errors = true;
	}

//////// 3 1
	ExpressionParser parse3_1 = new ExpressionParser( s_3_1 );
	double_3_1 = parse3_1.getExpressionValue();
	if( parse3_1.getParseError() )
	{
		JOptionPane.showMessageDialog( null, "element 3 1 not valid expression" );
		errors = true;
	}

//////// 3 2
	ExpressionParser parse3_2 = new ExpressionParser( s_3_2 );
	double_3_2 = parse3_2.getExpressionValue();
	if( parse3_2.getParseError() )
	{
		JOptionPane.showMessageDialog( null, "element 3 2 not valid expression" );
		errors = true;
	}

//////// 3 3
	ExpressionParser parse3_3 = new ExpressionParser( s_3_3 );
	double_3_3 = parse3_3.getExpressionValue();
	if( parse3_3.getParseError() )
	{
		JOptionPane.showMessageDialog( null, "element 3 3 not valid expression" );
		errors = true;
	}


	if( !errors )
	{
		parent.setTransformationMatrix(
			double_1_1,
			double_1_2,
			double_1_3,
			double_2_1,
			double_2_2,
			double_2_3,
			double_3_1,
			double_3_2,
			double_3_3 );

		parent.transformObjects();
	}
	else
		JOptionPane.showMessageDialog( null, "error in values - NOT applied to object" );
		
} // method

public void displayAdvancedButtons( boolean visible )
{
	shearXButton.setVisible( visible );
	shearYButton.setVisible( visible );
	reflectAboutXAxisButton.setVisible( visible );
	reflectAboutYAxisButton.setVisible( visible );

	repaint();
}



} // class