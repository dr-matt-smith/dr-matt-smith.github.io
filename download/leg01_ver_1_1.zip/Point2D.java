
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/////////////////////////////////////////////////////////
// Class "Point2D"
// Author: Matt Smith
// Created: Dec 2000
// Last changed: May 2000 by Matt Smith
// Purpose: example 2D graphic object class for points
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////

class Point2D{

private double x;
private double y;
Color myColor;

public Point2D( )
{
	x = 0;
	y = 0;
}

public Point2D( double _x, double _y )
{
	setXY( _x, _y );
}

public void setXY( double _x, double _y )
{
	setX( _x );
	setY( _y );
}

public void setX( double _x )
{
	x = _x;
}

public void setY( double _y )
{
	y = _y;
}

public double getX()
{ 	return x;	}

public double getY()
{	return y;	}

} // class