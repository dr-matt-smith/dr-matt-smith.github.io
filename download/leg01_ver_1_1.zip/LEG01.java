// HTML applet tag comment so runs with 'appletviewer'
// <applet code="LEG01.class" width=750 height=400>[LEG01 Applet appears here on Java-capable browsers]</applet>

////////////////////////////

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.lang.reflect.*;
import java.text.*;

import Polygon2D;
import Matrix3by3;

public class LEG01
	extends JApplet 
	implements ActionListener
{   

/////////////////////////////////////////
//  timer for repeated transformation  //
////////////////////////////////////////
	protected javax.swing.Timer animationTimer;

	// 50 milisecond delay)
	protected int animationDelay = 1;


//----------------------------
// to loop or not to loop
//----------------------------
	boolean looping;

//----------------------------
// to display coordinates each change or not
//----------------------------
	boolean displayCoordinates;

//----------------------------
// to display advanced buttons or not
//----------------------------
	boolean displayAdvancedButtons;

// the PANEL objects
	DrawingPanel graphicPanel;
	JPanel rightPanel;
	JPanel mainButtonPanel;
	JPanel matrixPanel;
	JPanel checkBoxPanel;
	JPanel coordinatesPanel;

	JPanel innerCheckBoxPanel;

	JScrollPane coordinatesScrollPane;

// a text area for displaying coordinates
	JTextArea coordinatesTextArea;

// state variable for show/hide Matrix panel
	boolean matrixPanelVisible;

// Frame/Panel for displaying matrix
	DisplayMatrixFrame myDisplayMatrixFrame;
	DisplayMatrixPanel myDisplayMatrixPanel;

// applet window size and title
	private int width = 400;
	private int height = 400;
	static final String windowTitle = "LEG 01 v1.1 (bug fix version 12 March 2001)";

// matrix input panel
	MatrixInput3by3 matrixInput3by3;

// matrix object for current transformation
	Matrix3by3 currentTransformation;

// ZOOM mouse pointer variables
	Image zoomInImage;
	Image zoomOutImage;
	Cursor zoomInCursor;
	Cursor zoomOutCursor;

///////////////
// run timer
///////////////
	protected javax.swing.Timer myTimer;
	boolean running = false;

// 50 milisecond delay
	int timerDelay = 10;
	int runSpeed = 0;
	int runCounter = 0;

///////////
// about and DisplayMatrix Buttons
///////////
	JCheckBox loopCheckBox;
	JCheckBox coordinatesCheckBox;
	JCheckBox advancedCheckBox;
	JButton aboutButton;

/*------------------------------------
 *       (internal) init
 *------------------------------------*/
public void init()
{	
// initially set NOT to loop
	looping = false;

// initially set NOT to display coordinates
	displayCoordinates = true;

// initially set to display coordinates
	displayAdvancedButtons = true;

// set up timer for animation
	animationTimer = new  javax.swing.Timer( animationDelay, this );
	animationTimer.start();

// load images and create ZOOM in and out mouse cursors
	Toolkit toolkit = Toolkit.getDefaultToolkit();
	zoomInImage = toolkit.getImage("images/zoom_in.gif");
	zoomOutImage = toolkit.getImage("images/zoom_out.gif");

	zoomInCursor = toolkit.createCustomCursor( zoomInImage, new Point(0,0), "zoom in cursor");
	zoomOutCursor = toolkit.createCustomCursor( zoomOutImage, new Point(0,0), "zoom in cursor");

//	setCursor( zoomInCursor );
//	setCursor( zoomOutCursor );
// 	setCursor( Cursor.DEFAULT_CURSOR );

//----------------------
// set up the panels
//----------------------
/*

	|---------------|---------
	|		||----------------------------
	| graphic panel ||  right panel |-------------------
	| CENTER	||  EAST	| main button panel 	|----------------|
	|		||		|  NORTH		| checkbox panel | button
00	|		||		|			|----------------|
	|		||		|---------------------
					| matrix panel
					| CENTER
					|-----------------
					| list of points panel
					| SOUTH


*/
	// create the panels
	graphicPanel = new DrawingPanel( this );
	rightPanel = new JPanel();
	mainButtonPanel = new JPanel();
	matrixPanel = new JPanel();
//	coordinatesPanel = new JPanel();

	// get the container
	Container c = getContentPane();
	c.setLayout(new BorderLayout());

	// add the panels
	c.add( graphicPanel,  BorderLayout.CENTER );
	c.add( new JScrollPane( rightPanel ),  BorderLayout.EAST );

	rightPanel.setLayout(new BorderLayout());
	rightPanel.add( mainButtonPanel,  BorderLayout.NORTH );
	rightPanel.add( matrixPanel,  BorderLayout.CENTER );
//	rightPanel.add( coordinatesPanel, BorderLayout.SOUTH ) ;


	// default is to show the matrix panel
	matrixPanelVisible = true;

// the coorinates panel
//	coordinatesTextArea = new JTextArea("", 15, 20);
//	coordinatesScrollPane = new JScrollPane( coordinatesTextArea );
//	coordinatesPanel.add( coordinatesScrollPane  );
//	updateDisplayedCoordinates();

	//----------------------------------
	// the buttons and button handlers
	//----------------------------------
	// buttonPanel and button event handler class
	ButtonHandler handler = new ButtonHandler();

// check box panel
	checkBoxPanel = new JPanel();
	checkBoxPanel.setLayout( new GridLayout( 2, 1, 5, 5 ) );
	mainButtonPanel.add( checkBoxPanel );

// coordinates check box
	coordinatesCheckBox = new JCheckBox( "display coordinates", true);
	CheckBoxHandler checkBoxHandler = new CheckBoxHandler();
	coordinatesCheckBox.addItemListener( checkBoxHandler );
//	checkBoxPanel.add( coordinatesCheckBox );

// inner check box panel
	innerCheckBoxPanel = new JPanel();
	innerCheckBoxPanel.setLayout( new GridLayout( 1, 2, 5, 5 ) );
	checkBoxPanel.add( innerCheckBoxPanel );

// loop check box
	loopCheckBox = new JCheckBox( "loop" );
	loopCheckBox.addItemListener( checkBoxHandler );
	innerCheckBoxPanel.add( loopCheckBox );

// advanced check box
	advancedCheckBox = new JCheckBox( "advanced", true);
	advancedCheckBox.addItemListener( checkBoxHandler );
	innerCheckBoxPanel.add( advancedCheckBox );

// "About" button
	aboutButton = new JButton("About");
	aboutButton.addActionListener( handler );
	mainButtonPanel.add( aboutButton );

//////// matrix input panel
	matrixInput3by3 = new MatrixInput3by3( this );
	matrixPanel.add( matrixInput3by3 );

	///////////////////////////////////
	//////////// start run timer

	// set up timer for animation
	myTimer = new javax.swing.Timer( timerDelay, this );

}

////////////// MAIN - to allow running as an application ////////
// main()
public static void main( String args[] )
{
        int width2;
        int height2;

        if( args.length != 2)
        {
                // no command line args
                width2 = 750;
                height2 = 400;
        }
        else
        {
                // set width and height according to command line args
                width2 = Integer.parseInt( args[0] );
                height2 = Integer.parseInt( args[1] );
        }

        // create window in which applet will execute
        JFrame applicationWindow = new JFrame( windowTitle );

        WindowAdapter myWindowAdapter = new WindowAdapter()
        {
                public void windowClosing( WindowEvent e )
                {
                        System.exit( 0 );
                }
        };

        applicationWindow.addWindowListener( myWindowAdapter );

        // create an applet instance
        LEG01 appletObject = new LEG01();
        appletObject.setSize( width2, height2 );

        // call applets "init()" and "start()" methods
        appletObject.init();
        appletObject.start();

        // attach applet to centre of window
        applicationWindow.getContentPane().add( appletObject );

        //set the windows size
        applicationWindow.setSize( width2, height2 );

        // call all GUI components to be painted by calling "show()"
        applicationWindow.show();
} // method







public void revertToOriginal()
{
	graphicPanel.resetObjectCoordinates();
}

public void updateDisplayedCoordinates()
{
	String coordinateString  = graphicPanel.polygon.asString();
//	coordinatesTextArea.setText( coordinateString );

//	repaint();//
}

public void setTransformationMatrix(
					double double_1_1,
					double double_1_2,
					double double_1_3,
					double double_2_1,
					double double_2_2,
					double double_2_3,
					double double_3_1,
					double double_3_2,
					double double_3_3 )
{
	currentTransformation = new Matrix3by3( 
				double_1_1,
				double_1_2,
				double_1_3,
				double_2_1,
				double_2_2,
				double_2_3,
				double_3_1,
				double_3_2,
				double_3_3 );

	graphicPanel.setTransformationMatrix( currentTransformation );
}

////////// inner class for check box handling
////////// inner class for check box handling
private class CheckBoxHandler implements ItemListener
{
        public void itemStateChanged( ItemEvent e )
        {
		if( e.getSource() == loopCheckBox )
			if( e.getStateChange() == ItemEvent.SELECTED )
				setLooping( true );
			else
				setLooping( false );


		if( e.getSource() == advancedCheckBox )
			if( e.getStateChange() == ItemEvent.SELECTED )
			{
				setDisplayAdvancedButtons( true );
			}
			else
			{
				setDisplayAdvancedButtons( false );
			}

		if( e.getSource() == coordinatesCheckBox )
			if( e.getStateChange() == ItemEvent.SELECTED )
			{
				setDisplayCoordinates( true );

// hack to fix placement of text box
				boolean temp = displayAdvancedButtons;
				setDisplayAdvancedButtons( ! temp );
				setDisplayAdvancedButtons( temp );
			}
			else
			{
				setDisplayCoordinates( false );
			}

	} // method
}// inner class

////////// inner class for "FileMenu" button handler
////////// inner class for "FileMenu" button handler
private class FileMenuHandler implements ActionListener
{
        public void actionPerformed( ActionEvent e )
        {
		String command = e.getActionCommand();

		if( command == "Exit" )
		{
                        System.exit( 0 );
		}
	}
			
}

////////// inner class for ABOUT button handler
////////// inner class for ABOUT button handler
private class ButtonHandler implements ActionListener
{
        public void actionPerformed( ActionEvent e )
        {
		if( e.getSource() == aboutButton )
		{
			String aboutMessage = "";

			aboutMessage += windowTitle + "\n";
			aboutMessage += "LEG 01= Learning Environment for Graphics";
			aboutMessage += "\n";
			aboutMessage += "\nAn environment for learning about computer graphics";
			aboutMessage += "\n";
			aboutMessage += "\nCopyright Nov 2000 Matt Smith";
			aboutMessage += "\nEMAIL  matt.smith@smithit.com";

			JOptionPane.showMessageDialog( null, aboutMessage );
		}

        } // method actionPerformed()

} // inner class ButtonHandler

/////////////////////////////
//                         //
//   timer action clicks   //
//                         //
/////////////////////////////
public void actionPerformed( ActionEvent e )
{	
	if( looping )
	{
		transformObjects();
	}
}


public void transformObjects()
{
	graphicPanel.transformObjects(); 	
	repaint();
}


public void x()
{
	if( looping )
	{
//		graphicPanel.repaint(); 	
		repaint();

		if( displayCoordinates )
		{
			updateDisplayedCoordinates();
		}
	}
}

void setLooping(boolean _looping)
{
	looping = _looping;
}

void setDisplayCoordinates(boolean _displayCoordinates)
{
	displayCoordinates = _displayCoordinates;
//	coordinatesScrollPane.setVisible( displayCoordinates );

	if( displayCoordinates )
	{
		updateDisplayedCoordinates();
	}
}


void setDisplayAdvancedButtons( boolean _displayAdvancedButtons )
{
	displayAdvancedButtons = _displayAdvancedButtons;
	matrixInput3by3.displayAdvancedButtons( displayAdvancedButtons );
	repaint();
}

void repaint(Graphics g)
{
	updateDisplayedCoordinates();
	graphicPanel.repaint(); 	

	x();
}


} // class


/*
/////////////////////////////
//                         //
//   timer action clicks   //
//                         //
/////////////////////////////

public void startRunning()
{
	// start run timer
	myTimer.start();

	running = true;	
	runCounter = 0;

}

public void stopRunning()
{
	myTimer.stop();

	running = false;
	runCounter = 0;
}
*/
