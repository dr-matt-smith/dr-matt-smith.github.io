
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.lang.*;

public class DrawingPanel
		extends JPanel
{
//---------------
// constants
//---------------
	static final int MAX_NUM_POINTS = 1000;

	static final int myWidth = 500;
	static final int myHeight = 500;

//---------------
// variables
//---------------
	// matrix to transform polygon by each tick
	Matrix3by3 transformationMatrix;


//----------------------------
// polygon to be transformed
//----------------------------
	public Polygon2D polygon;
	Polygon2D xaxis;
	Polygon2D yaxis;

// Y=50
	Polygon2D minusY50sign;
	Polygon2D fiveYminus50;
	Polygon2D noughtYminus50;

// Y=50
	Polygon2D fiveY50;
	Polygon2D noughtY50;

// X=50
	Polygon2D fiveX50;
	Polygon2D noughtX50;

// X=100
	Polygon2D one;
	Polygon2D nought;
	Polygon2D nought2;


// X=minus50
	Polygon2D minus50sign;
	Polygon2D fiveXminus50;
	Polygon2D noughtXminus50;

// X=minus100
	Polygon2D minus100sign;
	Polygon2D oneXminus100;
	Polygon2D noughtXminus100;
	Polygon2D nought2Xminus100;

	Polygon2D two;
	Polygon2D three;
	Polygon2D four;
	Polygon2D five;
	Polygon2D six;
	Polygon2D seven;
	Polygon2D eight;
	Polygon2D nine;
	Polygon2D minusOne;
	Polygon2D minusTwoSign;
	Polygon2D minusTwo;
	Polygon2D minusThreeSign;
	Polygon2D minusThree;
	Polygon2D minusFourSign;
	Polygon2D minusFour;
	Polygon2D minusFiveSign;
	Polygon2D minusFive;
	Polygon2D minusSixSign;
	Polygon2D minusSix;
	Polygon2D minusSevenSign;
	Polygon2D minusSeven;
	Polygon2D minusEightSign;
	Polygon2D minusEight;
	Polygon2D minusNineSign;
	Polygon2D minusNine;

	// polygon for viewing transformations
	Polygon2D viewPolygon;

	// matrix for transforming the numbers
	Matrix3by3 numberTransformation;

//---------------
// 2D viewing system (world window, world limits, viewport)
//---------------
	double xwmax;
	double xwmin;
	double ywmax;
	double ywmin;

	double xvmax;
	double xvmin;
	double yvmax;
	double yvmin;

	// matrix for window to viewport transformation
	Matrix3by3 viewingScaleTransformation;
	Matrix3by3 viewingTranslateTransformation;
	Matrix3by3 yaxisTransformation;
	Matrix3by3 viewingTransformation;

// reference to calling parent
	JApplet parent;

///////////////////////
//                   //
//   constructor     //
//                   //
///////////////////////
   public DrawingPanel(JApplet _parent)
   {

	parent = _parent;

// World window settings and Viewport
	//WORLD window
	xwmax = 109;
	xwmin = -109;
	ywmax = 109;
	ywmin = -109;

	// default transformationMatrix is identity
	transformationMatrix = new Matrix3by3();
	transformationMatrix.setIdentity();

	// according to JPanel size
	calculateViewingTransformation();


// set up polygons
	polygon = new Polygon2D();

	resetObjectCoordinates();

	setUpAxisPolygons();
}

//------------------------------------
// calculateViewingTransformation()
//------------------------------------
// calculate Viewport max X and Y according to JPanel size
void calculateViewingTransformation()
{
	// device VIEWPORT
	xvmax = getWidth() - 1; // get width of JPanel
	xvmin = 0;
	yvmax = getHeight() - 1; // get height of JPanel
	yvmin = 0; 


// create matrices for window to viewport transformations
	// SCALE first
	// Scaling from window to viewport
	double sx = (xvmax - xvmin) / (xwmax- xwmin);
	double sy = (yvmax - yvmin) / (ywmax- ywmin);

	viewingScaleTransformation = new Matrix3by3();
	viewingScaleTransformation.setIdentity();
	viewingScaleTransformation.scale( 0, 0, sx, sy );

	// then TRANSLATE
	// translation from window postion to viewport position
	double tx = xvmin - (sx * xwmin);
	double ty = yvmin - (sy * ywmin);

	viewingTranslateTransformation = new Matrix3by3();
	viewingTranslateTransformation.setIdentity();
	viewingTranslateTransformation.translate( tx, ty );

	// then FLIP VERTICALLY (reflect about vertial center line for device origin
	// matrix to flip vertically to allow for (0,0) at top left of computer screen
	yaxisTransformation = new Matrix3by3();
	yaxisTransformation.setIdentity();
	yaxisTransformation.translate(0, ( yvmax / 2 ) );
	yaxisTransformation.reflectAboutXAxis();
	yaxisTransformation.translate(0, -1 * ( yvmax / 2 ) );

// single viewing transformation 
	viewingTransformation = new Matrix3by3();
	viewingTransformation.concatenate( yaxisTransformation );
	viewingTransformation.concatenate( viewingTranslateTransformation );
	viewingTransformation.concatenate( viewingScaleTransformation );
}


public void resetObjectCoordinates()
{
	polygon.clearAllPoints();
	polygon.setLineColor( Color.blue );
	polygon.setFilled( true );

	// square
	polygon.addPoint( 5, 1 );
	polygon.addPoint( 7, 1 );
	polygon.addPoint( 7, 3 );
	polygon.addPoint( 5, 3 );
		// roof
		polygon.addPoint( 6, 4 );
		polygon.addPoint( 7, 3 );
		polygon.addPoint( 5, 3 );
	polygon.addPoint( 5, 1 );

	// front door
	polygon.addPoint( 5.8, 1 );
	polygon.addPoint( 5.8, 1.5 );
	polygon.addPoint( 6.2, 1.5 );
	polygon.addPoint( 6.2, 1 );

	Matrix3by3 polygonTransformation = new Matrix3by3();
	polygonTransformation .setIdentity();
	polygonTransformation .scale( 0, 0, 10, 10 );
	polygon.transform( polygonTransformation );

}

void setUpAxisPolygons()
{
	setUpXAxis();
	setUpYAxis();

	GraphicNumbers numbers = new GraphicNumbers();


// X=minus100
	minus100sign = numbers.minusSign.copy();
	numberTransformation = new Matrix3by3();
	numberTransformation.setIdentity();
	numberTransformation.translate( -105, 0 );
	numberTransformation.scale( 0, 0, 2, 5 );
	numberTransformation.translate( 0, -2.1 );
	minus100sign.transform( numberTransformation );

	oneXminus100 = numbers.one.copy();
	numberTransformation = new Matrix3by3();
	numberTransformation.setIdentity();
	numberTransformation.translate( -102, 0 );
	numberTransformation.scale( 0, 0, 2, 5 );
	numberTransformation.translate( 0, -2.1 );
	oneXminus100.transform( numberTransformation );

	noughtXminus100 = numbers.nought.copy();
	numberTransformation = new Matrix3by3();
	numberTransformation.setIdentity();
	numberTransformation.translate( -100, 0 );
	numberTransformation.scale( 0, 0, 2, 5 );
	numberTransformation.translate( 0, -2.1 );
	noughtXminus100.transform( numberTransformation );

	nought2Xminus100 = numbers.nought.copy();
	numberTransformation = new Matrix3by3();
	numberTransformation.setIdentity();
	numberTransformation.translate( -97, 0 );
	numberTransformation.scale( 0, 0, 2, 5 );
	numberTransformation.translate( 0, -2.1 );
	nought2Xminus100.transform( numberTransformation );

// X=minus50
	minus50sign = numbers.minusSign.copy();
	numberTransformation = new Matrix3by3();
	numberTransformation.setIdentity();
	numberTransformation.translate( -55, 0 );
	numberTransformation.scale( 0, 0, 2, 5 );
	numberTransformation.translate( 0, -2.1 );
	minus50sign.transform( numberTransformation );

	fiveXminus50 = numbers.five.copy();
	numberTransformation = new Matrix3by3();
	numberTransformation.setIdentity();
	numberTransformation.translate( -52, 0 );
	numberTransformation.scale( 0, 0, 2, 5 );
	numberTransformation.translate( 0, -2.1 );
	fiveXminus50.transform( numberTransformation );

	noughtXminus50 = numbers.nought.copy();
	numberTransformation = new Matrix3by3();
	numberTransformation.setIdentity();
	numberTransformation.translate( -48, 0 );
	numberTransformation.scale( 0, 0, 2, 5 );
	numberTransformation.translate( 0, -2.1 );
	noughtXminus50.transform( numberTransformation );

// Y=50
	fiveY50 = numbers.five.copy();
	numberTransformation = new Matrix3by3();
	numberTransformation.setIdentity();
	numberTransformation.translate( 0, 48 );
	numberTransformation.scale( 0, 0, 2, 5 );
	numberTransformation.translate( -4.1, 0 );
	fiveY50 .transform( numberTransformation );

	noughtY50 = numbers.nought.copy();
	numberTransformation = new Matrix3by3();
	numberTransformation.setIdentity();
	numberTransformation.translate( 0, 48 );
	numberTransformation.scale( 0, 0, 2, 5 );
	numberTransformation.translate( -2.5, 0 );
	noughtY50.transform( numberTransformation );

// Y=minus50
	minusY50sign = numbers.minusSign.copy();
	numberTransformation = new Matrix3by3();
	numberTransformation.setIdentity();
	numberTransformation.translate( 0, -52 );
	numberTransformation.scale( 0, 0, 2, 5 );
	numberTransformation.translate( -5.5, 0 );
	minusY50sign.transform( numberTransformation );

	fiveYminus50 = numbers.five.copy();
	numberTransformation = new Matrix3by3();
	numberTransformation.setIdentity();
	numberTransformation.translate( 0, -52 );
	numberTransformation.scale( 0, 0, 2, 5 );
	numberTransformation.translate( -4.1, 0 );
	fiveYminus50 .transform( numberTransformation );

	noughtYminus50 = numbers.nought.copy();
	numberTransformation = new Matrix3by3();
	numberTransformation.setIdentity();
	numberTransformation.translate( 0, -52 );
	numberTransformation.scale( 0, 0, 2, 5 );
	numberTransformation.translate( -2.5, 0 );
	noughtYminus50.transform( numberTransformation );

// X=50
	fiveX50 = numbers.five.copy();
	numberTransformation = new Matrix3by3();
	numberTransformation.setIdentity();
	numberTransformation.translate( 48, 0 );
	numberTransformation.scale( 0, 0, 2, 5 );
	numberTransformation.translate( 0, -2.1 );
	fiveX50 .transform( numberTransformation );

	noughtX50 = numbers.nought.copy();
	numberTransformation = new Matrix3by3();
	numberTransformation.setIdentity();
	numberTransformation.translate( 52, 0 );
	numberTransformation.scale( 0, 0, 2, 5 );
	numberTransformation.translate( 0, -2.1 );
	noughtX50.transform( numberTransformation );

// X=100
	one = numbers.one.copy();
	numberTransformation = new Matrix3by3();
	numberTransformation.setIdentity();
	numberTransformation.translate( 97, 0 );
	numberTransformation.scale( 0, 0, 2, 5 );
	numberTransformation.translate( 0, -2.1 );
	one.transform( numberTransformation );

	nought = numbers.nought.copy();
	numberTransformation = new Matrix3by3();
	numberTransformation.setIdentity();
	numberTransformation.translate( 100, 0 );
	numberTransformation.scale( 0, 0, 2, 5 );
	numberTransformation.translate( 0, -2.1 );
	nought.transform( numberTransformation );

	nought2 = numbers.nought.copy();
	numberTransformation = new Matrix3by3();
	numberTransformation.setIdentity();
	numberTransformation.translate( 103, 0 );
	numberTransformation.scale( 0, 0, 2, 5 );
	numberTransformation.translate( 0, -2.1 );
	nought2.transform( numberTransformation );

/*
	two = numbers.two.copy();
	transformXAxisNumber( two, 2 );
	three= numbers.three.copy();
	transformXAxisNumber( three, 3 );
	four= numbers.four.copy();
	transformXAxisNumber( four, 4 );
	five= numbers.five.copy();
	transformXAxisNumber( five, 5 );
	six= numbers.six.copy();
	transformXAxisNumber( six, 6 );
	seven= numbers.seven.copy();
	transformXAxisNumber( seven, 7 );
	eight= numbers.eight.copy();
	transformXAxisNumber( eight, 8 );
	nine= numbers.nine.copy();
	transformXAxisNumber( nine, 9 );

	minusOne = numbers.one.copy();
	transformXAxisNumber( minusOne, -1 );
	minusOneSign = numbers.minusSign.copy();
	transformXAxisNumber( minusOneSign, -1.5 );

	minusTwo = numbers.two.copy();
	transformXAxisNumber( minusTwo, -2 );
	minusTwoSign = numbers.minusSign.copy();
	transformXAxisNumber( minusTwoSign, -2.5 );

	minusThree = numbers.three.copy();
	transformXAxisNumber( minusThree, -3 );
	minusThreeSign = numbers.minusSign.copy();
	transformXAxisNumber( minusThreeSign, -3.5 );

	minusFour = numbers.four.copy();
	transformXAxisNumber( minusFour, -4 );
	minusFourSign = numbers.minusSign.copy();
	transformXAxisNumber( minusFourSign, -4.5 );

	minusFive = numbers.five.copy();
	transformXAxisNumber( minusFive, -5 );
	minusFiveSign = numbers.minusSign.copy();
	transformXAxisNumber( minusFiveSign, -5.5 );

	minusSix = numbers.six.copy();
	transformXAxisNumber( minusSix, -6 );
	minusSixSign = numbers.minusSign.copy();
	transformXAxisNumber( minusSixSign, -6.5 );

	minusSeven = numbers.seven.copy();
	transformXAxisNumber( minusSeven, -7 );
	minusSevenSign = numbers.minusSign.copy();
	transformXAxisNumber( minusSevenSign, -7.5 );

	minusEight = numbers.eight.copy();
	transformXAxisNumber( minusEight, -8 );
	minusEightSign = numbers.minusSign.copy();
	transformXAxisNumber( minusEightSign, -8.5 );

	minusNine = numbers.nine.copy();
	transformXAxisNumber( minusNine, -9 );
	minusNineSign = numbers.minusSign.copy();
	transformXAxisNumber( minusNineSign, -9.5 );
*/
}

void transformXAxisNumber( Polygon2D numberPolygon, double position )
{
	numberTransformation.setIdentity();
	numberTransformation.translate( (position - 1 ) + 0.8, -0.8 );
	numberTransformation.scale( 0, 0, 2, 5 );
	numberPolygon.transform( numberTransformation );
}

void setUpXAxis()
{
	double currx;
	int intCurrx;

	xaxis = new Polygon2D();

	double yLines = -4;
	
//	for(currx = xwmin;  currx <= xwmax; currx+=10)
// hard coded for -100 to +100
	for(currx = -100;  currx <= 100; currx+=10)
	{
		xaxis.addPoint( currx, 0);
		xaxis.addPoint( currx, yLines);
		xaxis.addPoint( currx, 0);
	}
}

void setUpYAxis()
{
	double curry;
	int intCurry;

	yaxis = new Polygon2D();

	double xLines = -2;
	
	for(curry = -100;  curry <= 100; curry+=10)
	{
		yaxis.addPoint( 0, curry);
		yaxis.addPoint( xLines, curry);
		yaxis.addPoint( 0, curry);
	}
}


///////////////////////////////////
//                               //
//   setTransformationMatrix     //
//                               //
///////////////////////////////////
public void setTransformationMatrix(Matrix3by3 _transformationMatrix)
{
	transformationMatrix = _transformationMatrix;

	repaint();
}

public void transformObjects()
{
	polygon.transform( transformationMatrix );
}

/////////////////
//             //
//   paint     //
//             //
/////////////////
public void paintComponent( Graphics g )
{
        super.paintComponent( g );
//	polygon.transform( transformationMatrix );

	// accordingt to size of component
	calculateViewingTransformation();

	paintPolygonAfterViewingTransformation( g, xaxis );
	paintPolygonAfterViewingTransformation( g, yaxis );
	paintPolygonAfterViewingTransformation( g, polygon );

	paintPolygonAfterViewingTransformation( g, nought);
	paintPolygonAfterViewingTransformation( g, nought2);
	paintPolygonAfterViewingTransformation( g, one );

// Y=-50
	paintPolygonAfterViewingTransformation( g, minusY50sign );
	paintPolygonAfterViewingTransformation( g, fiveYminus50 );
	paintPolygonAfterViewingTransformation( g, noughtYminus50);

// Y=50
	paintPolygonAfterViewingTransformation( g, fiveY50 );
	paintPolygonAfterViewingTransformation( g, noughtY50);

// X=50
	paintPolygonAfterViewingTransformation( g, fiveX50 );
	paintPolygonAfterViewingTransformation( g, noughtX50);

// X=minus50
	paintPolygonAfterViewingTransformation( g, minus50sign );
	paintPolygonAfterViewingTransformation( g, fiveXminus50 );
	paintPolygonAfterViewingTransformation( g, noughtXminus50);

// X=-100
	paintPolygonAfterViewingTransformation( g, minus100sign );
	paintPolygonAfterViewingTransformation( g, oneXminus100 );
	paintPolygonAfterViewingTransformation( g, noughtXminus100 );
	paintPolygonAfterViewingTransformation( g, nought2Xminus100 );

//	paintPolygonAfterViewingTransformation( g, two );
//	paintPolygonAfterViewingTransformation( g, three );
//	paintPolygonAfterViewingTransformation( g, four );
//	paintPolygonAfterViewingTransformation( g, five);
//	paintPolygonAfterViewingTransformation( g, six );
//	paintPolygonAfterViewingTransformation( g, seven );
//	paintPolygonAfterViewingTransformation( g, eight );
//	paintPolygonAfterViewingTransformation( g, nine );

//	paintPolygonAfterViewingTransformation( g, minusOneSign );
//	paintPolygonAfterViewingTransformation( g, minusOne );
//	paintPolygonAfterViewingTransformation( g, minusTwoSign );
//	paintPolygonAfterViewingTransformation( g, minusTwo );
//	paintPolygonAfterViewingTransformation( g, minusThreeSign );
//	paintPolygonAfterViewingTransformation( g, minusThree );
//	paintPolygonAfterViewingTransformation( g, minusFourSign );
//	paintPolygonAfterViewingTransformation( g, minusFour );
//	paintPolygonAfterViewingTransformation( g, minusFiveSign );
//	paintPolygonAfterViewingTransformation( g, minusFive );
//	paintPolygonAfterViewingTransformation( g, minusSixSign );
//	paintPolygonAfterViewingTransformation( g, minusSix );
//	paintPolygonAfterViewingTransformation( g, minusSevenSign );
//	paintPolygonAfterViewingTransformation( g, minusSeven );
//	paintPolygonAfterViewingTransformation( g, minusEightSign );
//	paintPolygonAfterViewingTransformation( g, minusEight );
//	paintPolygonAfterViewingTransformation( g, minusNineSign );
//	paintPolygonAfterViewingTransformation( g, minusNine );
}

//------------------------------
// view system transformation
//------------------------------
void paintPolygonAfterViewingTransformation( Graphics g, Polygon2D p )
{
	// make a copy of the polygon to transoform
	viewPolygon = p.copy();

	viewPolygon.transform( viewingTransformation );
//	viewPolygon.transform( viewingScaleTransformation );
//	viewPolygon.transform( viewingTranslateTransformation );
//	viewPolygon.transform( yaxisTransformation );

	// draw the polygon
	viewPolygon.paint( g );
}



} // class
