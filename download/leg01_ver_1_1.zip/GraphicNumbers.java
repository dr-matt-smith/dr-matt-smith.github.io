class GraphicNumbers
{

// variables
	public Polygon2D one;
	public Polygon2D two;
	public Polygon2D three;
	public Polygon2D four;
	public Polygon2D five;
	public Polygon2D six;
	public Polygon2D seven;
	public Polygon2D eight;
	public Polygon2D nine;
	public Polygon2D nought;
	public Polygon2D minusSign;


// methods

//--------------
// constructor 
//--------------
GraphicNumbers()
{
	defineOne();
	defineTwo();
	defineThree();
	defineFour();
	defineFive();
	defineSix();
	defineSeven();
	defineEight();
	defineNine();
	defineNought();
	defineMinusSign();
}

//--------------
// defineOne()
//--------------
void defineOne()
{
	one = new Polygon2D();
	one.addPoint( 0.5, 1.0 );
	one.addPoint( 0.2, 0.6 );
	one.addPoint( 0.5, 1.0 );
	one.addPoint( 0.5, 0.0 );
	one.addPoint( 0.2, 0.0 );
	one.addPoint( 0.8, 0.0 );
	one.addPoint( 0.5, 0.0 );
} // method

//--------------
// defineTwo()
//--------------
void defineTwo()
{
	two = new Polygon2D();
	two.addPoint( 0.0, 1.0 );
	two.addPoint( 1.0, 1.0 );
	two.addPoint( 1.0, 0.5 );
	two.addPoint( 0.0, 0.5 );
	two.addPoint( 0.0, 0.0 );
	two.addPoint( 1.0, 0.0 );
	two.addPoint( 0.0, 0.0 );
	two.addPoint( 0.0, 0.5 );
	two.addPoint( 1.0, 0.5 );
	two.addPoint( 1.0, 1.0 );
	two.addPoint( 0.0, 1.0 );
} // method

//--------------
// defineThree()
//--------------
void defineThree()
{
	three = new Polygon2D();
	three.addPoint( 1.0, 0.5);
	three.addPoint( 0.2, 0.5 );
	three.addPoint( 1.0, 0.5 );
	three.addPoint( 1.0, 1.0 );
	three.addPoint( 0.0, 1.0 );
	three.addPoint( 1.0, 1.0 );
	three.addPoint( 1.0, 0.0 );
	three.addPoint( 0.0, 0.0 );
	three.addPoint( 1.0, 0.0 );
} // method

//--------------
// defineFour()
//--------------
void defineFour()
{
	four = new Polygon2D();
	four.addPoint( 0.5, 0.0);
	four.addPoint( 0.5, 1.0);
	four.addPoint( 0.0, 0.4);
	four.addPoint( 1.0, 0.4);
	four.addPoint( 0.0, 0.4);
	four.addPoint( 0.5, 1.0);
	four.addPoint( 0.5, 0.0);
} // method

//--------------
// defineFive()
//--------------
void defineFive()
{
	five = new Polygon2D();
	five.addPoint( 1.0, 1.0);
	five.addPoint( 0.0, 1.0);
	five.addPoint( 0.0, 0.5);
	five.addPoint( 1.0, 0.5);
	five.addPoint( 1.0, 0.0);
	five.addPoint( 0.0, 0.0);
	five.addPoint( 1.0, 0.0);
	five.addPoint( 1.0, 0.5);
	five.addPoint( 0.0, 0.5);
	five.addPoint( 0.0, 1.0);
	five.addPoint( 1.0, 1.0);
} // method

//--------------
// defineSix()
//--------------
void defineSix()
{
	six = new Polygon2D();
	six.addPoint( 1.0, 1.0);
	six.addPoint( 0.0, 1.0);
	six.addPoint( 0.0, 0.0);
	six.addPoint( 1.0, 0.0);
	six.addPoint( 1.0, 0.5);
	six.addPoint( 0.0, 0.5);
	six.addPoint( 0.0, 1.0);
	six.addPoint( 1.0, 1.0);
} // method

//--------------
// defineSeven()
//--------------
void defineSeven()
{
	seven = new Polygon2D();
	seven.addPoint( 0.0, 1.0);
	seven.addPoint( 1.0, 1.0);
	seven.addPoint( 0.0, 0.0);
	seven.addPoint( 1.0, 1.0);
	seven.addPoint( 0.0, 1.0);
} // method

//--------------
// defineEight()
//--------------
void defineEight()
{
	eight = new Polygon2D();
	eight.addPoint( 0.0, 0.0);
	eight.addPoint( 1.0, 0.0);
	eight.addPoint( 1.0, 1.0);
	eight.addPoint( 0.0, 1.0);
	eight.addPoint( 0.0, 0.5);
	eight.addPoint( 1.0, 0.5);
	eight.addPoint( 0.0, 0.5);
} // method

//--------------
// defineNine()
//--------------
void defineNine()
{
	nine = new Polygon2D();
	nine.addPoint( 1.0, 0.0);
	nine.addPoint( 1.0, 1.0);
	nine.addPoint( 0.0, 1.0);
	nine.addPoint( 0.0, 0.5);
	nine.addPoint( 1.0, 0.5);
} // method

//--------------
// defineNine()
//--------------
void defineNought()
{
	nought = new Polygon2D();
	nought.addPoint( 0.0, 0.0 );
	nought.addPoint( 1.0, 0.0 );
	nought.addPoint( 1.0, 1.0 );
	nought.addPoint( 0.0, 1.0 );
} // method

//--------------
// defineMinusSign()
//--------------
void defineMinusSign()
{
	minusSign = new Polygon2D();
	minusSign.addPoint( 0.5, 0.6 );
	minusSign.addPoint( 0.9, 0.6 );
//	minusSign.addPoint( 0.9, 0.5 );
//	minusSign.addPoint( 0.5, 0.5 );
} // method

} // class